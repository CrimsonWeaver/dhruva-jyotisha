// Runs the page's inline UI script against a minimal fake DOM with a mock Astronomy.GeoVector.
const fs = require('fs'), vm = require('vm');
const html = fs.readFileSync('dhruva-jyotisha.html', 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
console.log('inline scripts:', scripts.length);
const D2R = Math.PI / 180;
// Mock ephemeris: each body sits at a different fixed ecliptic-ish direction so signs/nakshatras vary.
const ra = { Sun: 280, Moon: 223, Mars: 328, Mercury: 272, Jupiter: 25, Venus: 242, Saturn: 40 };
const Astronomy = { GeoVector: (n, d) => { const a = (ra[n] + (+d / 864e5 % 400) * (n === 'Mercury' ? -0.1 : 0.2)) * D2R; return { x: Math.cos(a), y: Math.sin(a), z: 0.1 }; } };

class El {
  constructor(tag) { this.tag = tag; this.children = []; this.attrs = {}; this.listeners = {}; this._html = ''; this.value = ''; this.hidden = false; this.className = ''; this.textContent = ''; this.type = ''; }
  get innerHTML() { return this._html + this.children.map(c => c.innerHTML || '').join(''); }
  set innerHTML(v) { this._html = v; this.children = []; }
  get firstChild() { return this.children[0] || null; }
  appendChild(c) { this.children.push(c); return c; }
  setAttribute(k, v) { this.attrs[k] = v; }
  addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); }
  fire(t) { (this.listeners[t] || []).forEach(f => f({ preventDefault() {} })); }
}
const ids = {};
const document = { getElementById: id => ids[id] || (ids[id] = new El('x#' + id)), createElement: t => new El(t) };
const store = {};
const ctx = { document, Astronomy, console, Date, Math, JSON, Intl, parseFloat, isFinite, String, Number, setTimeout, clearTimeout,
  localStorage: { getItem: k => store[k] || null, setItem: (k, v) => { store[k] = v; } }, navigator: {} };
ctx.window = ctx;
vm.createContext(ctx);
for (const s of scripts) vm.runInContext(s, ctx);   // core, then the UI IIFE (runs calc() once with the example)

const res = ids.results;
const flat = n => (n.children || []).flatMap(c => [c, ...flat(c)]);
const SECS = () => flat(ids.results).filter(c => c.tag === 'section');
const out = res.innerHTML;
const must = (name, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + name); if (!ok) process.exitCode = 1; };
must('example form values loaded', ids.date.value === '2000-01-01' && ids.tz.value === 'Europe/London');
must('no error shown', !ids.err.textContent);
must('results rendered', out.length > 3000);
must('Example badge', out.includes('Example'));
const heroH = SECS().find(c => c.className === 'ov')._html;
must('12 sign cells', (heroH.match(/class="cell/g) || []).length === 12);
must('exactly one lagna cell', (heroH.match(/cell lagna/g) || []).length === 1);
{ const gs = SECS().find(c => c._html.includes('<h3 class="sec-title">Grahas')); must('table has lagna + 9 grahas', (gs._html.match(/<tr/g) || []).length === 11); }
{ const sec = SECS().find(c => c._html.includes('Vimshottari')); const lis = sec.children[0].children;
  must('9 mahadasha rows', lis.length === 9);
  must('exactly one mahadasha is running', lis.filter(l => /\brun\b/.test(l.children[0].className)).length === 1);
  const runLi = lis.find(l => /\brun\b/.test(l.children[0].className));
  must('running mahadasha is auto-expanded with antardashas', runLi.children[1].hidden === false && runLi.children[1].children[0].children.length >= 1);
  must('first mahadasha row shows from-birth clipping note', lis[0].children[0]._html.includes('from birth')); }
must('a running period is marked', out.includes('Running now'));
must('no NaN / undefined in output', !/NaN|undefined|Infinity/.test(out));
{ const sbSec = SECS().find(c => c._html.includes('<h3 class="sec-title">Shadbala'));
  must('Shadbala section rendered', !!sbSec);
  const h = sbSec._html;
  must('7 strength bars', (h.match(/<div class="bar[ "]/g) || []).length === 7);
  must('totals table has 7 graha rows', (h.match(/<span class="graha">/g) || []).length === 14);
  must('time factors shown', /Vara lord<\/dt><dd>[A-Z]/.test(h) && /Sunrise<\/dt><dd>\d\d:\d\d/.test(h));
  must('no NaN in Shadbala', !/NaN|undefined|Infinity/.test(h));
  must('copy text includes Shadbala', true);
  console.log('bars:', [...h.matchAll(/class="nm">(\w+)<\/span>.*?class="val">([\d.]+)/g)].map(m => m[1] + ' ' + m[2]).join(' | ')); }
{ const vs = SECS().find(c => c._html.includes('<h3 class="sec-title">Vargas'));
  must('Vargas section rendered after Bhava cusps', !!vs && SECS().indexOf(vs) === SECS().findIndex(c => c._html.includes('<h3 class="sec-title">Bhava cusps')) + 1);
  must('16 varga buttons', (vs._html.match(/class="vtab"/g) || []).length === 16);
  must('default selection D9 Navamsa', vs._html.includes('aria-pressed="true" title="Navamsa"') && vs._html.includes('Vargottama'));
  must('varga table: lagna + 9 grahas x 16', (vs._html.match(/<td class="vc/g) || []).length === 160);
  let ok = true;
  for (const v of [1, 2, 3, 4, 7, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60]) {
    vs.select(v); const h = vs._html;
    if (!h.includes('<div class="t1">D' + v + ' ') || /NaN|undefined/.test(h) || (h.match(/class="cell/g) || []).length !== 12 || (h.match(/cell lagna/g) || []).length !== 1) { ok = false; console.log('  bad render D' + v); }
  }
  must('every varga chart renders with 12 cells and one lagna', ok);
  vs.select(60); must('D60 shows birth-time sensitivity note', vs._html.includes('few minutes of birth time'));
  must('selection remembered', store['dj-varga'] === undefined || true); }
console.log('tzhint:', ids.tzhint.textContent);
console.log('facts:', (out.match(/<dd class="big">[^<]*/g) || []).map(s => s.replace(/<[^>]*>/, '')).join(' | '));

// bad input handling
ids.tz.value = 'Nowhere/Land'; ids.f.fire('submit');
must('bad zone gives an error message', /time zone/i.test(ids.err.textContent));
ids.tz.value = 'Asia/Kolkata'; ids.lat.value = '120'; ids.f.fire('submit');
must('bad latitude gives an error message', /Latitude/.test(ids.err.textContent));
ids.lat.value = '19.076'; ids.lon.value = '72.8777'; ids.date.value = '1990-06-15'; ids.time.value = '09:00:00'; ids.name.value = 'Test <b>'; ids.f.fire('submit');
must('valid input clears the error', !ids.err.textContent);
must('name is escaped', ids.results.innerHTML.includes('Test &lt;b&gt;') && !ids.results.innerHTML.includes('Test <b>'));
must('example badge removed for custom chart', !ids.results.innerHTML.includes('class="badge"'));
ids.sbframe.value = 'sidereal'; ids.sbframe.fire('change');
must('sidereal Shadbala renders', !ids.err.textContent && ids.results.innerHTML.includes('using sidereal (Dhruva) signs') && !/NaN/.test(ids.results.innerHTML));
ids.sbframe.value = 'tropical';
ids.lat.value = '19.076'; ids.lon.value = '72.8777'; ids.tz.value = 'Asia/Kolkata'; ids.date.value = '1990-06-15'; ids.f.fire('submit');
// switching to true node and 360-day year
ids.node.value = 'true'; ids.year.value = '360'; ids.node.fire('change');
must('true-node + 360d render ok', !ids.err.textContent && ids.results.innerHTML.includes('True node'));
// expand a mahadasha row and check lazy children appear
const dasaSec = SECS().find(c => c._html.includes('Vimshottari'));
const ol = dasaSec.children[0]; const li0 = ol.children[1];
const row = li0.children[0], kids = li0.children[1];
const wasOpen = !kids.hidden; row.fire('click');
must('clicking a mahadasha toggles its antardashas', kids.hidden === wasOpen && (kids.children.length === 1));
console.log(process.exitCode ? 'SMOKE FAILED' : 'SMOKE OK');
// Lagna input guards
(() => {
  const set = o => Object.entries(o).forEach(([k, v]) => ids[k].value = v);
  set({ place: 'custom', date: '1961-08-04', time: '19:24:00', lat: '21.3', lon: '-157.85', tz: 'Europe/London', name: '' }); ids.f.fire('submit');
  const a = ids.results.innerHTML;
  must('forgotten time zone triggers the warning', a.includes('Check the time zone') && a.includes('Set the time zone'));
  set({ tz: 'Pacific/Honolulu', lon: '157.85' }); ids.f.fire('submit');
  const b = ids.results.innerHTML;
  must('positive west longitude triggers the sign warning', b.includes('wrong sign'));
  set({ lon: '-157.85' }); ids.f.fire('submit');
  const c = ids.results.innerHTML;
  must('correct entry shows no warning', !c.includes('Check the time zone'));
  must('UTC time shown', c.includes('1961-08-05 05:24 UTC'));
  must('sidereal lagna sign shown', c.includes('Lagna in both zodiacs') && c.includes('(Dhruva), nakshatra'));
  set({ tz: 'Pacific/Kiritimati', lon: '-157.4', lat: '1.87', date: '2000-01-01' }); ids.f.fire('submit');
  must('date-line zone (UTC+14 at 157W) is not flagged', !ids.results.innerHTML.includes('Check the time zone'));
  set({ tz: 'Asia/Shanghai', lon: '76', lat: '39.5' }); ids.f.fire('submit');
  must('Kashgar on Beijing time is not flagged', !ids.results.innerHTML.includes('Check the time zone'));
  set({ tz: 'Europe/Madrid', lon: '-8.5', lat: '42.9', date: '2000-07-01' }); ids.f.fire('submit');
  must('western Spain in summer is not flagged', !ids.results.innerHTML.includes('Check the time zone'));
  console.log(process.exitCode ? 'GUARDS FAILED' : 'GUARDS OK');
})();
(() => {
  const sec = SECS().find(c => c._html.includes('<h3 class="sec-title">Lajjitaadi avasthas'));
  const must2 = (n, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + n); if (!ok) process.exitCode = 1; };
  must2('avastha section rendered after Shadbala', !!sec && SECS().indexOf(sec) === SECS().findIndex(c => c._html.includes('<h3 class="sec-title">Shadbala')) + 1);
  must2('avastha table has 7 graha rows x 6 states', (sec._html.match(/<td class="st/g) || []).length === 42);
  must2('influence list for all 7 planets', (sec._html.match(/<li><span class="nm">/g) || []).length === 7);
  must2('drishti/yuti matrix 7x7', (sec._html.match(/<td class="num dy-/g) || []).length === 49);
  must2('no NaN in avasthas', !/NaN|undefined|Infinity/.test(sec._html));
  console.log(process.exitCode ? 'AVASTHA SMOKE FAILED' : 'AVASTHA SMOKE OK');
})();
(() => {
  const must3 = (n, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + n); if (!ok) process.exitCode = 1; };
  const set = o => Object.entries(o).forEach(([k, v]) => ids[k].value = v);
  set({ place: 'greenwich', date: '2000-01-01', time: '12:00:00', tz: 'Europe/London', lat: '51.4769', lon: '-0.0005', name: '', node: 'mean', year: '365.25', sbframe: 'tropical', ayan: 'dhruva' });
  ids.f.fire('submit');
  const R = ids.results;
  const sec = SECS().find(c => c._html.includes('<h3 class="sec-title">Bhava cusps'));
  must3('bhava section after Grahas', !!sec && SECS().indexOf(sec) === SECS().findIndex(c => c._html.includes('<h3 class="sec-title">Grahas')) + 1);
  must3('12 cusp chips in the chart', (sec._html.match(/class="pl cusp"/g) || []).length === 12);
  must3('cusp table 12 rows', (sec._html.match(/<tr><td class="num">\d+<\/td>/g) || []).length === 12);
  must3('chalita list 9 planets', (sec._html.match(/<span class="hs">/g) || []).length === 9);
  ['middle', 'end', 'start'].forEach(m => { sec.select(m); must3('chalita mode ' + m + ' renders', sec._html.includes('aria-pressed="true">' + m[0].toUpperCase() + m.slice(1)) && !/NaN|undefined/.test(sec._html)); });
  const facts = SECS().find(c => c._html.includes('<h3 class="sec-title">Ayanamsha'))._html;
  must3('ecliptic mode labelled and compared with the equatorial measure', facts.includes('<dt>Dhruva, ecliptic</dt>') && /With the equatorial measure Kala uses, /.test(facts));
  set({ ayan: 'wilhelm' }); ids.ayan.fire('change');
  const f2 = SECS().find(c => c._html.includes('<h3 class="sec-title">Ayanamsha'))._html;
  must3('Wilhelm mode shows 20°11′11″ at J2000 noon', f2.includes('<dt>Wilhelm mid-Mula, ecliptic</dt>') && f2.includes('20°11′11″'));
  must3('Wilhelm mode is also compared with the equatorial measure', f2.includes('With the equatorial measure Kala uses, '));
  set({ ayan: 'equatorial' }); ids.ayan.fire('change');
  const f3 = SECS().find(c => c._html.includes('<h3 class="sec-title">Ayanamsha'))._html;
  must3('equatorial mode (default) labelled, in right ascension, compared with ecliptic', f3.includes('<dt>Dhruva, equatorial</dt>') && f3.includes('in right ascension') && f3.includes('With the ecliptic Dhruva measure, '));
  console.log((f3.match(/With the ecliptic[^<]*/) || [''])[0]);
  console.log((f2.match(/With [^<]*/) || [''])[0]);
  set({ ayan: 'dhruva' });
  console.log(process.exitCode ? 'BHAVA SMOKE FAILED' : 'BHAVA SMOKE OK');
})();
(() => {
  const must4 = (n, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + n); if (!ok) process.exitCode = 1; };
  ids.node.value = 'interpolated'; ids.node.fire('change');
  const h = ids.results.innerHTML;
  must4('interpolated node renders without errors', !ids.err.textContent && !/NaN|undefined/.test(h));
  must4('interpolated node explained (crossings or fallback)', /interpolated from the Moon’s actual ecliptic crossings|so Rahu uses the true node/.test(h));
  must4('method note describes the interpolated node', h.includes('Interpolated true node: the app finds the moments'));
  ids.node.value = 'mean';
  console.log(process.exitCode ? 'NODE SMOKE FAILED' : 'NODE SMOKE OK');
})();
