/* Swiss Ephemeris adapter for core.js.

   core.js asks for one thing: getVector(bodyName, Date) -> {x, y, z}, the body's geocentric position in the
   J2000 mean-equator frame, in AU, corrected for light-time and aberration (what Astronomy Engine returns from
   GeoVector(name, date, true)). This file produces the same vector from Swiss Ephemeris, so nothing else in
   core.js changes:

       const createCore = require('./core.js');
       const { createSwissVector } = require('./engine-swisseph.js');
       const Core = createCore(createSwissVector(swe));

   `swe` is a thin object you build around whichever Swiss Ephemeris binding you install (for example the `sweph`
   native addon on the server, or a WebAssembly build in the browser). It needs exactly one method:

       swe.calcUt(jdUt, bodyNumber, flags) -> [x, y, z]      // swe_calc_ut; throw on error

   and one property, `swe.usedFlags` (optional): the flag word swe_calc_ut returned for the last call, so the
   adapter can detect a silent fall-back to the built-in Moshier ephemeris when the .se1 data files are missing.

   NOT YET RUN: this adapter was written against the Swiss Ephemeris C interface without access to the library.
   test-engine.js must pass before it is trusted.

   Licence: Swiss Ephemeris is used under the AGPL-3.0, so this whole project is released under the AGPL-3.0. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SwissEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Swiss Ephemeris body numbers and flag bits (swephexp.h)
  var BODY = { Sun: 0, Moon: 1, Mercury: 2, Venus: 3, Mars: 4, Jupiter: 5, Saturn: 6, Uranus: 7, Neptune: 8, Pluto: 9 };
  var SEFLG_SWIEPH = 2, SEFLG_MOSEPH = 4, SEFLG_J2000 = 32, SEFLG_NONUT = 64, SEFLG_EQUATORIAL = 2048, SEFLG_XYZ = 4096;
  /* Apparent position (light-time, aberration and light deflection applied by default), but expressed in the
     J2000 equator with no precession or nutation, as rectangular coordinates. */
  var FLAGS = SEFLG_SWIEPH | SEFLG_J2000 | SEFLG_NONUT | SEFLG_EQUATORIAL | SEFLG_XYZ;

  function julianDayUt(date) { return date.getTime() / 86400000 + 2440587.5; }

  function createSwissVector(swe, opts) {
    opts = opts || {};
    var allowMoshier = !!opts.allowMoshier, warned = false;
    return function getVector(name, date) {
      var body = BODY[name];
      if (body === undefined) throw new Error('Swiss Ephemeris adapter: unknown body ' + name);
      var v = swe.calcUt(julianDayUt(date), body, FLAGS);
      if (!v || !isFinite(v[0]) || !isFinite(v[1]) || !isFinite(v[2])) throw new Error('Swiss Ephemeris returned no position for ' + name);
      if (typeof swe.usedFlags === 'number' && (swe.usedFlags & SEFLG_MOSEPH) && !(swe.usedFlags & SEFLG_SWIEPH)) {
        if (!allowMoshier) throw new Error('Swiss Ephemeris fell back to Moshier: the .se1 data files (sepl_18.se1, semo_18.se1) were not found');
        if (!warned && typeof console !== 'undefined') { warned = true; console.warn('Swiss Ephemeris is using the built-in Moshier ephemeris'); }
      }
      return { x: v[0], y: v[1], z: v[2] };
    };
  }
  return { createSwissVector: createSwissVector, julianDayUt: julianDayUt, BODY: BODY, FLAGS: FLAGS };
});
