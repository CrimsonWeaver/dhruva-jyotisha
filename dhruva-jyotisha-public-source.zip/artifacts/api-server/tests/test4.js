const C = require('./core.js')(() => ({ x: 1, y: 0, z: 0 }));
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const near = (a, b) => Math.abs(a - b) < 1e-6;
const SBT = { Sun: 400, Moon: 300, Mars: 350, Mercury: 420, Jupiter: 450, Venus: 330, Saturn: 360 };
const IDS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
// Defaults park every body somewhere harmless; tests override what they need.
function run(pos, o) {
  o = o || {};
  const def = { Sun: 255, Moon: 75, Mars: 165, Mercury: 255 + 15, Jupiter: 345, Venus: 105, Saturn: 15, Rahu: 52, Ketu: 232 };
  const p = Object.assign({}, def, pos);
  const ch = { asc: { trop: o.asc || 0, sid: ((o.asc || 0) - 20 + 360) % 360 }, bodies: IDS.map(id => ({ id, trop: p[id], sid: (p[id] - 20 + 360) % 360 })) };
  // Only bodies placed by the test carry Shadbala; parked ones weigh 0 and cannot influence anything.
  const sb = { planets: Object.keys(SBT).map(id => ({ id, total: (id in pos || (o.keep || []).includes(id)) ? SBT[id] : 0 })), waxing: o.waxing !== false };
  return C.avasthas(ch, sb, 'tropical');
}
const P = (r, id) => r.planets.find(p => p.id === id);
const inf = (r, id, st, from) => P(r, id).influences.filter(i => i.state === st && (!from || i.from === from));

// --- sphuta drishti table
[['Sun', 180, 60], ['Sun', 90, 45], ['Sun', 30, 0], ['Sun', 300, 0], ['Mars', 90, 60], ['Mars', 210, 60], ['Mars', 120, 30], ['Mars', 180, 60],
 ['Jupiter', 120, 60], ['Jupiter', 240, 60], ['Jupiter', 150, 0], ['Saturn', 60, 60], ['Saturn', 270, 60], ['Saturn', 299, 45.5], ['Saturn', 300, 0], ['Venus', 120, 30]]
  .forEach(([f, d, w]) => ok('drishti ' + f + ' at ' + d + '° = ' + w, near(C.sphutaDrishti(f, d), w), 'got ' + C.sphutaDrishti(f, d)));

// --- Kshudhita
let r = run({ Mars: 100, Saturn: 110, Moon: 75 });
ok('Saturn conjunction starves Mars by Saturn\'s full Shadbala', inf(r, 'Mars', 'kshudhita', 'Saturn').length === 1 && near(inf(r, 'Mars', 'kshudhita', 'Saturn')[0].amount, 360));
ok('Mars in Cancer: rasi lord Moon is a friend, so delighted by 300', near(inf(r, 'Mars', 'mudita', 'Moon')[0].amount, 300) && inf(r, 'Mars', 'mudita', 'Moon')[0].how === 'rasi');
ok('Mars starved value = 350 - 360 = -10, devastating', near(P(r, 'Mars').states.kshudhita.value, -10) && P(r, 'Mars').states.kshudhita.grade === 'devastating');
r = run({ Mercury: 190, Moon: 10 });
ok('enemy aspect: Moon opposite Mercury starves Mercury by 300', inf(r, 'Mercury', 'kshudhita', 'Moon').length === 1 && near(inf(r, 'Mercury', 'kshudhita', 'Moon')[0].amount, 300));
ok('the Moon has no enemies: Mercury\'s aspect does not starve the Moon', inf(r, 'Moon', 'kshudhita').length === 0);
ok('...but delights it (Mercury is the Moon\'s friend)', inf(r, 'Moon', 'mudita', 'Mercury').length === 1);
r = run({ Venus: 125, Sun: 100 });
ok('Venus in Leo is starved by its enemy rasi lord, the Sun', inf(r, 'Venus', 'kshudhita', 'Sun').some(i => i.how === 'rasi' && near(i.amount, 400)));

// --- Sun conjunction: agitation, counted once
r = run({ Venus: 125, Sun: 130 });
ok('Sun with Venus in Leo: agitation from the conjunction', inf(r, 'Venus', 'kshobhita', 'Sun').length === 1);
ok('Sun\'s conjunction is not also counted as starvation (only the rasi lordship)', inf(r, 'Venus', 'kshudhita', 'Sun').length === 1 && inf(r, 'Venus', 'kshudhita', 'Sun')[0].how === 'rasi');
r = run({ Mars: 100, Sun: 105 });
ok('a friend joined by the Sun is agitated, not delighted', inf(r, 'Mars', 'kshobhita', 'Sun').length === 1 && inf(r, 'Mars', 'mudita', 'Sun').length === 0);
ok('...and the Sun is delighted by its friend Mars', inf(r, 'Sun', 'mudita', 'Mars').length === 1);

// --- Jupiter
r = run({ Venus: 200, Jupiter: 205 });
ok('Jupiter delights Venus by conjunction regardless of friendship', inf(r, 'Venus', 'mudita', 'Jupiter').length === 1);
ok('Venus starves Jupiter by conjunction (enemy) and as lord of Libra', inf(r, 'Jupiter', 'kshudhita', 'Venus').map(i => i.how).sort().join() === 'conjunction,rasi');

// --- Saturn never delights except a friendly same-lord join
r = run({ Venus: 280 });
ok('Venus in Saturn\'s Capricorn gets no delight from Saturn as rasi lord', inf(r, 'Venus', 'mudita', 'Saturn').length === 0);
r = run({ Venus: 280, Saturn: 310 });
ok('friendly Saturn by same-lord conjunction delights Venus at half weight', inf(r, 'Venus', 'mudita', 'Saturn').length === 1 && near(inf(r, 'Venus', 'mudita', 'Saturn')[0].amount, 180) && inf(r, 'Venus', 'kshudhita', 'Saturn').length === 0);
r = run({ Mars: 10, Saturn: 220 });
ok('Saturn in Scorpio, Mars in Aries: same-lord join starves Mars at half weight', near(inf(r, 'Mars', 'kshudhita', 'Saturn')[0].amount, 180) && inf(r, 'Mars', 'kshudhita', 'Saturn')[0].how === 'same-lord conjunction');
r = run({ Mercury: 190, Saturn: 10 });
ok('Saturn aspecting a friend gives no delight', inf(r, 'Mercury', 'mudita', 'Saturn').length === 0);

// --- Trishita
r = run({ Mercury: 340, Moon: 160, Jupiter: 220 });
ok('Mercury in Pisces aspected by enemy Moon is thirsty', inf(r, 'Mercury', 'trishita', 'Moon').length === 1);
ok('Jupiter\'s full 9th-house aspect (120° behind... 240° ahead) offsets the thirst', inf(r, 'Mercury', 'trishita+', 'Jupiter').length === 1 && near(inf(r, 'Mercury', 'trishita+', 'Jupiter')[0].value, 60));
ok('thirst = 420 - 300 + 450 = 570', near(P(r, 'Mercury').states.trishita.value, 570), 'got ' + P(r, 'Mercury').states.trishita.value);
r = run({ Mercury: 190, Moon: 10 });
ok('no thirst outside a water sign', !P(r, 'Mercury').states.trishita);
r = run({ Moon: 100, Mars: 280 });
ok('the Moon is never thirsty', !P(r, 'Moon').states.trishita);

// --- Lajjita
r = run({ Venus: 125, Mars: 130 }, { asc: 0 });
ok('Venus in the 5th with Mars is shamed by Mars', inf(r, 'Venus', 'lajjita', 'Mars').length === 1 && near(P(r, 'Venus').states.lajjita.value, 330 - 350));
r = run({ Jupiter: 200, Rahu: 205, Ketu: 25, Saturn: 208 }, { asc: 0 });
ok('Jupiter joined by Rahu and Saturn (7th house) is shamed by Saturn', inf(r, 'Jupiter', 'lajjita', 'Saturn').length === 1);
r = run({ Moon: 50, Rahu: 55, Ketu: 235 }, { asc: 0 });
ok('a node alone does not shame', !P(r, 'Moon').states.lajjita);
r = run({ Venus: 125, Jupiter: 130 }, { asc: 0 });
ok('the 5th house without Sun, Saturn or Mars is no shame', !P(r, 'Venus').states.lajjita);

// --- Garvita and grades
r = run({ Sun: 10, Mars: 5 + 360 - 360, Mercury: 168 });
ok('Sun in Aries is proud (exalted)', P(r, 'Sun').states.garvita && P(r, 'Sun').states.garvita.reason === 'exalted');
ok('Mars at 5° Aries is proud (moolatrikona)', P(r, 'Mars').states.garvita && P(r, 'Mars').states.garvita.reason === 'moolatrikona');
ok('Mercury at 18° Virgo is proud (exalted sign)', P(r, 'Mercury').states.garvita && P(r, 'Mercury').states.garvita.reason === 'exalted');
r = run({ Mars: 5, Saturn: 10 });
ok('pride cushions starvation: Mars -10 + 350 cushion = 340, above its 300 minimum -> mild', P(r, 'Mars').states.kshudhita.grade === 'mild', P(r, 'Mars').states.kshudhita.grade);
r = run({ Mars: 100, Saturn: 110 });
ok('without pride the same -10 is devastating', P(r, 'Mars').states.kshudhita.grade === 'devastating');
r = run({ Mars: 100, Saturn: 280, Moon: 75 });
ok('Saturn\'s aspect does not starve Mars (Mars counts Saturn neutral); only its conjunction would', !P(r, 'Mars').states.kshudhita);
r = run({ Mars: 100, Mercury: 280, Moon: 75 });
ok('enemy Mercury opposite Mars: 350 - 420 = -70 devastating; Moon as rasi lord delights to 650', near(P(r, 'Mars').states.kshudhita.value, -70) && P(r, 'Mars').states.kshudhita.grade === 'devastating' && near(P(r, 'Mars').states.mudita.value, 650));
r = run({ Venus: 310, Sun: 130 });   // Aquarius: no pride, no water sign
ok('Sun opposite Venus (enemy, full 60): 330 - 400 = -70 -> devastating', near(P(r, 'Venus').states.kshudhita.value, -70) && P(r, 'Venus').states.kshudhita.grade === 'devastating');
r = run({ Jupiter: 340, Mercury: 160 });
ok('Jupiter 450 - Mercury 420 = 30: positive but under 390 -> felt', near(P(r, 'Jupiter').states.kshudhita.value, 30) && P(r, 'Jupiter').states.kshudhita.grade === 'felt');

// --- Kshobhita by aspect: Sun, Mars and Saturn all aspect, plus an enemy
r = run({ Venus: 0, Sun: 180, Mars: 270, Saturn: 90, Moon: 185 });
const v = P(r, 'Venus');
ok('Sun, Mars, Saturn all aspect Venus with enemy aspects: agitated by aspect', inf(r, 'Venus', 'kshobhita').length >= 1, v.influences.filter(i => i.state === 'kshobhita').map(i => i.from + ' ' + i.how + ' ' + i.value.toFixed(1)).join(', '));

// --- matrix shape and both directions
r = run({});
ok('7x6 drishti/yuti matrix', Object.keys(r.matrix).length === 7 && Object.values(r.matrix).every(m => Object.keys(m).length === 6));
r = run({ Mars: 0, Mercury: 90 });
ok('directional values differ (Mars on Mercury 60, Mercury on Mars from 270° = 15)', near(r.matrix.Mars.Mercury.value, 60) && near(r.matrix.Mercury.Mars.value, 15), r.matrix.Mars.Mercury.value + ' / ' + r.matrix.Mercury.Mars.value);

r = run({ Venus: 340, Sun: 160 });
ok('the same aspect on exalted Venus in Pisces: pride cushion 330 makes it felt, not devastating', near(P(r, 'Venus').states.kshudhita.value, -70) && P(r, 'Venus').states.kshudhita.grade === 'felt');
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
