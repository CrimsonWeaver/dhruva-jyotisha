/* Run on Replit after installing both libraries:  node test-engine.js
   Checks the Swiss Ephemeris adapter against Astronomy Engine. The two are independent, so agreement within
   Astronomy Engine's stated 1 arcminute proves the adapter's frame, units, time scale and corrections are right.
   Edit makeSwe() to match the Swiss Ephemeris package you installed. */
const Astronomy = require('astronomy-engine');
const createCore = require('./core.js');
const { createSwissVector, julianDayUt, FLAGS } = require('./engine-swisseph.js');
const swephTime = require('sweph');
// Compare independent position models at the same TT. Their default future
// delta-T predictions differ by ~110 seconds in 2100, exceeding the Moon tolerance.
// This does not change production Swiss time conversion or the 60" threshold.
Astronomy.SetDeltaTFunction(ut => swephTime.deltat_ex(ut + 2451545, 2).data * 86400);

function makeSwe() {
  // Example for the `sweph` native addon; adjust names if your binding differs.
  const sweph = require('sweph');
  sweph.set_ephe_path(__dirname + '/../../../generated-artifacts/ephe');
  const swe = { usedFlags: 0, calcUt(jd, body, flags) {
    const r = sweph.calc_ut(jd, body, flags);         // { flag, error, data: [x, y, z, ...] }
    if (r.flag < 0 || r.error && !r.data) throw new Error(r.error || 'swe_calc_ut failed');
    swe.usedFlags = r.flag; return r.data;
  } };
  return swe;
}

let n = 0, bad = 0; const must = (l, ok, x) => { n++; if (!ok) { bad++; console.log('FAIL ' + l, x === undefined ? '' : x); } else console.log('PASS ' + l); };
const swissVector = createSwissVector(makeSwe());
const aeVector = (name, date) => Astronomy.GeoVector(name, date, true);
const sep = (a, b) => { const d = a.x * b.x + a.y * b.y + a.z * b.z, la = Math.hypot(a.x, a.y, a.z), lb = Math.hypot(b.x, b.y, b.z); return Math.acos(Math.max(-1, Math.min(1, d / (la * lb)))) * 180 / Math.PI * 3600; };

must('Julian Day of J2000 noon UT is 2451545.0', Math.abs(julianDayUt(new Date(Date.UTC(2000, 0, 1, 12))) - 2451545) < 1e-9);
const BODIES = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'], worst = {};
for (let y = 1900; y <= 2100; y += 1) for (const mo of [0, 4, 8]) {
  const date = new Date(Date.UTC(y, mo, 1 + (y % 27), (y * 7) % 24, 13));
  for (const b of BODIES) { const s = sep(swissVector(b, date), aeVector(b, date)); if (!(s <= (worst[b] || 0))) worst[b] = s; }
}
for (const b of BODIES) must(b + ': Swiss Ephemeris and Astronomy Engine agree within 60″ over 1900–2100 (worst ' + worst[b].toFixed(2) + '″)', worst[b] < 60, worst[b]);
const length = v => Math.hypot(v.x, v.y, v.z);
must('distances agree (units are AU): Sun within 1e-4 AU', Math.abs(length(swissVector('Sun', new Date(Date.UTC(2000, 0, 1, 12)))) - length(aeVector('Sun', new Date(Date.UTC(2000, 0, 1, 12))))) < 1e-4);

// The whole chart through core.js with each engine: same signs, nakshatras and padas away from boundaries, dasa within days.
const A = createCore(aeVector), S = createCore(swissVector);
for (const C of [A, S]) C.setAyanamsaMode('lahiri');
const o = { ms: Date.UTC(1990, 5, 15, 3, 0), lat: 28.6139, lon: 77.209, nodeType: 'mean' };
const ca = A.chart(o), cs = S.chart(o);
must('ascendant identical (it does not use the ephemeris)', Math.abs(ca.asc.trop - cs.asc.trop) < 1e-9);
ca.bodies.forEach((b, i) => { const d = Math.abs(((b.trop - cs.bodies[i].trop + 540) % 360) - 180) * 3600; must(b.id + ' longitude differs by ' + d.toFixed(2) + '″ (< 60″)', d < 60, d); });
const moon = c => c.bodies.find(b => b.id === 'Moon').sid, YR = 365.25 * 864e5;
const da = A.buildDasa(moon(ca), o.ms, YR), ds = S.buildDasa(moon(cs), o.ms, YR);
must('same birth dasa lord', da.lord === ds.lord, da.lord + ' / ' + ds.lord);
const shift = Math.abs(da.periods[1].fullStart - ds.periods[1].fullStart) / 864e5;
must('dasa dates move by ' + shift.toFixed(2) + ' days (< 10)', shift < 10, shift);
console.log('\nWorst separations, arcseconds:', JSON.stringify(worst));
console.log(bad ? 'FAILED ' + bad : 'ENGINE OK (' + n + ')'); process.exit(bad ? 1 : 0);
