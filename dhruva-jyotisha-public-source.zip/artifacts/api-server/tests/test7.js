// Regression against the user's Vault of the Heavens (Kala) printout: equatorial Dhruva must reproduce its table.
const C = require('./core.js')(() => ({ x: 1, y: 0, z: 0 }));
const D2R = Math.PI / 180, norm = a => ((a % 360) + 360) % 360;
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const ORDER = ['Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury'], AB = { Ketu: 'Ke', Venus: 'Ve', Sun: 'Su', Moon: 'Mo', Mars: 'Ma', Rahu: 'Ra', Jupiter: 'Ju', Saturn: 'Sa', Mercury: 'Me' };
function sub(sid) { const k = C.nakshatraOf(sid), span = 360 / 27, into = sid - k.index * span; let acc = 0, s = ORDER.indexOf(k.lord);
  for (let j = 0; j < 9; j++) { const L = ORDER[(s + j) % 9], w = C.DASA_YEARS[L] / 120 * span; if (into < acc + w) return AB[L]; acc += w; } }
const ms = Date.UTC(2000, 0, 21, 14);
const rows = [   // [label, tropical lon, ecliptic lat, VOTH nakshatra, pada, star lord, sub lord, isEclipticPoint]
  ['Asc', 68 + 52 / 60, 0, 'Rohini', 3, 'Mo', 'Me', true], ['Sun', 300 + 49 / 60, 0, 'Shravana', 1, 'Mo', 'Ra'],
  ['Moon', 126.1, 5.145 * Math.sin((126.1 - 123.683) * D2R), 'Ashlesha', 1, 'Me', 'Ke'], ['Mars', 343.5, 0, 'Purva Bhadrapada', 2, 'Ju', 'Me'],
  ['Mercury', 304 + 28 / 60, 0, 'Shravana', 3, 'Mo', 'Sa'], ['Jupiter', 26 + 43 / 60, 0, 'Ashwini', 2, 'Ke', 'Ma'],
  ['Venus', 266, 0, 'Mula', 2, 'Ke', 'Ra'], ['Saturn', 40 + 22 / 60, 0, 'Bharani', 2, 'Ve', 'Ra'],
  ['Rahu', 123 + 41 / 60, 0, 'Pushya', 4, 'Sa', 'Ju'], ['Ketu', 303 + 41 / 60, 0, 'Shravana', 2, 'Mo', 'Sa']];
const off = C.equatorialOffset(ms);
ok('equatorial offset near 19°45′ in January 2000', Math.abs(off - 19.747) < 0.01, off.toFixed(4) + '°');
let hits = 0;
for (const r of rows) {
  const sid = r[7] ? norm(r[1] - C.dhruvaAyanamsa(ms, 'equatorial').ayanamsa) : C.siderealOf(r[1], r[2], ms, 'equatorial');
  const k = C.nakshatraOf(sid), s = sub(sid), good = k.name === r[3] && k.pada === r[4] && AB[k.lord] === r[5] && s === r[6];
  if (good) hits++;
  ok(r[0] + ' → ' + k.name + ' ' + k.pada + ' ' + AB[k.lord] + '/' + s, good, good ? '' : 'VOTH ' + r[3] + ' ' + r[4] + ' ' + r[5] + '/' + r[6]);
}
ok('all 10 VOTH rows reproduced', hits === 10);
const moon = C.siderealOf(rows[2][1], rows[2][2], ms, 'equatorial'), d = C.buildDasa(moon, ms, 365.25 * 864e5);
const ve = d.periods.find(p => p.lord === 'Venus');
ok('Venus mahadasha begins in 2021, within a month of VOTH 2021-04-28', Math.abs(ve.fullStart - Date.UTC(2021, 3, 28)) < 31 * 864e5, new Date(ve.fullStart).toISOString().slice(0, 10));
// identities
ok('ecliptic modes unchanged: siderealOf = tropical - ayanamsa', Math.abs(C.siderealOf(123.4, 2, ms, 'dhruva') - norm(123.4 - C.dhruvaAyanamsa(ms, 'dhruva').ayanamsa)) < 1e-12);
ok('equinox and solstice points: RA equals ecliptic longitude', [0, 90, 180, 270].every(l => Math.abs(norm(C.siderealOf(l, 0, ms, 'equatorial') + off - l + 180) - 180) < 1e-9));
ok('Galactic Center itself lands exactly at 6°40′ Sagittarius', (() => { const g = C.eqjToTrueEcliptic(C.GC.ra, C.GC.dec, C.tOf(ms)); return Math.abs(C.siderealOf(g.lon, g.lat, ms, 'equatorial') - (246 + 40 / 60)) < 1e-9; })());
C.setAyanamsaMode('equatorial'); const mode = C.dhruvaAyanamsa(ms).mode; C.setAyanamsaMode('dhruva');
ok('mode can be selected globally', mode === 'equatorial');
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
