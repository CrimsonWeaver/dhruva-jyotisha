const createCore = require('./core.js');
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
let fails = 0;
const norm = a => ((a % 360) + 360) % 360;
function check(name, got, want, tol) { const ok = Math.abs(got - want) <= tol; if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + name + '  got=' + (+got).toFixed(4) + '  want=' + want + '  tol=' + tol); }
function truthy(name, cond, extra) { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); }
const hhmm = ms => new Date(ms).toISOString().slice(11, 16);

/* ---- Mock ephemeris: Meeus Sun, truncated Moon, circular-orbit planets; ecliptic-of-date -> EQJ by inverting the core's own transform ---- */
const base = createCore(() => ({ x: 1, y: 0, z: 0 }));
function basis(T) {
  const cols = [[0, 0], [90, 0], [0, 90]].map(([ra, dec]) => { const e = base.eqjToTrueEcliptic(ra, dec, T); const l = e.lon * D2R, b = e.lat * D2R; return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)]; });
  return cols;
}
const sin = a => Math.sin(a * D2R), cos = a => Math.cos(a * D2R);
const MEAN_L = { Mercury: [252.250906, 149474.0722491, 0.387], Venus: [181.979801, 58519.2130302, 0.723], Mars: [355.433275, 19141.6964746, 1.524], Jupiter: [34.351484, 3036.3027889, 5.203], Saturn: [50.077471, 1223.5110141, 9.537] };
function sunApparent(T) {
  const L0 = 280.46646 + 36000.76983 * T, M = 357.52911 + 35999.05029 * T;
  const C = (1.914602 - 0.004817 * T) * sin(M) + 0.019993 * sin(2 * M) + 0.000289 * sin(3 * M);
  return norm(L0 + C - 0.00569 - 0.00478 * sin(125.04 - 1934.136 * T));
}
function eclPos(name, T) {
  if (name === 'Sun') return { lon: sunApparent(T), lat: 0 };
  if (name === 'Moon') {
    const Lp = 218.3164477 + 481267.88123421 * T, D = 297.8501921 + 445267.1114034 * T, M = 357.5291092 + 35999.0502909 * T, Mp = 134.9633964 + 477198.8675055 * T, F = 93.272095 + 483202.0175233 * T;
    return { lon: norm(Lp + 6.289 * sin(Mp) + 1.274 * sin(2 * D - Mp) + 0.658 * sin(2 * D) + 0.214 * sin(2 * Mp) - 0.186 * sin(M) - 0.114 * sin(2 * F)), lat: 5.128 * sin(F) };
  }
  const [l0, rate, a] = MEAN_L[name];
  const L = (l0 + rate * T) * D2R, Le = (280.4664567 + 36000.76983 * T + 180) * D2R;
  const x = a * Math.cos(L) - Math.cos(Le), y = a * Math.sin(L) - Math.sin(Le);
  return { lon: norm(Math.atan2(y, x) * R2D), lat: 0 };
}
function mockVec(name, date) {
  const ms = +date, T = (ms / 86400000 + 2440587.5 - 2451545) / 36525;
  const p = eclPos(name, T), l = p.lon * D2R, b = p.lat * D2R;
  const e = [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
  const c = basis(T); const dot = (u, v) => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  return { x: dot(c[0], e), y: dot(c[1], e), z: dot(c[2], e) };
}
const C = createCore(mockVec);

/* ---- 1. Sunrise / sunset against published times (upper limb, standard refraction) ---- */
{
  const ev = C.sunEvents(Date.UTC(2000, 0, 1, 12), 51.4769, -0.0005);
  const sr = ev.rises.find(t => t > Date.UTC(2000, 0, 1, 0)), ss = ev.sets.find(t => t > sr);
  console.log('Greenwich 2000-01-01  sunrise', hhmm(sr), 'sunset', hhmm(ss));
  check('Greenwich sunrise 08:06 UT (min)', (sr - Date.UTC(2000, 0, 1, 8, 6)) / 60000, 0, 4);
  check('Greenwich sunset 16:01 UT (min)', (ss - Date.UTC(2000, 0, 1, 16, 1)) / 60000, 0, 4);
  const ny = C.sunEvents(Date.UTC(2026, 5, 21, 15), 40.7128, -74.0060);
  const a = ny.rises.find(t => t > Date.UTC(2026, 5, 21, 0)), b = ny.sets.find(t => t > a);
  console.log('New York 2026-06-21   sunrise', hhmm(a), 'sunset', hhmm(b), '(UTC)');
  check('NYC solstice sunrise 05:25 EDT = 09:25 UT (min)', (a - Date.UTC(2026, 5, 21, 9, 25)) / 60000, 0, 5);
  check('NYC solstice sunset 20:31 EDT = 00:31 UT (min)', (b - Date.UTC(2026, 5, 22, 0, 31)) / 60000, 0, 5);
  const eq = C.sunEvents(Date.UTC(2000, 2, 20, 12), 0, 0);
  const e1 = eq.rises.find(t => t > Date.UTC(2000, 2, 20, 0)), e2 = eq.sets.find(t => t > e1);
  check('equator equinox day length (h)', (e2 - e1) / 3600000, 12.12, 0.06);
}

/* ---- 2. Hindu day: weekday lords, hora, tribhaga, natonnata ---- */
{
  const noon = C.timeFactors(Date.UTC(2000, 0, 1, 12), 51.4769, -0.0005, 'tropical');
  truthy('2000-01-01 noon is Saturday: vara Saturn', noon.varaLord === 'Saturn', noon.varaLord);
  truthy('noon hora is the Sun (Saturn, Jupiter, Mars, Sun)', noon.horaLord === 'Sun' && noon.horaNumber === 4, noon.horaLord + ' #' + noon.horaNumber);
  truthy('2nd third of the day -> Sun', noon.tribhagaLord === 'Sun' && noon.isDay, noon.tribhagaLord);
  const pre = C.timeFactors(Date.UTC(2000, 0, 1, 6, 0), 51.4769, -0.0005, 'tropical');
  truthy('06:00 before sunrise still belongs to Friday: Venus', pre.varaLord === 'Venus', pre.varaLord);
  truthy('before sunrise it is night, hora counted from previous sunrise', pre.isDay === false, 'hora #' + pre.horaNumber);
  const wed = C.timeFactors(Date.UTC(2026, 9, 28, 20, 0), 40.7128, -74.006, 'tropical');
  truthy('2026-10-28 afternoon is Wednesday: Mercury', wed.varaLord === 'Mercury', wed.varaLord);
  check('weekday index for 2000-01-01 (Saturday=6)', C.hinduDay(Date.UTC(2000, 0, 1, 12), 51.4769, -0.0005).weekday, 6, 0);
  const nm = (noon.sunrise + noon.sunset) / 2;
  const atNoon = C.timeFactors(nm, 51.4769, -0.0005, 'tropical');
  check('hours from noon at solar noon', atNoon.hoursFromNoon, 0, 0.01);
  const atMid = C.timeFactors(nm + 12 * 3600000, 51.4769, -0.0005, 'tropical');
  check('hours from noon at midnight', atMid.hoursFromNoon, 12, 0.05);
  // year and month lords: ingress dates known independently
  const y0 = C.lastIngress(Date.UTC(2000, 0, 1, 12), 0, 'tropical'), m0 = C.lastIngress(Date.UTC(2000, 0, 1, 12), 270, 'tropical');
  console.log('last equinox', new Date(y0).toISOString(), ' last solstice', new Date(m0).toISOString());
  check('vernal equinox 1999 = Mar 21 01:46 UT (min)', (y0 - Date.UTC(1999, 2, 21, 1, 46)) / 60000, 0, 20);
  check('winter solstice 1999 = Dec 22 07:44 UT (min)', (m0 - Date.UTC(1999, 11, 22, 7, 44)) / 60000, 0, 20);
  truthy('year lord: equinox is before sunrise on Sunday, so the Hindu day is Saturday -> Saturn', noon.yearLord === 'Saturn', noon.yearLord);
  truthy('month lord: solstice is before sunrise on Wednesday, so Tuesday -> Mars', noon.monthLord === 'Mars', noon.monthLord);
  const sid = C.timeFactors(Date.UTC(2000, 0, 1, 12), 51.4769, -0.0005, 'sidereal');
  truthy('sidereal frame finds its own ingress (about 20 days later than tropical)', sid.yearStart > y0 + 15 * 864e5 && sid.yearStart < y0 + 25 * 864e5, new Date(sid.yearStart).toISOString().slice(0, 10));
}

/* ---- 3. Varga sign tables (hand-checked) ---- */
{
  const v = (sign, deg) => C.vargaSigns(sign * 30 + deg);
  const S = ['Ari', 'Tau', 'Gem', 'Can', 'Leo', 'Vir', 'Lib', 'Sco', 'Sag', 'Cap', 'Aqu', 'Pis'];
  const eq = (name, got, want) => truthy(name + ' = ' + S[want], got === want, 'got ' + S[got]);
  eq('navamsa Aries 0', v(0, 0).d9, 0); eq('navamsa Aries 3.4', v(0, 3.4).d9, 1);
  eq('navamsa Taurus 0 (starts Capricorn)', v(1, 0).d9, 9); eq('navamsa Taurus 15', v(1, 15).d9, 1);
  eq('navamsa Gemini 0 (starts Libra)', v(2, 0).d9, 6); eq('navamsa Cancer 0', v(3, 0).d9, 3); eq('navamsa Leo 0 (starts Aries)', v(4, 0).d9, 0);
  eq('saptamsa Aries 0', v(0, 0).d7, 0); eq('saptamsa Aries 4.4', v(0, 4.4).d7, 1); eq('saptamsa Taurus 0 (starts 7th)', v(1, 0).d7, 7);
  eq('dwadasamsa Aries 2.6', v(0, 2.6).d12, 1); eq('dwadasamsa Leo 0', v(4, 0).d12, 4);
  eq('drekkana Aries 5', v(0, 5).d3, 0); eq('drekkana Aries 12', v(0, 12).d3, 4); eq('drekkana Aries 25', v(0, 25).d3, 8);
  eq('hora Aries 10 (Sun)', v(0, 10).d2, 4); eq('hora Aries 20 (Moon)', v(0, 20).d2, 3);
  eq('hora Taurus 10 (Moon)', v(1, 10).d2, 3); eq('hora Taurus 20 (Sun)', v(1, 20).d2, 4);
  eq('trimsamsa Aries 3 (Mars)', v(0, 3).d30, 0); eq('trimsamsa Aries 7 (Saturn)', v(0, 7).d30, 10); eq('trimsamsa Aries 15 (Jupiter)', v(0, 15).d30, 8);
  eq('trimsamsa Aries 20 (Mercury)', v(0, 20).d30, 2); eq('trimsamsa Aries 27 (Venus)', v(0, 27).d30, 6);
  eq('trimsamsa Taurus 3 (Venus)', v(1, 3).d30, 1); eq('trimsamsa Taurus 8 (Mercury)', v(1, 8).d30, 5); eq('trimsamsa Taurus 15 (Jupiter)', v(1, 15).d30, 11);
  eq('trimsamsa Taurus 22 (Saturn)', v(1, 22).d30, 9); eq('trimsamsa Taurus 28 (Mars)', v(1, 28).d30, 7);
}

/* ---- 4. Relationship points and drishti curve ---- */
check('Sun/Moon temp friend -> great friend', C.relationPoints('Sun', 'Moon', 0, 1), 22.5, 0);
check('Sun/Moon same sign -> neutral', C.relationPoints('Sun', 'Moon', 0, 0), 7.5, 0);
check('Sun/Venus temp friend -> neutral', C.relationPoints('Sun', 'Venus', 0, 2), 7.5, 0);
check('Sun/Venus temp enemy -> great enemy', C.relationPoints('Sun', 'Venus', 0, 0), 1.875, 0);
check('Moon/Mars neutral+friend -> friend', C.relationPoints('Moon', 'Mars', 0, 3), 15, 0);
check('Moon/Mars neutral+enemy -> enemy', C.relationPoints('Moon', 'Mars', 0, 0), 3.75, 0);
check('own sign', C.relationPoints('Mars', 'Mars', 0, 0), 30, 0);
[[0, 0], [30, 0], [45, 7.5], [60, 15], [75, 30], [90, 45], [105, 37.5], [120, 30], [135, 15], [150, 0], [165, 30], [180, 60], [240, 30], [300, 0], [330, 0]]
  .forEach(([d, w]) => check('drishti at ' + d, C.drishtiBase(d), w, 1e-9));
check('cheshta kendra opposition', C.cheshtaKendraFrom(0, 180, 180), 180, 1e-9);
check('cheshta kendra conjunction', C.cheshtaKendraFrom(0, 0, 0), 0, 1e-9);

/* ---- 5. Component values on controlled charts ---- */
function ctl(lons, o) {
  o = o || {};
  const ids = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
  return {
    ayanamsa: 20, asc: { trop: o.asc != null ? o.asc : 0, sid: norm((o.asc || 0) - 20) }, mc: { trop: o.mc != null ? o.mc : 270 },
    bodies: ids.map((id, i) => ({ id: id, trop: norm(lons[id] != null ? lons[id] : 40 + i * 37), sid: norm((lons[id] != null ? lons[id] : 40 + i * 37) - 20), decl: (o.decl && o.decl[id]) || 0, eclLat: 0, speed: 1 }))
  };
}
const NOON = Date.UTC(2000, 0, 1, 12), G = [51.4769, -0.0005];
const S = (lons, o, ms) => C.strength(ctl(lons, o), { ms: ms || NOON, lat: G[0], lon: G[1], frame: 'tropical' });
const P = (res, id) => res.planets.find(p => p.id === id);
{
  const r = S({ Sun: 10, Moon: 33, Venus: 357, Saturn: 200 });
  check('uccha Sun at 10 Aries', P(r, 'Sun').sthana.uccha, 60, 1e-9);
  check('uccha Moon at 3 Taurus', P(r, 'Moon').sthana.uccha, 60, 1e-9);
  check('uccha Venus at 27 Pisces', P(r, 'Venus').sthana.uccha, 60, 1e-9);
  check('uccha Saturn at 20 Libra', P(r, 'Saturn').sthana.uccha, 60, 1e-9);
  const d = S({ Sun: 190, Moon: 213, Venus: 177, Saturn: 20, Mars: 118, Mercury: 345, Jupiter: 275 });
  ['Sun', 'Moon', 'Venus', 'Saturn', 'Mars', 'Mercury', 'Jupiter'].forEach(id => check('uccha ' + id + ' debilitated = 0', P(d, id).sthana.uccha, 0, 1e-9));
  check('uccha halfway (Sun 100)', P(S({ Sun: 100 }), 'Sun').sthana.uccha, 30, 1e-9);
}
{ // Dig bala
  const r = S({ Jupiter: 0, Saturn: 180, Sun: 270, Moon: 90 }, { asc: 0, mc: 270 });
  check('dig Jupiter on the ascendant', P(r, 'Jupiter').dig, 60, 1e-9);
  check('dig Saturn on the descendant', P(r, 'Saturn').dig, 60, 1e-9);
  check('dig Sun on the MC', P(r, 'Sun').dig, 60, 1e-9);
  check('dig Moon on the IC', P(r, 'Moon').dig, 60, 1e-9);
  const w = S({ Jupiter: 180, Saturn: 0, Sun: 90, Moon: 270 }, { asc: 0, mc: 270 });
  check('dig Jupiter on the descendant = 0', P(w, 'Jupiter').dig, 0, 1e-9);
  check('dig Saturn on the ascendant = 0', P(w, 'Saturn').dig, 0, 1e-9);
  check('dig Sun on the IC = 0', P(w, 'Sun').dig, 0, 1e-9);
  check('dig Moon on the MC = 0', P(w, 'Moon').dig, 0, 1e-9);
}
{ // Kendradi, ojhayugma, drekkana
  const r = S({ Sun: 100, Mars: 35, Mercury: 65 }, { asc: 5 });   // Asc Aries
  check('kendra Sun in 4th', P(r, 'Sun').sthana.kendra, 60, 0);
  check('panaphara Mars in 2nd', P(r, 'Mars').sthana.kendra, 30, 0);
  check('apoklima Mercury in 3rd', P(r, 'Mercury').sthana.kendra, 15, 0);
  // Sun at 100 = Cancer 10 (even sign), navamsa of Cancer 10: part 3 -> Cancer+3 = Libra (odd) -> Sun gets 15 for navamsa only
  check('ojhayugma Sun Cancer10', P(r, 'Sun').sthana.ojha, 15, 0);
  const m = S({ Moon: 40 });   // Taurus 10 (even); navamsa part 3 -> Capricorn+3 = Aries (odd) -> 15
  check('ojhayugma Moon Taurus10 (even rasi, odd navamsa)', P(m, 'Moon').sthana.ojha, 15, 0);
  const m2 = S({ Moon: 50 });  // Taurus 20 (even); part 6 -> Capricorn+6 = Cancer (even) -> 30
  check('ojhayugma Moon Taurus20 (even rasi, even navamsa)', P(m2, 'Moon').sthana.ojha, 30, 0);
  const m3 = S({ Sun: 5 });    // Aries 5 (odd); part 1 -> Aries+1 = Taurus (even) -> Sun gets 15 for rasi only
  check('ojhayugma Sun Aries5 (odd rasi, even navamsa)', P(m3, 'Sun').sthana.ojha, 15, 0);
  check('drekkana Sun in first (Leo 5)', P(S({ Sun: 125 }), 'Sun').sthana.drekkana, 15, 0);
  check('drekkana Moon in third (Taurus 25)', P(S({ Moon: 55 }), 'Moon').sthana.drekkana, 15, 0);
  check('drekkana Mercury in second (Gemini 15)', P(S({ Mercury: 75 }), 'Mercury').sthana.drekkana, 15, 0);
  check('drekkana Sun in second = 0', P(S({ Sun: 135 }), 'Sun').sthana.drekkana, 0, 0);
}
{ // Kala: paksha, ayana, naisargika
  const full = S({ Sun: 0, Moon: 180 });
  check('Moon paksha at full (doubled)', P(full, 'Moon').kala.paksha, 120, 1e-9);
  check('Jupiter paksha at full', P(full, 'Jupiter').kala.paksha, 60, 1e-9);
  check('Saturn paksha at full', P(full, 'Saturn').kala.paksha, 0, 1e-9);
  const nw = S({ Sun: 100, Moon: 100 });
  check('Moon paksha at new', P(nw, 'Moon').kala.paksha, 0, 1e-9);
  check('Mars paksha at new', P(nw, 'Mars').kala.paksha, 60, 1e-9);
  const dec = { Sun: 23.45, Moon: -23.45, Mercury: -23.45, Saturn: -23.45, Jupiter: 23.45, Mars: -23.45 };
  const a = S({}, { decl: dec });
  check('Sun ayana at +23.45 (doubled)', P(a, 'Sun').kala.ayana, 120, 1e-9);
  check('Moon ayana at -23.45', P(a, 'Moon').kala.ayana, 60, 1e-9);
  check('Saturn ayana at -23.45', P(a, 'Saturn').kala.ayana, 60, 1e-9);
  check('Mercury ayana at -23.45 (either direction)', P(a, 'Mercury').kala.ayana, 60, 1e-9);
  check('Jupiter ayana at +23.45', P(a, 'Jupiter').kala.ayana, 60, 1e-9);
  check('Mars ayana at -23.45 = 0', P(a, 'Mars').kala.ayana, 0, 1e-9);
  check('Sun cheshta = its ayana bala', P(a, 'Sun').cheshta, 120, 1e-9);
  check('Moon cheshta = its paksha bala', P(a, 'Moon').cheshta, P(a, 'Moon').kala.paksha, 1e-9);
  check('naisargika sum (classical 7 values)', C.SB.reduce((s, id) => s + P(a, id).naisargika, 0), 60 + 51.43 + 17.14 + 25.70 + 34.28 + 42.85 + 8.57, 1e-9);
}
{ // Time-based kala components at noon on 2000-01-01 (Saturday, Sun hora, 2nd third)
  const r = S({});
  check('hora bala goes to the Sun only', C.SB.filter(id => P(r, id).kala.hora === 60).length, 1, 0);
  truthy('Sun holds hora', P(r, 'Sun').kala.hora === 60);
  truthy('Saturn holds vara (45)', P(r, 'Saturn').kala.vara === 45 && C.SB.filter(id => P(r, id).kala.vara > 0).length === 1);
  truthy('Sun holds tribhaga, Jupiter always', P(r, 'Sun').kala.tribhaga === 60 && P(r, 'Jupiter').kala.tribhaga === 60 && P(r, 'Moon').kala.tribhaga === 0);
  truthy('year lord Saturn holds abda 15, month lord Mars holds masa 30', P(r, 'Saturn').kala.abda === 15 && P(r, 'Mars').kala.masa === 30);
  const noon = C.timeFactors(NOON, G[0], G[1], 'tropical'), nm = (noon.sunrise + noon.sunset) / 2;
  const at = S({}, null, nm);
  check('natonnata Sun at solar noon', P(at, 'Sun').kala.nata, 60, 0.1);
  check('natonnata Moon at solar noon', P(at, 'Moon').kala.nata, 0, 0.1);
  check('natonnata Mercury always 60', P(at, 'Mercury').kala.nata, 60, 0);
  const mid = S({}, null, nm + 12 * 3600000);
  check('natonnata Moon at midnight', P(mid, 'Moon').kala.nata, 60, 0.3);
  check('natonnata Sun at midnight', P(mid, 'Sun').kala.nata, 0, 0.3);
}
{ // Drik bala: a lone benefic opposition adds 60/4, a malefic subtracts
  const r = S({ Sun: 10, Moon: 40, Mars: 70, Mercury: 100, Jupiter: 190, Venus: 130, Saturn: 160 });
  const sat = P(r, 'Saturn'); truthy('drik is finite', isFinite(sat.drik));
  const lone = S({ Sun: 0, Moon: 0, Mars: 0, Mercury: 0, Jupiter: 180, Venus: 0, Saturn: 0 });
  // Sun at 0, Jupiter opposite (full 60, benefic). Other planets also at 0 give d=0 -> 0.
  check('Sun gets +15 from Jupiter opposition', P(lone, 'Sun').drik, 15 + (0) , 0.001 + 0);   // Moon waxing? both at 0 -> waxing=false -> malefic but 0 aspect
  const mal = S({ Sun: 0, Moon: 0, Mars: 180, Mercury: 0, Jupiter: 0, Venus: 0, Saturn: 0 });
  check('Sun gets -15 from Mars opposition', P(mal, 'Sun').drik, -15, 0.001);
  // Jupiter special aspect: Jupiter in Aries casting on a planet in Leo (5th) counts full even at a small partial angle
  // Jupiter 120 deg behind the Sun: normal drishti 30 + special 30 = full 60, benefic -> +15; the others sit 25 deg ahead (no aspect)
  const sp = S({ Jupiter: 25, Sun: 145, Moon: 170, Mars: 170, Mercury: 170, Venus: 170, Saturn: 170 });
  check('Jupiter special aspect at 120 deg gives the Sun +15 drik', P(sp, 'Sun').drik, 15, 1e-9);
  const satSp = S({ Saturn: 0, Sun: 270, Moon: 285, Mars: 285, Mercury: 285, Venus: 285, Jupiter: 285 });
  check('Saturn special aspect at 270 deg gives the Sun -15 drik', P(satSp, 'Sun').drik, -15, 1e-9);
}
{ // totals and ratios
  const r = S({});
  r.planets.forEach(p => {
    const sum = p.sthana.total + p.dig + p.kala.total + p.cheshta + p.naisargika + p.drik;
    check('total = six balas (' + p.id + ')', p.total, sum, 1e-9);
    check('ratio (' + p.id + ')', p.ratio, p.total / p.required, 1e-12);
  });
  check('required minimum Sun', P(r, 'Sun').required, 390, 0); check('required Mercury', P(r, 'Mercury').required, 420, 0);
  truthy('ranks are 1..7', r.planets.map(p => p.rank).sort().join('') === '1234567');
}

/* ---- 6. End to end on the mock ephemeris: both zodiacs, several places and dates ---- */
for (const frame of ['tropical', 'sidereal']) {
  for (const [ms, lat, lon] of [[Date.UTC(2000, 0, 1, 12), 51.4769, -0.0005], [Date.UTC(1990, 5, 15, 3, 30), 19.076, 72.8777], [Date.UTC(2026, 9, 28, 20), 40.7128, -74.006], [Date.UTC(1975, 11, 31, 23), -33.87, 151.21], [Date.UTC(2010, 5, 21, 12), 64.1, -21.9]]) {
    const ch = C.chart({ ms, lat, lon, nodeType: 'mean' });
    const r = C.strength(ch, { ms, lat, lon, frame });
    const ok = r.planets.length === 7 && r.planets.every(p => [p.total, p.sthana.total, p.dig, p.kala.total, p.cheshta, p.drik, p.ishta, p.kashta].every(isFinite)) && r.time.varaLord && r.time.horaLord;
    truthy('strength finite ' + frame + ' ' + new Date(ms).toISOString().slice(0, 10) + ' lat ' + lat, ok, 'totals(rupas)=' + r.planets.map(p => p.rupas.toFixed(1)).join(' ') + (r.time.polar ? ' [polar fallback]' : ''));
    truthy('  components in range', r.planets.every(p => p.sthana.uccha >= 0 && p.sthana.uccha <= 60 && p.dig >= 0 && p.dig <= 60 && p.cheshta >= 0 && p.cheshta <= 120.001));
  }
}
{ const ch = C.chart({ ms: NOON, lat: G[0], lon: G[1], nodeType: 'mean' });
  const t = C.strength(ch, { ms: NOON, lat: G[0], lon: G[1], frame: 'tropical' }), s = C.strength(ch, { ms: NOON, lat: G[0], lon: G[1], frame: 'sidereal' });
  console.log('tropical rupas', t.planets.map(p => p.id.slice(0, 2) + ' ' + p.rupas.toFixed(2)).join(' | '));
  console.log('sidereal rupas', s.planets.map(p => p.id.slice(0, 2) + ' ' + p.rupas.toFixed(2)).join(' | '));
  truthy('frames differ (sign-based parts change)', t.planets.some((p, i) => Math.abs(p.total - s.planets[i].total) > 1));
  truthy('dig, paksha, ayana, natonnata, naisargika are frame independent', t.planets.every((p, i) => p.dig === s.planets[i].dig && p.kala.paksha === s.planets[i].kala.paksha && p.kala.ayana === s.planets[i].kala.ayana && p.kala.nata === s.planets[i].kala.nata));
}
{ // Svalbard at the June solstice: no sunrise, so the nominal 06-18 local solar day is used
  const ms = Date.UTC(2001, 5, 21, 12), ch = C.chart({ ms, lat: 78.2, lon: 15.6, nodeType: 'mean' });
  const r = C.strength(ch, { ms, lat: 78.2, lon: 15.6, frame: 'tropical' });
  truthy('polar day uses the nominal day', r.time.polar === true);
  truthy('polar day: Thursday (Jupiter) vara, finite totals', r.time.varaLord === 'Jupiter' && r.planets.every(p => isFinite(p.total)), r.time.varaLord);
  const w = C.strength(C.chart({ ms: Date.UTC(2001, 11, 21, 12), lat: 78.2, lon: 15.6 }), { ms: Date.UTC(2001, 11, 21, 12), lat: 78.2, lon: 15.6, frame: 'tropical' });
  truthy('polar night also handled', w.time.polar === true && w.planets.every(p => isFinite(p.total)));
}
console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED');
process.exit(fails ? 1 : 0);
