// Standard ayanamshas and the zodiac choice
const createCore = require('./core.js');
const C = createCore((name) => { const a = { Sun: 1, Moon: 2.2, Mercury: 0.4, Venus: 5.1, Mars: 3.3, Jupiter: 4.0, Saturn: 0.9 }[name] || 0; return { x: Math.cos(a), y: Math.sin(a) * 0.917, z: Math.sin(a) * 0.398 }; });
let n = 0, bad = 0; const must = (l, ok, x) => { n++; if (!ok) { bad++; console.log('FAIL ' + l, x === undefined ? '' : x); } else console.log('PASS ' + l); };
const J2000 = Date.UTC(2000, 0, 1, 11, 58, 56);  // J2000.0 TT, to the second
const SE = { lahiri: 23.857092, fagan: 24.7403, krishnamurti: 23.7602, raman: 22.4108, ushashashi: 20.0575, yukteshwar: 22.4788 };
for (const k in SE) { const v = C.standardAyanamsa(J2000, k).mean; must(k + ' matches the Swiss Ephemeris value at J2000', Math.abs(v - SE[k]) < 1e-4, v); }
// Lahiri's defining value: 23°15'00.658" on 21 March 1956, 0h TT (true ayanamsha)
const d56 = C.standardAyanamsa(Date.UTC(1956, 2, 21), 'lahiri');
must('Lahiri true ayanamsha is 23°15′00.66″ on 21 Mar 1956 within 1″', Math.abs(d56.ayanamsa - (23 + 15 / 60 + 0.658 / 3600)) < 1 / 3600, (d56.ayanamsa - 23.25) * 3600);
must('rate is about 50.3″ a year', Math.abs((C.standardAyanamsa(J2000 + 365.25 * 864e5, 'lahiri').mean - SE.lahiri) * 3600 - 50.29) < 0.05);
const ms = Date.UTC(1990, 5, 15, 8, 30), o = { ms, lat: 28.6, lon: 77.2, nodeType: 'mean' };
for (const k of Object.keys(SE)) {
  C.setAyanamsaMode(k); const t = C.chart(o), s = C.chart(Object.assign({ zodiac: 'sidereal' }, o));
  must(k + ': mode kept, sidereal = tropical − ayanamsha', t.ayMode === k && t.ayStandard && t.bodies.every(b => Math.abs(C.norm(b.trop - b.sid - t.ayanamsa + 180) - 180) < 1e-9));
  must(k + ': sidereal zodiac moves signs, degrees and houses; longitudes and nakshatras stay', s.zodiac === 'sidereal' && t.zodiac === 'tropical' &&
    s.bodies.every((b, i) => b.sign === Math.floor(b.sid / 30) && Math.abs(b.degInSign - b.sid % 30) < 1e-9 && b.house === ((b.sign - s.asc.sign + 12) % 12) + 1 && b.sid === t.bodies[i].sid && b.nak.index === t.bodies[i].nak.index && t.bodies[i].sign === Math.floor(b.trop / 30)) &&
    s.asc.sign === Math.floor(s.asc.sid / 30));
  must(k + ': siderealOf agrees with the chart', Math.abs(C.siderealOf(t.bodies[1].trop, t.bodies[1].eclLat, ms) - t.bodies[1].sid) < 1e-9);
}
C.setAyanamsaMode('equatorial'); const e = C.chart(Object.assign({ zodiac: 'sidereal' }, o));
must('Dhruva equatorial still works with sidereal signs', e.ayMode === 'equatorial' && !e.ayStandard && e.bodies.every(b => b.sign === Math.floor(b.sid / 30)));
must('unknown mode falls back to Dhruva', C.setAyanamsaMode('nonsense') === 'dhruva');
const order = Object.keys(SE).map(k => C.standardAyanamsa(ms, k).mean);
must('ordering Fagan > Lahiri > Krishnamurti > Yukteshwar > Raman > Ushashashi', order[1] > order[0] && order[0] > order[2] && order[2] > order[5] && order[5] > order[3] && order[3] > order[4]);
console.log(bad ? 'FAILED ' + bad : 'ALL PASSED (' + n + ')'); process.exit(bad ? 1 : 0);
