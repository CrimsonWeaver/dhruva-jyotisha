const C = require('./core.js')(() => ({ x: 1, y: 0, z: 0 }));
const S = ['Ari', 'Tau', 'Gem', 'Can', 'Leo', 'Vir', 'Lib', 'Sco', 'Sag', 'Cap', 'Aqu', 'Pis'];
const IDX = Object.fromEntries(S.map((s, i) => [s, i]));
let fails = 0, n = 0;
function eq(label, sign, deg, varga, want) {
  n++;
  const got = C.vargaSign(IDX[sign] * 30 + deg, varga);
  if (got !== IDX[want]) { fails++; console.log('FAIL D' + varga + ' ' + sign + ' ' + deg + '  got ' + S[got] + '  want ' + want + '  (' + label + ')'); }
}
// [sign, degree, varga, expected sign, why]
const cases = [
  ['Ari', 10, 1, 'Ari', 'rasi'], ['Pis', 29.99, 1, 'Pis', 'rasi'],
  // D2 Parashara hora: odd sign Sun then Moon, even sign Moon then Sun
  ['Ari', 14.9, 2, 'Leo', 'odd 1st half Sun'], ['Ari', 15, 2, 'Can', 'odd 2nd half Moon'], ['Tau', 3, 2, 'Can', 'even 1st half Moon'], ['Tau', 29, 2, 'Leo', 'even 2nd half Sun'],
  // D3: 1st, 5th, 9th
  ['Ari', 9.99, 3, 'Ari', ''], ['Ari', 10, 3, 'Leo', ''], ['Ari', 20, 3, 'Sag', ''], ['Pis', 25, 3, 'Sco', '9th from Pisces'],
  // D4: 1st, 4th, 7th, 10th
  ['Ari', 0, 4, 'Ari', ''], ['Ari', 8, 4, 'Can', ''], ['Ari', 16, 4, 'Lib', ''], ['Tau', 23, 4, 'Aqu', '10th from Taurus'],
  // D7: odd from itself, even from the 7th
  ['Ari', 0, 7, 'Ari', ''], ['Ari', 29.9, 7, 'Lib', '7th part'], ['Tau', 0, 7, 'Sco', 'even starts 7th'], ['Tau', 29.9, 7, 'Tau', ''],
  // D9: fire Aries, earth Capricorn, air Libra, water Cancer
  ['Ari', 0, 9, 'Ari', ''], ['Ari', 29.9, 9, 'Sag', ''], ['Tau', 0, 9, 'Cap', ''], ['Gem', 0, 9, 'Lib', ''], ['Can', 0, 9, 'Can', ''], ['Pis', 29.9, 9, 'Pis', 'vargottama end'], ['Leo', 15, 9, 'Leo', '5th part of Leo'],
  // D10: odd from itself, even from the 9th
  ['Ari', 0, 10, 'Ari', ''], ['Ari', 4, 10, 'Tau', ''], ['Ari', 29.9, 10, 'Cap', ''], ['Tau', 0, 10, 'Cap', 'even from 9th'], ['Tau', 29, 10, 'Lib', ''],
  // D12: from itself
  ['Ari', 2.6, 12, 'Tau', ''], ['Leo', 0, 12, 'Leo', ''], ['Pis', 29.9, 12, 'Aqu', ''],
  // D16: movable Aries, fixed Leo, dual Sagittarius
  ['Ari', 0, 16, 'Ari', 'movable'], ['Tau', 0, 16, 'Leo', 'fixed'], ['Gem', 0, 16, 'Sag', 'dual'], ['Can', 29.9, 16, 'Can', 'movable last part 16th'], ['Lib', 1.9, 16, 'Tau', ''],
  // D20: movable Aries, fixed Sagittarius, dual Leo
  ['Ari', 0, 20, 'Ari', 'movable'], ['Tau', 0, 20, 'Sag', 'fixed'], ['Gem', 0, 20, 'Leo', 'dual'], ['Ari', 29.9, 20, 'Sco', '20th part'], ['Aqu', 1.5, 20, 'Cap', ''],
  // D24: odd from Leo, even from Cancer
  ['Ari', 0, 24, 'Leo', 'odd'], ['Tau', 0, 24, 'Can', 'even'], ['Ari', 29.9, 24, 'Can', '24th part'], ['Tau', 29.9, 24, 'Gem', ''],
  // D27: fire Aries, earth Cancer, air Libra, water Capricorn
  ['Ari', 0, 27, 'Ari', 'fire'], ['Tau', 0, 27, 'Can', 'earth'], ['Gem', 0, 27, 'Lib', 'air'], ['Can', 0, 27, 'Cap', 'water'], ['Leo', 0, 27, 'Ari', 'fire'], ['Ari', 29.9, 27, 'Gem', '27th part'],
  // D30: odd Mars 5, Saturn 5, Jupiter 8, Mercury 7, Venus 5; even reversed
  ['Ari', 4.9, 30, 'Ari', ''], ['Ari', 5, 30, 'Aqu', ''], ['Ari', 10, 30, 'Sag', ''], ['Ari', 18, 30, 'Gem', ''], ['Ari', 25, 30, 'Lib', ''],
  ['Tau', 4.9, 30, 'Tau', ''], ['Tau', 5, 30, 'Vir', ''], ['Tau', 12, 30, 'Pis', ''], ['Tau', 20, 30, 'Cap', ''], ['Tau', 25, 30, 'Sco', ''],
  // D40: odd from Aries, even from Libra
  ['Ari', 0, 40, 'Ari', 'odd'], ['Tau', 0, 40, 'Lib', 'even'], ['Tau', 29.9, 40, 'Cap', '40th part'], ['Leo', 0.75, 40, 'Tau', ''],
  // D45: movable Aries, fixed Leo, dual Sagittarius
  ['Ari', 0, 45, 'Ari', 'movable'], ['Tau', 0, 45, 'Leo', 'fixed'], ['Gem', 0, 45, 'Sag', 'dual'], ['Ari', 29.9, 45, 'Sag', '45th part'],
  // D60: from the sign itself, half-degree parts
  ['Ari', 0, 60, 'Ari', ''], ['Ari', 0.5, 60, 'Tau', ''], ['Tau', 29.9, 60, 'Ari', '60th part'], ['Lib', 5.6, 60, 'Vir', '12th part: 12th sign from Libra'], ['Lib', 6.0, 60, 'Lib', '13th part wraps to Libra'],
];
cases.forEach(c => eq(c[4], c[0], c[1], c[2], c[3]));

// Every varga: each division of every sign maps to a valid sign, and there are exactly n distinct steps across a sign
C.VARGAS.forEach(v => {
  for (let s = 0; s < 12; s++) {
    let changes = 0, prev = null;
    for (let i = 0; i < 6000; i++) {
      const g = C.vargaSign(s * 30 + (i + 0.5) * 30 / 6000, v.n);
      n++; if (!(g >= 0 && g < 12 && Number.isInteger(g))) { fails++; console.log('FAIL invalid sign D' + v.n); break; }
      if (prev !== null && g !== prev) changes++;
      prev = g;
    }
    const want = v.n === 30 ? 4 : v.n === 1 ? 0 : v.n - 1;
    n++; if (changes !== want) { fails++; console.log('FAIL D' + v.n + ' ' + S[s] + ' has ' + (changes + 1) + ' divisions, want ' + (want + 1)); }
  }
  // exact boundary values never overflow
  n++; if (C.vargaSign(29.999999999999996, v.n) == null) { fails++; console.log('FAIL boundary D' + v.n); }
});
console.log(C.VARGAS.length === 16 ? 'PASS 16 vargas defined' : 'FAIL vargas count'); if (C.VARGAS.length !== 16) fails++;

// Shadbala's seven vargas agree with the general function
for (let L = 0.05; L < 360; L += 0.37) {
  const a = C.vargaSigns(L);
  for (const k of [1, 2, 3, 7, 9, 12, 30]) { n++; if (a['d' + k] !== C.vargaSign(L, k)) { fails++; console.log('FAIL shadbala varga mismatch D' + k + ' at ' + L); } }
}
// Dignity
const dg = (id, s, w) => { n++; const g = C.dignityIn(id, IDX[s]); if (g !== w) { fails++; console.log('FAIL dignity ' + id + ' in ' + s + ' got "' + g + '" want "' + w + '"'); } };
dg('Sun', 'Ari', 'ex'); dg('Sun', 'Lib', 'db'); dg('Sun', 'Leo', 'own'); dg('Moon', 'Tau', 'ex'); dg('Moon', 'Sco', 'db'); dg('Moon', 'Can', 'own');
dg('Mars', 'Cap', 'ex'); dg('Mars', 'Can', 'db'); dg('Mars', 'Sco', 'own'); dg('Mercury', 'Vir', 'ex'); dg('Mercury', 'Pis', 'db'); dg('Mercury', 'Gem', 'own');
dg('Jupiter', 'Can', 'ex'); dg('Jupiter', 'Cap', 'db'); dg('Jupiter', 'Pis', 'own'); dg('Venus', 'Pis', 'ex'); dg('Venus', 'Vir', 'db'); dg('Venus', 'Lib', 'own');
dg('Saturn', 'Lib', 'ex'); dg('Saturn', 'Ari', 'db'); dg('Saturn', 'Aqu', 'own'); dg('Rahu', 'Tau', ''); dg('Sun', 'Gem', '');

// vargaChart: both zodiacs, lagna and 9 grahas, D1 equals the chart's signs
const ch = { asc: { trop: 204.27, sid: 184.09 }, bodies: ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'].map((id, i) => ({ id, abbr: id.slice(0, 2), trop: (i * 41.3 + 7) % 360, sid: (i * 41.3 + 7 - 20.18 + 360) % 360 })) };
for (const fr of ['tropical', 'sidereal']) {
  const vc = C.vargaChart(ch, fr);
  n++; if (vc.bodies.length !== 9 || Object.keys(vc.asc).length !== 16) { fails++; console.log('FAIL vargaChart shape ' + fr); }
  vc.bodies.forEach((b, i) => { n++; const L = fr === 'sidereal' ? ch.bodies[i].sid : ch.bodies[i].trop; if (b.signs[1] !== Math.floor(L / 30)) { fails++; console.log('FAIL D1 ' + b.id + ' ' + fr); } });
  n++; if (vc.asc[1] !== Math.floor((fr === 'sidereal' ? 184.09 : 204.27) / 30)) { fails++; console.log('FAIL asc D1 ' + fr); }
  console.log(fr.padEnd(9), 'Asc', C.VARGAS.map(v => S[vc.asc[v.n]]).join(' '));
}
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ' checks)');
process.exit(fails ? 1 : 0);
