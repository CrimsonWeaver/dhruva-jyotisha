// Transits: ashtakavarga, contacts, influences, and a 12-month timeline on a realistic test ephemeris.
const createCore = require('./core.js');
const D2R = Math.PI / 180, R2D = 180 / Math.PI, norm = a => ((a % 360) + 360) % 360, sin = a => Math.sin(a * D2R);
const sep = (a, b) => Math.abs(((a - b) % 360 + 540) % 360 - 180);
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
// --- test ephemeris (as in test6: Meeus Sun & Moon, circular heliocentric planets) ---
const base = createCore(() => ({ x: 1, y: 0, z: 0 }));
const ML = { Mercury: [252.250906, 149474.0722491, 0.387], Venus: [181.979801, 58519.2130302, 0.723], Mars: [355.433275, 19141.6964746, 1.524], Jupiter: [34.351484, 3036.3027889, 5.203], Saturn: [50.077471, 1223.5110141, 9.537] };
function ecl(name, T) {
  if (name === 'Sun') { const M = 357.52911 + 35999.05029 * T; return [norm(280.46646 + 36000.76983 * T + 1.9146 * sin(M) + 0.02 * sin(2 * M)), 0]; }
  if (name === 'Moon') { const D = 297.85 + 445267.1114 * T, M = 357.53 + 35999.05 * T, Mp = 134.96 + 477198.8675 * T, F = 93.27 + 483202.0175 * T;
    return [norm(218.3165 + 481267.8813 * T + 6.289 * sin(Mp) + 1.274 * sin(2 * D - Mp) + 0.658 * sin(2 * D) + 0.214 * sin(2 * Mp) - 0.186 * sin(M) - 0.114 * sin(2 * F)), 5.128 * sin(F) + 0.2806 * sin(Mp + F) + 0.2777 * sin(Mp - F) + 0.1732 * sin(2 * D - F)]; }
  const [l0, rate, a] = ML[name], L = (l0 + rate * T) * D2R, Le = (280.4664567 + 36000.76983 * T + 180) * D2R;
  return [norm(Math.atan2(a * Math.sin(L) - Math.sin(Le), a * Math.cos(L) - Math.cos(Le)) * R2D), 0];
}
function vec(name, date) {
  const T = (+date / 864e5 + 2440587.5 - 2451545) / 36525, [lo, la] = ecl(name, T);
  const cols = [[0, 0], [90, 0], [0, 90]].map(([ra, dec]) => { const e = base.eqjToTrueEcliptic(ra, dec, T); const l = e.lon * D2R, b = e.lat * D2R; return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)]; });
  const nut = base.nutation(T).dpsi, l = (lo + nut) * D2R, b = la * D2R, v = [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
  const dot = u => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  return { x: dot(cols[0]), y: dot(cols[1]), z: dot(cols[2]) };
}
const C = createCore(vec);
const birth = Date.UTC(1990, 5, 15, 3, 30), natal = C.chart({ ms: birth, lat: 19.076, lon: 72.8777, nodeType: 'mean' });

// ---- Ashtakavarga
const av = C.ashtakavarga(natal, 'tropical');
const TOT = { Sun: 48, Moon: 49, Mars: 39, Mercury: 54, Jupiter: 56, Venus: 52, Saturn: 39 };
ok('each planet\'s bindus total its classical figure', Object.keys(TOT).every(p => av.bav[p].reduce((a, b) => a + b, 0) === TOT[p]), Object.keys(TOT).map(p => p.slice(0, 2) + ' ' + av.bav[p].reduce((a, b) => a + b, 0)).join(', '));
ok('sarvashtakavarga totals 337', av.sav.reduce((a, b) => a + b, 0) === 337);
ok('no sign above 8 bindus in any planet\'s table', Object.values(av.bav).every(r => r.every(x => x >= 0 && x <= 8)));
// hand check: every reference in Aries
const allAries = { asc: { trop: 5, sid: 345 }, bodies: ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'].map(id => ({ id, trop: 10, sid: 350 })) };
const av0 = C.ashtakavarga(allAries, 'tropical');
ok('all in Aries: Sun gets 3 bindus in Aries (from Sun, Mars, Saturn)', av0.bav.Sun[0] === 3 && av0.contrib.Sun[0].join() === 'Sun,Mars,Saturn');
ok('all in Aries: Sun gets 7 in Aquarius (11th from all but Venus)', av0.bav.Sun[10] === 7 && !av0.contrib.Sun[10].includes('Venus'));
ok('all in Aries: Venus gets 3 in Pisces? (Sun, Moon, Mars)', av0.bav.Venus[11] === 3 && av0.contrib.Venus[11].join() === 'Sun,Moon,Mars', av0.bav.Venus[11] + ' ' + av0.contrib.Venus[11]);
ok('all in Aries: Jupiter in Sagittarius (9th) from Sun, Moon, Mercury, Venus, Lagna', av0.bav.Jupiter[8] === 5);

// ---- contacts geometry
const pts = [{ id: 'X', kind: 'planet', lon: 270 }, { id: 'Y', kind: 'planet', lon: 60 }, { id: 'Z', kind: 'planet', lon: 210 }, { id: 'W', kind: 'planet', lon: 180 }, { id: 'V', kind: 'planet', lon: 1.5 }];
const sat = C.contactsAt('Saturn', 0, pts, 3).map(c => c.to + ':' + c.aspect).sort().join(' ');
ok('Saturn at 0°: 10th-house aspect to 270°, 3rd to 60°, opposition to 180°, conjunction to 1.5°', sat === 'V:0 W:180 X:270 Y:60', sat);
ok('Mars at 0°: 8th-house aspect to 210°', C.contactsAt('Mars', 0, pts, 3).some(c => c.to === 'Z' && c.aspect === 210));
ok('Sun at 0°: only opposition and conjunction', C.contactsAt('Sun', 0, pts, 3).map(c => c.aspect).sort().join() === '0,180');
ok('nodes: conjunction only', C.contactsAt('Rahu', 0, pts, 3).every(c => c.aspect === 0));

// ---- snapshot and influences
const now = Date.UTC(2026, 10, 3, 17);
const snap = C.transitSnapshot(natal, now, { frame: 'tropical', nodeType: 'mean', av });
ok('snapshot: 9 transiting bodies with house, nakshatra and bindus', snap.bodies.length === 9 && snap.bodies.every(b => b.house >= 1 && b.house <= 12 && b.nak && (b.id === 'Rahu' || b.id === 'Ketu' || (b.av.bindus >= 0 && b.av.bindus <= 8))));
ok('snapshot: house counted from the natal lagna sign', snap.bodies.every(b => b.house === ((b.sign - Math.floor(natal.asc.trop / 30) + 12) % 12) + 1));
ok('snapshot: kakshya lord follows the 3°45′ parts', snap.bodies.filter(b => b.av.kakshya).every(b => b.av.kakshya === C.KAKSHYA[Math.min(7, Math.floor(b.deg / 3.75))]));
ok('snapshot: transit chart has its own strength and avasthas', snap.strength.planets.length === 7 && snap.avasthas.planets.length === 7);
ok('influences cover the 7 natal grahas, net = delight - affliction', snap.influences.length === 7 && snap.influences.every(i => Math.abs(i.net - (i.delight - i.affliction)) < 1e-9));
// controlled: transit Saturn in natal Venus's sign starves it; Jupiter with natal Mercury delights; Sun with natal Mars agitates
const mk = pos => ({ asc: { trop: 0, sid: 340 }, bodies: ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'].map((id, i) => ({ id, trop: pos[id] != null ? pos[id] : 5 + i * 37, sid: 0 })) });
const nat = mk({ Venus: 100, Mercury: 200, Mars: 300 }), tr = mk({ Saturn: 105, Jupiter: 205, Sun: 305, Moon: 20, Mercury: 50, Venus: 140, Mars: 250 });
const sbFake = { planets: ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'].map(id => ({ id, total: 300 })) };
const inf = C.transitInfluences(nat, tr, sbFake, 'tropical'), g = id => inf.find(x => x.id === id).influences;
ok('transit Saturn in natal Venus\'s sign starves it, though Venus counts Saturn a friend', g('Venus').some(i => i.from === 'Saturn' && i.state === 'kshudhita' && i.amount === 300));
ok('transit Jupiter with natal Mercury delights it', g('Mercury').some(i => i.from === 'Jupiter' && i.state === 'mudita'));
ok('transit Sun with natal Mars agitates it', g('Mars').some(i => i.from === 'Sun' && i.state === 'kshobhita'));

// ---- timeline
const dasa = C.buildDasa(natal.bodies[1].sid, birth, 365.25 * 864e5);
const t0 = Date.now();
const start = Date.UTC(2026, 0, 1), end = Date.UTC(2027, 0, 1);
const ev = C.transitTimeline(natal, dasa, start, end, { frame: 'tropical', nodeType: 'mean' });
const took = Date.now() - t0;
ok('timeline computed', ev.length > 50, ev.length + ' events in ' + took + ' ms');
ok('events in order and inside the window', ev.every((e, i) => e.ms >= start && e.ms <= end && (i === 0 || e.ms >= ev[i - 1].ms)));
const sunIn = ev.filter(e => e.kind === 'ingress' && e.body === 'Sun');
ok('the Sun changes sign 12 times a year', sunIn.length === 12, sunIn.length);
const aries = sunIn.find(e => e.sign === 0);
ok('Sun enters tropical Aries on 20 March (equinox)', aries && new Date(aries.ms).toISOString().slice(5, 10) === '03-20', aries && new Date(aries.ms).toISOString());
ok('ingress times are exact', ev.filter(e => e.kind === 'ingress' && e.body !== 'Rahu' && e.body !== 'Ketu').every(e => sep(C.chart({ ms: e.ms, lat: 0, lon: 0 }).bodies.find(b => b.id === e.body).trop, e.sign * 30 + (e.retro ? 30 : 0)) < 0.01));
const merc = ev.filter(e => e.kind === 'station' && e.body === 'Mercury');
ok('Mercury stations 3-4 times retrograde and direct', merc.length >= 6 && merc.length <= 8 && merc.filter(e => e.retro).length >= 3, merc.map(e => (e.retro ? 'R ' : 'D ') + new Date(e.ms).toISOString().slice(0, 10)).join(', '));
ok('stations alternate retrograde/direct', merc.every((e, i) => i === 0 || e.retro !== merc[i - 1].retro));
ok('at each station the planet is momentarily still', merc.every(e => { const a = C.chart({ ms: e.ms - 864e5, lat: 0, lon: 0 }).bodies[3].trop, b = C.chart({ ms: e.ms + 864e5, lat: 0, lon: 0 }).bodies[3].trop; return sep(a, b) < 0.08; }));
const conj = ev.filter(e => e.kind === 'contact');
const exact = conj.filter(e => e.body !== 'Rahu' && e.body !== 'Ketu').every(e => {
  const p = C.natalPoints(natal).find(q => q.id === e.to), L = C.chart({ ms: e.ms, lat: 0, lon: 0 }).bodies.find(b => b.id === e.body).trop;
  return Math.abs(((L - p.lon - e.aspect) % 360 + 540) % 360 - 180) < 0.01;
});
ok('every contact is exact at its time', exact, conj.length + ' contacts');
const sunToMoon = conj.filter(e => e.body === 'Sun' && e.to === 'Moon' && e.aspect === 0);
ok('the Sun conjoins natal Moon once a year', sunToMoon.length === 1);
ok('cusp contacts included', conj.some(e => e.toKind === 'cusp'));
const ds = ev.filter(e => e.kind === 'dasa');
ok('dasa changes inside the window, nested correctly', ds.length > 0 && ds.every(e => e.lords.length === e.level + 1), ds.map(e => e.lords.join('-') + ' ' + new Date(e.ms).toISOString().slice(0, 10)).slice(0, 4).join(' | '));
const running = C.runningAt(dasa, start);
ok('the first pratyantardasha change comes when the running one ends', Math.abs(ds.filter(e => e.level === 2)[0].ms - running[2].fullEnd) < 1000);
ok('Jupiter or Saturn nakshatra changes reported', ev.some(e => e.kind === 'nakshatra'));
// interpolated node track
const tr2 = C.nodeTrack(start, end, 'interpolated');
let worst = 0, worstTrue = 0;
for (let t = start; t < end; t += 7 * 864e5) { worst = Math.max(worst, sep(tr2(t), C.lunarNode(t, 'interpolated'))); worstTrue = Math.max(worstTrue, sep(tr2(t), C.lunarNode(t, 'true'))); }
ok('year-long interpolated node track matches the per-moment interpolated node', worst < 0.01, worst.toExponential(2) + '° (vs 5-term true node ' + worstTrue.toFixed(2) + '° on this crude test Moon)');
ok('fast enough', took < 8000, took + ' ms');
// ---- observer's location
const here = C.transitSnapshot(natal, now, { frame: 'tropical', nodeType: 'mean', av, lat: 35.68, lon: 139.69 });
const home = C.transitSnapshot(natal, now, { frame: 'tropical', nodeType: 'mean', av });
ok('location: planet positions identical anywhere', here.bodies.every((b, i) => b.trop === home.bodies[i].trop));
ok('location: rising sign changes with the place', sep(here.rising.trop, home.rising.trop) > 1, home.rising.trop.toFixed(1) + '° vs ' + here.rising.trop.toFixed(1) + '°');
ok('location: rising sign placed in a natal house', here.rising.house === ((here.rising.sign - Math.floor(natal.asc.trop / 30) + 12) % 12) + 1);
ok('location: rising matches the ascendant computed for that place', sep(here.rising.trop, C.angles(now, 35.68, 139.69).asc) < 1e-9);
ok('location: transit strength uses the place (directional strength differs)', here.strength.planets.some((p, i) => Math.abs(p.dig - home.strength.planets[i].dig) > 1));
ok('location: default is the birthplace', home.lat === natal.lat && home.lon === natal.lon);
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
