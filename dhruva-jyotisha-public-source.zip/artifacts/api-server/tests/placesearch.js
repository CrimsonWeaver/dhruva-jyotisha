/* Birthplace search over the compact GeoNames file made by build_places.py.
   createPlaceIndex(text) parses it once; index.search(query) returns up to `limit` places.
   A query is "place[, region or country[, ...]]": "springfield, il", "york, england", "bombay". */
function createPlaceIndex(text) {
  var MARKS;
  try { MARKS = new RegExp('\\p{Mn}', 'gu'); } catch (e) { MARKS = /[̀-ͯ]/g; }
  var ASCII = /^[\x00-\x7f]*$/;
  function fold(s) { s = String(s); return ASCII.test(s) ? s.toLowerCase() : s.normalize('NFD').replace(MARKS, '').toLowerCase(); }
  /* Letters accents can't be stripped from, so "Lodz" is recognised as a plain spelling of "Łódź", not a former name. */
  var LOOSE = { 'ł': 'l', 'ø': 'o', 'æ': 'ae', 'ß': 'ss', 'đ': 'd', 'ı': 'i', 'œ': 'oe', 'þ': 'th', 'ð': 'd', 'ħ': 'h' };
  function loose(s) { return fold(s).replace(/[łøæßđıœþðħ]/g, function (c) { return LOOSE[c]; }).replace(/[^a-z0-9]/g, ''); }
  var lines = text.split('\n');
  if (!/^#places v1\t/.test(lines[0])) throw new Error('This is not a place file the app recognises.');
  var tzs = lines[1].replace(/^TZ\t/, '').split('|');
  var regions = lines[2].replace(/^A1\t/, '').split('|').map(function (e) {
    var i = e.lastIndexOf('='); return { name: i >= 0 ? e.slice(0, i) : e, code: i >= 0 ? e.slice(i + 1) : '' };
  });
  regions.forEach(function (r) { r.key = fold(r.name); r.codeKey = r.code.toLowerCase(); });

  var dn = null;
  try { dn = new Intl.DisplayNames(['en'], { type: 'region' }); } catch (e) { dn = null; }
  var countryCache = {};
  function countryName(cc) {
    if (!(cc in countryCache)) { var n = cc; try { n = (dn && dn.of(cc)) || cc; } catch (e) { n = cc; } countryCache[cc] = n; }
    return countryCache[cc];
  }
  var COUNTRY_ALIASES = { usa: 'US', us: 'US', america: 'US', 'united states of america': 'US', uk: 'GB', britain: 'GB', 'great britain': 'GB',
    uae: 'AE', holland: 'NL', burma: 'MM', ceylon: 'LK', persia: 'IR', russia: 'RU', 'south korea': 'KR', korea: 'KR' };

  var n = 0, name = [], alias = [], key = [], cc = [], a1 = [], lat = [], lon = [], tz = [], pop = [];
  for (var i = 3; i < lines.length; i++) {
    var p = lines[i].split('\t');
    if (p.length < 8) continue;
    name.push(p[0]); alias.push(p[1] ? p[1].split('|') : []); cc.push(p[2]); a1.push(+p[3]);
    lat.push(+p[4]); lon.push(+p[5]); tz.push(tzs[+p[6]] || ''); pop.push(+p[7]);
    key.push('\u0001' + fold(p[0] + (p[1] ? '\u0001' + p[1].replace(/\|/g, '\u0001') : '')) + '\u0001');
    n++;
  }

  function passes(i, filters) {
    var c = cc[i], r = a1[i] >= 0 ? regions[a1[i]] : null, cn = fold(countryName(c)), cl = c.toLowerCase();
    return filters.every(function (f) {
      if (r && (r.key.indexOf(f) === 0 || r.codeKey === f)) return true;
      if (cl === f || cn.indexOf(f) === 0) return true;
      return COUNTRY_ALIASES[f] === c;
    });
  }
  function result(i, q) {
    var r = a1[i] >= 0 ? regions[a1[i]].name : '', country = countryName(cc[i]);
    var matched = '';
    if (fold(name[i]).indexOf(q) !== 0) {
      var j, a;
      for (j = 0; j < alias[i].length && !matched; j++) { a = fold(alias[i][j]); if (a.indexOf(q) === 0) matched = alias[i][j]; }
      for (j = 0; j < alias[i].length && !matched; j++) { a = fold(alias[i][j]); if (a.indexOf(' ' + q) >= 0) matched = alias[i][j]; }
      if (matched && loose(matched) === loose(name[i])) matched = '';   // just another spelling of the same name
    }
    var parts = [name[i]];
    if (r && r !== name[i]) parts.push(r);
    parts.push(country);
    return { name: name[i], region: r, country: country, cc: cc[i], lat: lat[i], lon: lon[i], tz: tz[i], population: pop[i],
      alias: matched, label: parts.join(', ') };
  }
  function search(query, limit) {
    limit = limit || 8;
    var parts = fold(query).split(',').map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
    if (!parts.length || parts[0].length < 2) return [];
    var q = parts[0], filters = parts.slice(1);
    var exact = '\u0001' + q + '\u0001', pre = '\u0001' + q, word1 = ' ' + q, word2 = '-' + q;
    var tiers = [[], [], []];
    for (var i = 0; i < n; i++) {
      var k = key[i], t;
      if (k.indexOf(exact) >= 0) t = 0;
      else if (k.indexOf(pre) >= 0) t = 1;
      else if (k.indexOf(word1) >= 0 || k.indexOf(word2) >= 0) t = 2;
      else continue;
      if (tiers[t].length >= limit) continue;
      if (filters.length && !passes(i, filters)) continue;
      tiers[t].push(i);
      if (tiers[0].length >= limit) break;
    }
    return tiers[0].concat(tiers[1], tiers[2]).slice(0, limit).map(function (i) { return result(i, q); });
  }
  return { size: n, search: search, fold: fold, countryName: countryName };
}
if (typeof module !== 'undefined') module.exports = createPlaceIndex;
