// Real GeoNames data: spot checks a person would actually type.
const fs = require('fs');
const idx = require('./placesearch.js')(fs.readFileSync('places.txt', 'utf8'));
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const first = q => idx.search(q)[0] || {};
const near = (r, la, lo, d) => Math.abs(r.lat - la) < d && Math.abs(r.lon - lo) < d;
ok('loaded ' + idx.size + ' places', idx.size > 150000);
const cases = [
  ['london', 'London', 'GB', 'Europe/London', 51.51, -0.13],
  ['new york', 'New York City', 'US', 'America/New_York', 40.71, -74.01],
  ['springfield, il', 'Springfield', 'US', 'America/Chicago', 39.80, -89.64],
  ['springfield, mo', 'Springfield', 'US', 'America/Chicago', 37.22, -93.30],
  ['ulm', 'Ulm', 'DE', 'Europe/Berlin', 48.40, 9.99],
  ['honolulu', 'Honolulu', 'US', 'Pacific/Honolulu', 21.31, -157.86],
  ['bombay', 'Mumbai', 'IN', 'Asia/Kolkata', 19.07, 72.88],
  ['madras', 'Chennai', 'IN', 'Asia/Kolkata', 13.09, 80.28],
  ['peking', 'Beijing', 'CN', 'Asia/Shanghai', 39.91, 116.40],
  ['leningrad', 'Saint Petersburg', 'RU', 'Europe/Moscow', 59.94, 30.31],
  ['sao paulo', 'São Paulo', 'BR', 'America/Sao_Paulo', -23.55, -46.64],
  ['zurich', 'Zürich', 'CH', 'Europe/Zurich', 47.37, 8.55],
  ['lodz', 'Łódź', 'PL', 'Europe/Warsaw', 51.76, 19.46],
  ['kathmandu', 'Kathmandu', 'NP', 'Asia/Kathmandu', 27.70, 85.32],
  ['sydney', 'Sydney', 'AU', 'Australia/Sydney', -33.87, 151.21],
  ['varanasi', 'Varanasi', 'IN', 'Asia/Kolkata', 25.32, 83.01],
];
for (const [q, name, cc, tz, la, lo] of cases) {
  const r = first(q);
  ok(`"${q}" → ${r.label || 'nothing'}`, r.name === name && r.cc === cc && r.tz === tz && near(r, la, lo, 0.15), r.alias ? 'via ' + r.alias : '');
}
ok('"paris" puts Paris, France first', first('paris').cc === 'FR');
ok('"paris, texas" finds the Texas one', first('paris, texas').region === 'Texas' && first('paris, tx').region === 'Texas');
ok('"york, england" → York, England', first('york, england').name === 'York' && first('york, england').cc === 'GB');
ok('small towns are there: "ilfracombe"', first('ilfracombe').cc === 'GB');
const t0 = Date.now(); for (const q of ['sa', 'new', 'spring', 'ber', 'mu', 'ch']) idx.search(q); ok('search stays quick on 170k places', Date.now() - t0 < 600, (Date.now() - t0) + ' ms for 6 broad searches');
const t1 = Date.now(); require('./placesearch.js')(fs.readFileSync('places.txt', 'utf8')); ok('parsing the file', true, (Date.now() - t1) + ' ms');
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
