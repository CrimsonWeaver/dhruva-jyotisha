const createCore = require('./core.js');
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
let fails = 0;
function check(name, got, want, tol) {
  const ok = Math.abs(got - want) <= tol;
  if (!ok) fails++;
  console.log((ok ? 'PASS ' : 'FAIL ') + name + '  got=' + got.toFixed(6) + '  want=' + want + '  tol=' + tol);
}
function truthy(name, cond, extra) { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); }

// Mock vector source: a fixed EQJ direction (Regulus), enough to exercise the pipeline.
const regRa = (10 + 8 / 60 + 22.311 / 3600) * 15, regDec = 11 + 58 / 60 + 1.95 / 3600;
const mock = () => ({ x: Math.cos(regDec * D2R) * Math.cos(regRa * D2R), y: Math.cos(regDec * D2R) * Math.sin(regRa * D2R), z: Math.sin(regDec * D2R) });
const C = createCore(mock);
const jdToMs = jd => (jd - 2440587.5) * 86400000;

// 1. Meeus ex. 22.a nutation (JDE 2446895.5): dpsi -3.788", deps +9.443"
const nut = C.nutation(C.tOf(jdToMs(2446895.5)));
check('nutation dpsi (arcsec)', nut.dpsi * 3600, -3.788, 0.6);
check('nutation deps (arcsec)', nut.deps * 3600, 9.443, 0.3);

// 2. Meeus ex. 22.a mean obliquity 23°26'27.407"
check('mean obliquity (deg)', C.meanObliquity(C.tOf(jdToMs(2446895.5))), 23 + 26 / 60 + 27.407 / 3600, 0.0002);

// 3. Meeus ex. 12.b apparent sidereal time 1987-04-10 0h UT = 13h10m46.1351s
check('GAST 1987-04-10 0h (deg)', C.gast(jdToMs(2446895.5)), (13 + 10 / 60 + 46.1351 / 3600) * 15, 0.0005);
// GMST at J2000 = 280.46061837 (+ small eq. of equinoxes)
check('GAST J2000 (deg)', C.gast(jdToMs(2451545.0)), 280.46061837, 0.005);

// 4. Precession: a star on the ecliptic gains about 1.39697 deg per century in longitude
{
  const eps0 = 23.4392911, lam = 100;
  const ra = Math.atan2(Math.sin(lam * D2R) * Math.cos(eps0 * D2R), Math.cos(lam * D2R)) * R2D;
  const dec = Math.asin(Math.sin(eps0 * D2R) * Math.sin(lam * D2R)) * R2D;
  const a = C.eqjToTrueEcliptic(ra, dec, 0), b = C.eqjToTrueEcliptic(ra, dec, 1);
  const dpsi = C.nutation(1).dpsi - C.nutation(0).dpsi;
  check('ecliptic lon at J2000 equals input', a.lon - C.nutation(0).dpsi, 100, 0.001);
  check('precession per century (deg)', b.lon - a.lon - dpsi, 1.39697, 0.003);
  check('ecliptic lat stays ~0', b.lat, 0, 0.02);
}
// 5. Regulus: tropical longitude 29deg50' Leo at J2000 (149.83)
check('Regulus lon J2000', C.eqjToTrueEcliptic(regRa, regDec, 0).lon, 149.83, 0.03);

// 6. Galactic Center and Dhruva ayanamsa
const gc0 = C.dhruvaAyanamsa(jdToMs(2451545.0));
check('GC tropical lon J2000', gc0.gcLon, 266.85, 0.03);
check('GC ecliptic lat J2000', gc0.gcLat, -5.6, 0.1);
console.log('Dhruva ayanamsa J2000 =', gc0.ayanamsa.toFixed(4), ' on 2026-10-28 =', C.dhruvaAyanamsa(Date.UTC(2026, 9, 28)).ayanamsa.toFixed(4));
check('ayanamsa drift per century', C.dhruvaAyanamsa(jdToMs(2451545 + 36525)).ayanamsa - gc0.ayanamsa, 1.3969, 0.01);

// 7. Mean lunar node at J2000 = 125.0445479 (+ nutation)
check('mean node J2000', C.lunarNode(jdToMs(2451545.0), 'mean'), 125.0445479, 0.01);
truthy('true node within 2deg of mean', Math.abs(((C.lunarNode(Date.UTC(2026, 9, 28), 'true') - C.lunarNode(Date.UTC(2026, 9, 28), 'mean') + 540) % 360) - 180) < 2);

// 8. Ascendant geometry: the ascendant must be on the horizon (alt 0) and rising (hour angle ~270)
for (const [lat, lon, ms] of [[51.4769, 0, Date.UTC(2000, 0, 1, 12)], [19.076, 72.8777, Date.UTC(1990, 5, 15, 3, 30)], [-33.87, 151.21, Date.UTC(2026, 9, 28, 20)], [40.7, -74, Date.UTC(1975, 11, 31, 23)]]) {
  const a = C.angles(ms, lat, lon);
  const ra = Math.atan2(Math.sin(a.asc * D2R) * Math.cos(a.eps * D2R), Math.cos(a.asc * D2R)) * R2D;
  const dec = Math.asin(Math.sin(a.eps * D2R) * Math.sin(a.asc * D2R)) * R2D;
  const H = ((a.ramc - ra) % 360 + 360) % 360;
  const alt = Math.asin(Math.sin(lat * D2R) * Math.sin(dec * D2R) + Math.cos(lat * D2R) * Math.cos(dec * D2R) * Math.cos(H * D2R)) * R2D;
  check('asc altitude lat=' + lat, alt, 0, 0.001);
  check('asc hour angle (east) lat=' + lat, H, 270, 90);   // must be on the eastern half: 180-360
  truthy('asc hour angle in east half lat=' + lat, H > 180 && H < 360, 'H=' + H.toFixed(2));
  const raMc = Math.atan2(Math.sin(a.mc * D2R) * Math.cos(a.eps * D2R), Math.cos(a.mc * D2R)) * R2D;
  check('MC culminates lat=' + lat, ((raMc - a.ramc + 540) % 360) - 180, 0, 0.001);
}
check('asc at RAMC 0 on the equator', (() => { const ms = jdToMs(2451545.0); const a = C.angles(ms, 0, 0 - (C.gast(ms))); return a.asc; })(), 90, 0.5);

// 9. Nakshatra boundaries
const nk = C.nakshatraOf(0); truthy('0deg -> Ashwini pada 1, Ketu', nk.name === 'Ashwini' && nk.pada === 1 && nk.lord === 'Ketu');
const nm = C.nakshatraOf(246.67); truthy('246.67 -> Mula pada 3, Ketu', nm.name === 'Mula' && nm.pada === 3 && nm.lord === 'Ketu', nm.name + ' p' + nm.pada);
const nr = C.nakshatraOf(359.99); truthy('359.99 -> Revati pada 4, Mercury', nr.name === 'Revati' && nr.pada === 4 && nr.lord === 'Mercury');
truthy('Bharani lord Venus', C.nakshatraOf(14).lord === 'Venus');
truthy('Rohini lord Moon', C.nakshatraOf(45).lord === 'Moon');

// 10. Vimshottari
const YR = 365.25 * 86400000, birth = Date.UTC(1990, 5, 15, 3, 30);
let d = C.buildDasa(5, birth, YR);
check('balance (Moon 5deg Ashwini) years', d.balanceYears, 7 * (1 - 5 / (360 / 27)), 1e-9);
check('MD cycle total years', (d.periods[8].fullEnd - d.periods[0].fullStart) / YR, 120, 1e-9);
truthy('first MD is Ketu then Venus', d.periods[0].lord === 'Ketu' && d.periods[1].lord === 'Venus');
check('first MD ends balance years after birth', (d.periods[0].fullEnd - birth) / YR, d.balanceYears, 1e-9);
for (const lvl0 of d.periods) {
  const subs = C.subPeriods(lvl0, 0);
  const sum = subs.reduce((s, p) => s + (p.fullEnd - p.fullStart), 0);
  check('AD sum equals MD ' + lvl0.lord, sum / YR, (lvl0.fullEnd - lvl0.fullStart) / YR, 1e-9);
  truthy('AD starts with own lord ' + lvl0.lord, subs[0].lord === lvl0.lord);
}
// Venus MD, Venus-Venus AD length = 20*20/120 = 3.3333y; Ketu-Ketu = 7*7/120 = 0.40833y
const kk = C.subPeriods(d.periods[0], 0)[0]; check('Ketu-Ketu AD years', (kk.fullEnd - kk.fullStart) / YR, 49 / 120, 1e-9);
// Moon in Mula (idx 18) -> Ketu, Moon in Pushya (idx 7) -> Saturn, Moon in Revati (idx 26) -> Mercury
truthy('Pushya lord Saturn', C.nakshatraOf(100).lord === 'Saturn');
// A birth-time clip: sub periods ending before birth are removed
const later = C.subPeriods(d.periods[0], birth);
truthy('periods ending before birth are removed', later.every(p => p.fullEnd > birth) && later.length < 9, later.length + ' of 9 remain');
const run = C.runningAt(d, Date.UTC(2026, 9, 28));
console.log('running 2026-10-28:', run.map(p => p.lord).join(' / '));
truthy('running chain has 4 levels', run.length === 4);
truthy('running chain nested', run.every((p, i) => i === 0 || (p.fullStart >= run[i - 1].fullStart - 1 && p.fullEnd <= run[i - 1].fullEnd + 1)));

// 11. Time zones
const ny = C.parseZone('America/New_York');
check('NY offset Oct 28 2026 (h)', ny.offsetAt(Date.UTC(2026, 9, 28, 16)) / 3600000, -4, 0);
check('NY offset Dec 1 2026 (h)', ny.offsetAt(Date.UTC(2026, 11, 1, 16)) / 3600000, -5, 0);
check('localToUtc NY 2026-10-28 12:00 -> 16:00Z', C.localToUtc(2026, 10, 28, 12, 0, 0, ny), Date.UTC(2026, 9, 28, 16), 0);
check('localToUtc NY 1950-07-01 12:00 -> 16:00Z', C.localToUtc(1950, 7, 1, 12, 0, 0, ny), Date.UTC(1950, 6, 1, 16), 0);
check('Kolkata +5.5h', C.localToUtc(1990, 6, 15, 9, 0, 0, C.parseZone('Asia/Kolkata')), Date.UTC(1990, 5, 15, 3, 30), 0);
check('fixed +05:30', C.localToUtc(1990, 6, 15, 9, 0, 0, C.parseZone('+05:30')), Date.UTC(1990, 5, 15, 3, 30), 0);
check('fixed UTC-4', C.localToUtc(2026, 10, 28, 12, 0, 0, C.parseZone('UTC-4')), Date.UTC(2026, 9, 28, 16), 0);
truthy('bad zone returns null', C.parseZone('Nowhere/Land') === null);

// 12. End-to-end chart with the mock (fixed star): structure and consistency
const ch = C.chart({ ms: Date.UTC(2000, 0, 1, 12), lat: 51.4769, lon: -0.0005, nodeType: 'mean' });
truthy('9 bodies', ch.bodies.length === 9);
const ra = ch.bodies.find(b => b.id === 'Rahu'), ke = ch.bodies.find(b => b.id === 'Ketu');
check('Ketu opposite Rahu', ((ke.trop - ra.trop + 540) % 360) - 180, 180 > 0 ? 0 : 0, 180.0001);
check('sid = trop - ayanamsa (Sun)', (ch.bodies[0].trop - ch.bodies[0].sid + 360) % 360, ch.ayanamsa, 1e-9);
check('house of body in ascendant sign is 1', (() => { const s = ch.asc.sign; const b = { sign: s }; return ((b.sign - ch.asc.sign + 12) % 12) + 1; })(), 1, 0);
console.log(ch.bodies.map(b => b.id + ' ' + b.signName + ' ' + b.degInSign.toFixed(2) + ' | ' + b.nak.name + ' p' + b.nak.pada + ' | H' + b.house).join('\n'));
console.log('Asc', ch.asc.signName, ch.asc.degInSign.toFixed(2), ch.asc.nak.name);

console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED');
process.exit(fails ? 1 : 0);
