const C = require('./core.js')(() => ({ x: 1, y: 0, z: 0 }));
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; if (!cond || process.env.V) console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const sep = (a, b) => { const d = ((a - b) % 360 + 540) % 360 - 180; return Math.abs(d); };
const dms = d => { const t = Math.round(d * 3600); return Math.floor(t / 3600) + '°' + Math.floor(t % 3600 / 60) + "'" + (t % 60) + '"'; };

// ---- Ayanamsa modes
const J2K = Date.UTC(2000, 0, 1, 12);
const dh = C.dhruvaAyanamsa(J2K, 'dhruva').ayanamsa, wi = C.dhruvaAyanamsa(J2K, 'wilhelm').ayanamsa;
console.log('J2000  Dhruva (computed) ' + dms(dh) + '   Wilhelm ' + dms(wi) + '   offset ' + ((wi - dh) * 3600).toFixed(2) + '"');
ok('Wilhelm mode reads 20°11\'11" at 2000-01-01 12h', Math.abs(wi - (20 + 11 / 60 + 11 / 3600)) < 1e-9);
ok('computed Dhruva unchanged at 20°10\'52"', dms(dh) === '20°10\'52"');
for (const ms of [Date.UTC(1900, 0, 1), Date.UTC(1961, 7, 5), Date.UTC(2026, 9, 28), Date.UTC(2100, 0, 1)]) {
  const d = C.dhruvaAyanamsa(ms, 'wilhelm').ayanamsa - C.dhruvaAyanamsa(ms, 'dhruva').ayanamsa;
  ok('offset is constant (' + new Date(ms).toISOString().slice(0, 4) + ')', Math.abs(d - (wi - dh)) < 1e-12);
}
const gcW = C.dhruvaAyanamsa(J2K, 'wilhelm').gcSidereal;
console.log('Galactic Center with Wilhelm\'s value: ' + dms(gcW - 240) + ' Sagittarius sidereal (mid-Mula is 6°40\')');
ok('GC sits about 6°39.7\' Sag with Wilhelm\'s value', Math.abs((gcW - 240) * 60 - 399.7) < 0.3);
C.setAyanamsaMode('wilhelm');
const chW = C.chart({ ms: J2K, lat: 51.48, lon: 0 });
C.setAyanamsaMode('dhruva');
const chD = C.chart({ ms: J2K, lat: 51.48, lon: 0 });
ok('global mode shifts every sidereal longitude by the offset', chW.bodies.every((b, i) => Math.abs(((chD.bodies[i].sid - b.sid) - (wi - dh))) < 1e-9) && chW.ayMode === 'wilhelm' && chD.ayMode === 'dhruva');
ok('tropical positions untouched by the mode', chW.bodies.every((b, i) => b.trop === chD.bodies[i].trop));

// ---- Campanus: vector construction vs classical pole-height form
let worst = 0, cases = 0;
for (let lat = -60; lat <= 60; lat += 7.5) for (let k = 0; k < 24; k++) {
  const ms = Date.UTC(1990, 0, 1) + k * 3.7 * 3600000 + lat * 1e6;
  const v = C.campanusCusps(ms, lat, 13.4).cusps, p = C.campanusPoleForm(ms, lat, 13.4);
  for (let i = 0; i < 12; i++) worst = Math.max(worst, sep(v[i], p[i]));
  cases++;
}
ok('vector and pole-height Campanus agree (' + cases + ' charts, 12 cusps each)', worst < 1e-7, 'worst ' + worst.toExponential(2) + '°');
for (const [lat, lon, ms] of [[51.48, 0, J2K], [21.3, -157.85, Date.UTC(1961, 7, 5, 5, 24)], [-33.87, 151.21, Date.UTC(2026, 9, 28, 20)], [0, 0, Date.UTC(2000, 2, 20, 6)], [59.9, 10.7, Date.UTC(1985, 5, 21, 23)]]) {
  const r = C.campanusCusps(ms, lat, lon), c = r.cusps;
  ok('cusp 1 = ascendant, cusp 10 = MC (lat ' + lat + ')', sep(c[0], r.asc) < 1e-9 && sep(c[9], r.mc) < 1e-9);
  ok('opposite cusps 180° apart (lat ' + lat + ')', [0, 1, 2, 3, 4, 5].every(i => Math.abs(sep(c[i], c[i + 6]) - 180) < 1e-9));
  ok('cusps run in zodiacal order (lat ' + lat + ')', c.every((x, i) => { const d = ((c[(i + 1) % 12] - x) % 360 + 360) % 360; return d > 0 && d < 180; }));
}
// At the equator with RAMC 0 the ecliptic is symmetric: cusp 11 and cusp 3 mirror around the MC/IC axis
{ const ms0 = J2K, ramc = C.gast(ms0); const r = C.campanusCusps(ms0, 0, -ramc); ok('equator, RAMC 0: MC at 0° Aries, ASC at 0° Cancer', sep(r.cusps[9], 0) < 1e-6 && sep(r.cusps[0], 90) < 1e-6); ok('equator symmetry: cusp 11 and cusp 9 mirror about the MC', Math.abs(sep(r.cusps[10], 0) - sep(r.cusps[8], 0)) < 1e-6); }
// Published Campanus cusps for 1 Jan 2000 12:00 UT Greenwich (computed values printed for inspection)
{ const r = C.campanusCusps(J2K, 51.4769, -0.0005); const S = ['Ari', 'Tau', 'Gem', 'Can', 'Leo', 'Vir', 'Lib', 'Sco', 'Sag', 'Cap', 'Aqu', 'Pis'];
  console.log('Greenwich 2000-01-01 12h Campanus: ' + r.cusps.map((c, i) => (i + 1) + ' ' + S[Math.floor(c / 30)] + ' ' + (c % 30).toFixed(2)).join(' | ')); }

// ---- bhava placement conventions, equal cusps at 0, 30, 60 ...
const eq = Array.from({ length: 12 }, (_, i) => i * 30);
[[15, 'start', 1], [15, 'end', 2], [14.9, 'middle', 1], [15, 'middle', 2], [359, 'start', 12], [359, 'end', 1], [0, 'start', 1], [0, 'end', 1], [0.1, 'end', 2], [344.9, 'middle', 12], [345, 'middle', 1]]
  .forEach(([l, m, w]) => ok('bhava of ' + l + '° with cusp as ' + m + ' = ' + w, C.bhavaOf(l, eq, m) === w, 'got ' + C.bhavaOf(l, eq, m)));
const uneven = [100, 125, 160, 200, 240, 260, 280, 305, 340, 20, 60, 80];
ok('uneven cusps wrap through 0° Aries', C.bhavaOf(5, uneven, 'start') === 9 && C.bhavaOf(70, uneven, 'start') === 11 && C.bhavaOf(90, uneven, 'start') === 12);

// ---- bhavaCusps analysis (appended)
{
  const ch = C.chart({ ms: J2K, lat: 51.4769, lon: -0.0005 });
  const bc = C.bhavaCusps(ch, 'tropical'), bs = C.bhavaCusps(ch, 'sidereal');
  const chk = (n2, c) => { if (!c) { console.log('FAIL ' + n2); fails++; } };
  chk('12 cusps', bc.cusps.length === 12);
  chk('cusp 1 in the lagna sign = rasi house 1', bc.cusps[0].rasiHouse === 1 && bs.cusps[0].rasiHouse === 1);
  chk('cusp lords follow the sign', bc.cusps.every(c => c.lord === C.SIGN_LORD[c.sign]));
  chk('sidereal cusp = tropical - ayanamsa', bc.cusps.every(c => Math.abs(((c.trop - c.sid + 360) % 360) - ch.ayanamsa) < 1e-9));
  chk('nearby planets within the orb, nearest first', bc.cusps.every(c => c.near.every((x, i) => x.dist <= 15 && (i === 0 || x.dist >= c.near[i - 1].dist))));
  chk('placements for 9 bodies in each convention', ['start', 'middle', 'end'].every(m => bc.place(m).length === 9 && bc.place(m).every(p => p.bhava >= 1 && p.bhava <= 12)));
  n += 6;
}

console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
