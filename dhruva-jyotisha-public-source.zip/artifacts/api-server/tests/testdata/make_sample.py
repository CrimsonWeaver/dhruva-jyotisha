# Test-only GeoNames-format sample: zone.tab reference cities plus hand-made edge cases. Never shipped.
import re
rows = []
def row(gid, name, ascii_, alts, lat, lon, cc, a1, pop, tz):
    rows.append('\t'.join(map(str, [gid, name, ascii_, alts, lat, lon, 'P', 'PPL', cc, '', a1, '', '', '', pop, '', '', tz, '2024-01-01'])))
def dm(s, deg_digits):
    sign = -1 if s[0] == '-' else 1; s = s[1:]
    d, m = int(s[:deg_digits]), int(s[deg_digits:deg_digits + 2]); sec = int(s[deg_digits + 2:deg_digits + 4] or 0)
    return sign * (d + m / 60 + sec / 3600)
gid = 1
for line in open('/usr/share/zoneinfo/zone1970.tab'):
    if line.startswith('#'): continue
    p = line.rstrip('\n').split('\t')
    m = re.match(r'([+-]\d+)([+-]\d+)', p[1])
    la, lo = m.group(1), m.group(2)
    lat, lon = dm(la, 2), dm(lo, 3)
    name = p[2].split('/')[-1].replace('_', ' ')
    row(gid, name, name, '', round(lat, 4), round(lon, 4), p[0].split(',')[0], '00', 100000 + gid, p[2]); gid += 1
# edge cases
row(9001, 'Springfield', 'Springfield', '', 39.8017, -89.6437, 'US', 'IL', 114394, 'America/Chicago')
row(9002, 'Springfield', 'Springfield', '', 37.2153, -93.2982, 'US', 'MO', 169176, 'America/Chicago')
row(9003, 'Springfield', 'Springfield', '', 42.1015, -72.5898, 'US', 'MA', 155929, 'America/New_York')
row(9004, 'Mumbai', 'Mumbai', 'BOM,Bombay,Bombaim,Mumbai,ムンバイ,Мумбаи', 19.0728, 72.8826, 'IN', '16', 12691836, 'Asia/Kolkata')
row(9005, 'São Paulo', 'Sao Paulo', 'Sampa,San Paulo,Сан-Паулу', -23.5475, -46.6361, 'BR', '27', 10021295, 'America/Sao_Paulo')
row(9006, 'Zürich', 'Zurich', 'Zurich,Zurigo', 47.3667, 8.55, 'CH', 'ZH', 341730, 'Europe/Zurich')
row(9007, 'Ulm', 'Ulm', 'Ulm', 48.3984, 9.9916, 'DE', '01', 126329, 'Europe/Berlin')
row(9008, 'Tiny Hamlet', 'Tiny Hamlet', 'Old Name', 51.0, -1.0, 'GB', 'ENG', 1200, 'Europe/London')
row(9009, 'New York City', 'New York City', 'NYC,New York', 40.7143, -74.006, 'US', 'NY', 8804190, 'America/New_York')
row(9010, 'York', 'York', '', 53.9576, -1.0827, 'GB', 'ENG', 153717, 'Europe/London')
open('testdata/sample_cities.txt', 'w').write('\n'.join(rows) + '\n')
open('testdata/sample_admin1.txt', 'w').write('US.IL\tIllinois\tIllinois\t1\nUS.MO\tMissouri\tMissouri\t2\nUS.MA\tMassachusetts\tMassachusetts\t3\nIN.16\tMaharashtra\tMaharashtra\t4\nBR.27\tSão Paulo\tSao Paulo\t5\nCH.ZH\tZurich\tZurich\t6\nDE.01\tBaden-Württemberg\tBaden-Wuerttemberg\t7\nGB.ENG\tEngland\tEngland\t8\nUS.NY\tNew York\tNew York\t9\n')
print(len(rows), 'sample rows')
