/* Dhruva Jyotisha calculation core.
   createCore(getVector) takes getVector(bodyName, Date) -> {x,y,z} geocentric EQJ (J2000 equatorial), AU.
   Everything else (precession, nutation, ayanamsa, ascendant, nodes, dasa) is computed here. */
function createCore(getVector) {
  var D2R = Math.PI / 180, R2D = 180 / Math.PI;
  var norm = function (a) { return ((a % 360) + 360) % 360; };
  var sin = function (a) { return Math.sin(a * D2R); };
  var cos = function (a) { return Math.cos(a * D2R); };

  var SIGNS = [
    ['Aries', 'Mesha'], ['Taurus', 'Vrishabha'], ['Gemini', 'Mithuna'], ['Cancer', 'Karka'],
    ['Leo', 'Simha'], ['Virgo', 'Kanya'], ['Libra', 'Tula'], ['Scorpio', 'Vrishchika'],
    ['Sagittarius', 'Dhanu'], ['Capricorn', 'Makara'], ['Aquarius', 'Kumbha'], ['Pisces', 'Meena']
  ];
  var NAKSHATRAS = [
    ['Ashwini', 'अश्विनी'], ['Bharani', 'भरणी'], ['Krittika', 'कृत्तिका'], ['Rohini', 'रोहिणी'],
    ['Mrigashira', 'मृगशिरा'], ['Ardra', 'आर्द्रा'], ['Punarvasu', 'पुनर्वसु'], ['Pushya', 'पुष्य'],
    ['Ashlesha', 'आश्लेषा'], ['Magha', 'मघा'], ['Purva Phalguni', 'पूर्व फाल्गुनी'],
    ['Uttara Phalguni', 'उत्तर फाल्गुनी'], ['Hasta', 'हस्त'], ['Chitra', 'चित्रा'], ['Swati', 'स्वाति'],
    ['Vishakha', 'विशाखा'], ['Anuradha', 'अनुराधा'], ['Jyeshtha', 'ज्येष्ठा'], ['Mula', 'मूल'],
    ['Purva Ashadha', 'पूर्वाषाढ़ा'], ['Uttara Ashadha', 'उत्तराषाढ़ा'], ['Shravana', 'श्रवण'],
    ['Dhanishta', 'धनिष्ठा'], ['Shatabhisha', 'शतभिषा'], ['Purva Bhadrapada', 'पूर्व भाद्रपदा'],
    ['Uttara Bhadrapada', 'उत्तर भाद्रपदा'], ['Revati', 'रेवती']
  ];
  var DASA_ORDER = ['Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury'];
  var DASA_YEARS = { Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7, Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17 };
  var NAK_SPAN = 360 / 27;

  /* Dhruva: the Galactic Center (Sgr A*) is held at the middle of Mula, 6°40' Sagittarius sidereal. */
  var GC_RA = (17 + 45 / 60 + 40.0409 / 3600) * 15;   // J2000, degrees
  var GC_DEC = -(29 + 0 / 60 + 28.118 / 3600);        // J2000, degrees
  var GC_SIDEREAL = 246 + 40 / 60;                    // 6°40' Sagittarius

  function jdOf(ms) { return ms / 86400000 + 2440587.5; }
  function tOf(ms) { return (jdOf(ms) - 2451545) / 36525; }

  /* Nutation in longitude and obliquity (Meeus ch. 22, short series, ~0.5"). Degrees. */
  function nutation(T) {
    var om = 125.04452 - 1934.136261 * T;
    var L = 280.4665 + 36000.7698 * T;
    var Lp = 218.3165 + 481267.8813 * T;
    return {
      dpsi: (-17.20 * sin(om) - 1.32 * sin(2 * L) - 0.23 * sin(2 * Lp) + 0.21 * sin(2 * om)) / 3600,
      deps: (9.20 * cos(om) + 0.57 * cos(2 * L) + 0.10 * cos(2 * Lp) - 0.09 * cos(2 * om)) / 3600
    };
  }
  function meanObliquity(T) {
    return (84381.448 - 46.8150 * T - 0.00059 * T * T + 0.001813 * T * T * T) / 3600;
  }

  /* J2000 equatorial (RA, Dec in degrees) -> ecliptic longitude/latitude of date, true equinox. */
  function eqjToTrueEcliptic(raDeg, decDeg, T) {
    var ra = raDeg * D2R, dec = decDeg * D2R;
    var zeta = (2306.2181 * T + 0.30188 * T * T + 0.017998 * T * T * T) / 3600 * D2R;
    var z = (2306.2181 * T + 1.09468 * T * T + 0.018203 * T * T * T) / 3600 * D2R;
    var th = (2004.3109 * T - 0.42665 * T * T - 0.041833 * T * T * T) / 3600 * D2R;
    var A = Math.cos(dec) * Math.sin(ra + zeta);
    var B = Math.cos(th) * Math.cos(dec) * Math.cos(ra + zeta) - Math.sin(th) * Math.sin(dec);
    var C = Math.sin(th) * Math.cos(dec) * Math.cos(ra + zeta) + Math.cos(th) * Math.sin(dec);
    var ra2 = Math.atan2(A, B) + z;
    var dec2 = Math.asin(C);
    var eps = meanObliquity(T) * D2R;
    var lon = Math.atan2(Math.sin(ra2) * Math.cos(eps) + Math.tan(dec2) * Math.sin(eps), Math.cos(ra2)) * R2D;
    var lat = Math.asin(Math.sin(dec2) * Math.cos(eps) - Math.cos(dec2) * Math.sin(eps) * Math.sin(ra2)) * R2D;
    return { lon: norm(lon + nutation(T).dpsi), lat: lat };
  }

  function bodyLongitude(name, ms) {
    var v = getVector(name, new Date(ms));
    var ra = Math.atan2(v.y, v.x) * R2D;
    var dec = Math.atan2(v.z, Math.hypot(v.x, v.y)) * R2D;
    return eqjToTrueEcliptic(ra, dec, tOf(ms));
  }

  /* Dhruva ayanamsa: true-of-date tropical longitude of the Galactic Center minus 246°40'.
     Mode 'wilhelm' shifts it by a constant so that it reads 20°11'11" on 2000-01-01 (12h UT),
     the value Ernst Wilhelm suggested for the mid-Mula ayanamsa; it then moves with the same precession and nutation. */
  var WILHELM_2000 = 20 + 11 / 60 + 11 / 3600, J2000_MS = Date.UTC(2000, 0, 1, 12);
  var ayMode = 'dhruva', wilhelmOffset = null;
  function rawAyanamsa(ms) { return norm(eqjToTrueEcliptic(GC_RA, GC_DEC, tOf(ms)).lon - GC_SIDEREAL); }
  function ayanamsaOffset(mode) {
    if (mode !== 'wilhelm') return 0;
    if (wilhelmOffset === null) wilhelmOffset = WILHELM_2000 - rawAyanamsa(J2000_MS);
    return wilhelmOffset;
  }
  /* Standard ayanamshas, as the Swiss Ephemeris defines them: the mean value at J2000.0 (TT), carried to the date
     with the general precession in longitude (IAU 2006). Sidereal longitudes are then mean-equinox longitudes less
     this value, which for the true-equinox longitudes used here means subtracting the nutation in longitude too. */
  var STD_AYANAMSA = {
    lahiri: { name: 'Lahiri', j2000: 23.857092 },
    fagan: { name: 'Fagan Bradley', j2000: 24.7403 },
    krishnamurti: { name: 'Krishnamurti', j2000: 23.7602 },
    raman: { name: 'Raman', j2000: 22.4108 },
    ushashashi: { name: 'Ushâshashî', j2000: 20.0575 },
    yukteshwar: { name: 'Sri Yukteshwar', j2000: 22.4788 }
  };
  function generalPrecession(T) { return (5028.796195 * T + 1.1054348 * T * T + 0.00007964 * T * T * T) / 3600; }
  function standardAyanamsa(ms, mode) {
    var T = tOf(ms), mean = STD_AYANAMSA[mode].j2000 + generalPrecession(T);
    return { mean: mean, ayanamsa: mean + nutation(T).dpsi };
  }
  function setAyanamsaMode(mode) { ayMode = (mode === 'wilhelm' || mode === 'equatorial' || STD_AYANAMSA[mode]) ? mode : 'dhruva'; return ayMode; }

  /* Equatorial Dhruva, as Kala and Vault of the Heavens apply it: a planet's nakshatra comes from its right
     ascension (true equator of date) minus the right ascension of the Galactic Center less 246°40', so the
     Galactic Center sits at mid-Mula measured along the celestial equator. Points on the ecliptic itself (the
     ascendant and house cusps) take their ecliptic longitude minus that same offset. */
  function raFromEcl(lonDeg, latDeg, epsDeg) {
    var l = lonDeg * D2R, b = latDeg * D2R, e = epsDeg * D2R;
    return norm(Math.atan2(Math.sin(l) * Math.cos(e) - Math.tan(b) * Math.sin(e), Math.cos(l)) * R2D);
  }
  function trueObliquity(ms) { var T = tOf(ms); return meanObliquity(T) + nutation(T).deps; }
  function equatorialOffset(ms) {
    var gc = eqjToTrueEcliptic(GC_RA, GC_DEC, tOf(ms));
    return norm(raFromEcl(gc.lon, gc.lat, trueObliquity(ms)) - GC_SIDEREAL);
  }
  function dhruvaAyanamsa(ms, mode) {
    var gc = eqjToTrueEcliptic(GC_RA, GC_DEC, tOf(ms));
    var m = mode || ayMode;
    if (STD_AYANAMSA[m]) { var st = standardAyanamsa(ms, m); return { ayanamsa: st.ayanamsa, mean: st.mean, standard: true, gcLon: gc.lon, gcLat: gc.lat, gcSidereal: norm(gc.lon - st.ayanamsa), mode: m }; }
    if (m === 'equatorial') { var off = equatorialOffset(ms); return { ayanamsa: off, gcLon: gc.lon, gcLat: gc.lat, gcSidereal: GC_SIDEREAL, mode: m }; }
    var ay = norm(gc.lon - GC_SIDEREAL + ayanamsaOffset(m));
    return { ayanamsa: ay, gcLon: gc.lon, gcLat: gc.lat, gcSidereal: norm(gc.lon - ay), mode: m };
  }
  /* Sidereal longitude used for nakshatras, in any mode, for a body at tropical longitude/latitude. */
  function siderealOf(tropDeg, latDeg, ms, mode) {
    var m = mode || ayMode;
    if (m === 'equatorial') return norm(raFromEcl(tropDeg, latDeg || 0, trueObliquity(ms)) - equatorialOffset(ms));
    return norm(tropDeg - dhruvaAyanamsa(ms, m).ayanamsa);
  }

  /* Lunar node, Meeus ch. 47. Mean node plus optional periodic terms for the true node. */
  function lunarNode(ms, type) {
    if (type === 'interpolated') return interpolatedNode(ms).rahu;
    var T = tOf(ms), T2 = T * T, T3 = T2 * T, T4 = T3 * T;
    var om = 125.0445479 - 1934.1362891 * T + 0.0020754 * T2 + T3 / 467441 - T4 / 60616000;
    if (type === 'true') {
      var D = 297.8501921 + 445267.1114034 * T - 0.0018819 * T2 + T3 / 545868 - T4 / 113065000;
      var M = 357.5291092 + 35999.0502909 * T - 0.0001536 * T2 + T3 / 24490000;
      var Mp = 134.9633964 + 477198.8675055 * T + 0.0087414 * T2 + T3 / 69699 - T4 / 14712000;
      var F = 93.2720950 + 483202.0175233 * T - 0.0036539 * T2 - T3 / 3526000 + T4 / 863310000;
      om += -1.4979 * sin(2 * (D - F)) - 0.1500 * sin(M) - 0.1226 * sin(2 * D) +
        0.1176 * sin(2 * F) - 0.0801 * sin(2 * (Mp - F));
    }
    return norm(om + nutation(T).dpsi);   // referred to the true equinox like the planets
  }

  /* Interpolated true node: Rahu sampled where the Moon actually crosses the ecliptic (northward = Rahu,
     southward = Ketu, so Rahu = Moon + 180°), then a cubic through the two crossings before and the two after. */
  function moonCrossings(ms, dir, count) {
    var lat = function (t) { return bodyLongitude('Moon', t).lat; };
    var out = [], t = ms, prev = lat(t), step = 86400000 * dir, guard = 0;
    while (out.length < count && guard < 80) {
      var t2 = t + step, cur = lat(t2); guard++;
      if ((prev < 0) !== (cur < 0)) {
        var lo = Math.min(t, t2), hi = Math.max(t, t2), flo = lat(lo), rising = flo < 0;
        for (var i = 0; i < 36; i++) { var mid = (lo + hi) / 2, fm = lat(mid); if ((fm < 0) === (flo < 0)) { lo = mid; flo = fm; } else hi = mid; }
        var tc = (lo + hi) / 2, mlon = bodyLongitude('Moon', tc).lon;
        out.push({ ms: tc, rahu: norm(rising ? mlon : mlon + 180), ascending: rising });
      }
      t = t2; prev = cur;
    }
    return out;
  }
  function interpolatedNode(ms) {
    var before = moonCrossings(ms, -1, 2), after = moonCrossings(ms, 1, 2);
    if (before.length < 2 || after.length < 2) return { rahu: lunarNode(ms, 'true'), fallback: true };
    var pts = [before[1], before[0], after[0], after[1]];
    var ys = [pts[0].rahu];                                   // unwrap around the circle
    for (var i = 1; i < 4; i++) ys.push(ys[i - 1] + ((pts[i].rahu - pts[i - 1].rahu + 540) % 360) - 180);
    var x = ms, v = 0;
    for (var j = 0; j < 4; j++) {
      var w = 1;
      for (var k = 0; k < 4; k++) if (k !== j) w *= (x - pts[k].ms) / (pts[j].ms - pts[k].ms);
      v += w * ys[j];
    }
    return { rahu: norm(v), before: before[0], after: after[0], points: pts, fallback: false };
  }

  /* Greenwich apparent sidereal time, degrees. */
  function gast(ms) {
    var T = tOf(ms), jd = jdOf(ms);
    var gmst = 280.46061837 + 360.98564736629 * (jd - 2451545) + 0.000387933 * T * T - T * T * T / 38710000;
    var n = nutation(T);
    var eps = meanObliquity(T) + n.deps;
    return norm(gmst + n.dpsi * cos(eps));
  }

  function angles(ms, latDeg, lonDeg) {
    var T = tOf(ms);
    var eps = meanObliquity(T) + nutation(T).deps;
    var ramc = norm(gast(ms) + lonDeg);
    var asc = Math.atan2(cos(ramc), -(sin(ramc) * cos(eps) + Math.tan(latDeg * D2R) * sin(eps))) * R2D;
    var mc = Math.atan2(sin(ramc), cos(ramc) * cos(eps)) * R2D;
    return { asc: norm(asc), mc: norm(mc), ramc: ramc, eps: eps };
  }

  /* ---------- Campanus house cusps ----------
     The prime vertical is divided into twelve 30° arcs from the east point; each house circle passes through the
     north and south points of the horizon and one division, and its cusp is where it cuts the ecliptic.
     Worked as vectors in the true equatorial frame of date. */
  function campanusCusps(ms, latDeg, lonDeg) {
    var a = angles(ms, latDeg, lonDeg), th = a.ramc * D2R, phi = latDeg * D2R, eps = a.eps * D2R;
    var Z = [Math.cos(phi) * Math.cos(th), Math.cos(phi) * Math.sin(th), Math.sin(phi)];
    var E = [-Math.sin(th), Math.cos(th), 0];
    var N = [-Math.sin(phi) * Math.cos(th), -Math.sin(phi) * Math.sin(th), Math.cos(phi)];
    var K = [0, -Math.sin(eps), Math.cos(eps)];
    var cross = function (u, v) { return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; };
    var dot = function (u, v) { return u[0] * v[0] + u[1] * v[1] + u[2] * v[2]; };
    var cusps = [];
    for (var h = 1; h <= 12; h++) {
      var t = ((13 - h) * 30 % 360) * D2R;                    // 0 at the east point, 90 at the zenith
      var P = [Math.cos(t) * E[0] + Math.sin(t) * Z[0], Math.cos(t) * E[1] + Math.sin(t) * Z[1], Math.cos(t) * E[2] + Math.sin(t) * Z[2]];
      var X = cross(cross(N, P), K);
      if (dot(X, P) < 0) X = [-X[0], -X[1], -X[2]];
      cusps.push(norm(Math.atan2(X[1] * Math.cos(eps) + X[2] * Math.sin(eps), X[0]) * R2D));
    }
    return { cusps: cusps, asc: a.asc, mc: a.mc, ramc: a.ramc, eps: a.eps };
  }
  /* Independent check: the classical pole-height form (the same construction written as oblique ascensions). */
  function campanusPoleForm(ms, latDeg, lonDeg) {
    var a = angles(ms, latDeg, lonDeg), e = a.eps;
    var at = function (r, f) { return norm(Math.atan2(cos(r), -(sin(r) * cos(e) + Math.tan(f * D2R) * sin(e))) * R2D); };
    var cf = cos(latDeg), sf = sin(latDeg);
    var xh1 = Math.atan2(Math.sqrt(3), cf) * R2D, xh2 = Math.atan2(1, Math.sqrt(3) * cf) * R2D;
    var fh1 = Math.asin(sf / 2) * R2D, fh2 = Math.asin(Math.sqrt(3) / 2 * sf) * R2D;
    var c = [];
    c[0] = a.asc; c[9] = a.mc;
    c[10] = at(a.ramc - xh1, fh1); c[11] = at(a.ramc - xh2, fh2);
    c[1] = at(a.ramc + xh2, fh2); c[2] = at(a.ramc + xh1, fh1);
    for (var i = 3; i < 9; i++) c[i] = norm(c[(i + 6) % 12] + 180);
    return c;
  }
  /* The bhava (1-12) of a longitude with cusps marking the start, middle or end of each bhava. */
  function bhavaOf(lonDeg, cusps, mode) {
    var arc = function (a, b) { return norm(b - a); };
    var start = function (h) {          // longitude where bhava h (0-based) begins
      var c = cusps[h], prev = cusps[(h + 11) % 12];
      if (mode === 'end') return prev;
      if (mode === 'middle') return norm(prev + arc(prev, c) / 2);
      return c;
    };
    for (var h = 0; h < 12; h++) {
      var s = start(h), e = start((h + 1) % 12), x = arc(s, lonDeg), w = arc(s, e);
      if (mode === 'end' ? (x > 0 && x <= w) : x < w) return h + 1;   // a point on a cusp belongs to the bhava that cusp ends
    }
    return 1;
  }

  function signOf(lon) { return Math.floor(norm(lon) / 30); }
  function nakshatraOf(sid) {
    sid = norm(sid);
    var i = Math.floor(sid / NAK_SPAN);
    var into = sid - i * NAK_SPAN;
    return {
      index: i,
      name: NAKSHATRAS[i][0],
      sanskrit: NAKSHATRAS[i][1],
      lord: DASA_ORDER[i % 9],
      pada: Math.min(4, Math.floor(into / (NAK_SPAN / 4)) + 1),
      fraction: into / NAK_SPAN
    };
  }

  var BODIES = [
    { id: 'Sun', abbr: 'Su' }, { id: 'Moon', abbr: 'Mo' }, { id: 'Mars', abbr: 'Ma' },
    { id: 'Mercury', abbr: 'Me' }, { id: 'Jupiter', abbr: 'Ju' }, { id: 'Venus', abbr: 'Ve' },
    { id: 'Saturn', abbr: 'Sa' }, { id: 'Rahu', abbr: 'Ra' }, { id: 'Ketu', abbr: 'Ke' }
  ];

  function chart(opts) {
    var ms = opts.ms;
    var ay = dhruvaAyanamsa(ms);
    var ang = angles(ms, opts.lat, opts.lon);
    var zsid = opts.zodiac === 'sidereal';   // which zodiac the signs, degrees and whole-sign houses are read in
    var ascSidLon = norm(ang.asc - ay.ayanamsa);
    var ascSign = signOf(zsid ? ascSidLon : ang.asc);
    var nodeType = opts.nodeType || 'mean', nodeInfo = null, rahu;
    if (nodeType === 'interpolated') { nodeInfo = interpolatedNode(ms); rahu = nodeInfo.rahu; }
    else rahu = lunarNode(ms, nodeType);
    var out = [];
    var epsTrue = ang.eps * D2R;
    BODIES.forEach(function (b) {
      var trop, speed, eclLat = 0;
      if (b.id === 'Rahu') { trop = rahu; speed = -0.053; }
      else if (b.id === 'Ketu') { trop = norm(rahu + 180); speed = -0.053; }
      else {
        var pos = bodyLongitude(b.id, ms);
        trop = pos.lon; eclLat = pos.lat;
        var a = bodyLongitude(b.id, ms - 43200000).lon, c = bodyLongitude(b.id, ms + 43200000).lon;
        speed = ((c - a + 540) % 360) - 180;   // deg/day
      }
      var sid = ay.mode === 'equatorial' ? norm(raFromEcl(trop, eclLat, ang.eps) - ay.ayanamsa) : norm(trop - ay.ayanamsa);
      var zl = zsid ? sid : trop, s = signOf(zl);
      var decl = Math.asin(Math.sin(eclLat * D2R) * Math.cos(epsTrue) + Math.cos(eclLat * D2R) * Math.sin(epsTrue) * sin(trop)) * R2D;
      out.push({
        id: b.id, abbr: b.abbr, trop: trop, sid: sid, speed: speed, eclLat: eclLat, decl: decl, retro: speed < 0 && b.id !== 'Sun' && b.id !== 'Moon',
        sign: s, signName: SIGNS[s][0], signSanskrit: SIGNS[s][1], degInSign: zl - s * 30, lon: zl,
        nak: nakshatraOf(sid), house: ((s - ascSign + 12) % 12) + 1
      });
    });
    var ascTrop = ang.asc, ascSid = norm(ascTrop - ay.ayanamsa);
    return {
      ms: ms, nodeType: nodeType, nodeInfo: nodeInfo, zodiac: zsid ? 'sidereal' : 'tropical', ayanamsa: ay.ayanamsa, ayanamsaMean: ay.mean, ayStandard: !!ay.standard, ayMode: ay.mode, gcLon: ay.gcLon, gcLat: ay.gcLat, gcSidereal: ay.gcSidereal, lat: opts.lat, lon: opts.lon,
      asc: { trop: ascTrop, sid: ascSid, sign: ascSign, signName: SIGNS[ascSign][0], signSanskrit: SIGNS[ascSign][1],
        degInSign: (zsid ? ascSid : ascTrop) - ascSign * 30, lon: zsid ? ascSid : ascTrop, nak: nakshatraOf(ascSid) },
      mc: { trop: ang.mc, sign: signOf(ang.mc), signName: SIGNS[signOf(ang.mc)][0], degInSign: ang.mc - signOf(ang.mc) * 30 },
      bodies: out
    };
  }

  /* ---------- Vimshottari ---------- */
  function buildDasa(moonSid, birthMs, yearMs) {
    var nak = nakshatraOf(moonSid);
    var li = nak.index % 9;
    var lord = DASA_ORDER[li];
    var elapsedYears = nak.fraction * DASA_YEARS[lord];
    var balanceYears = DASA_YEARS[lord] - elapsedYears;
    var t = birthMs - elapsedYears * yearMs;
    var list = [];
    for (var k = 0; k < 9; k++) {
      var L = DASA_ORDER[(li + k) % 9];
      var dur = DASA_YEARS[L] * yearMs;
      list.push({ lord: L, level: 0, fullStart: t, fullEnd: t + dur, parent: null });
      t += dur;
    }
    return { nak: nak, lord: lord, balanceYears: balanceYears, elapsedYears: elapsedYears, periods: list, birthMs: birthMs, yearMs: yearMs };
  }
  function subPeriods(p, birthMs) {
    var dur = p.fullEnd - p.fullStart;
    var li = DASA_ORDER.indexOf(p.lord);
    var t = p.fullStart, res = [];
    for (var k = 0; k < 9; k++) {
      var L = DASA_ORDER[(li + k) % 9];
      var d = dur * DASA_YEARS[L] / 120;
      res.push({ lord: L, level: p.level + 1, fullStart: t, fullEnd: t + d, parent: p });
      t += d;
    }
    return res.filter(function (x) { return x.fullEnd > birthMs; });
  }
  function runningAt(dasa, ms) {
    var chain = [];
    var level = dasa.periods;
    for (var depth = 0; depth < 4 && level && level.length; depth++) {
      var hit = null;
      for (var i = 0; i < level.length; i++) { if (ms >= level[i].fullStart && ms < level[i].fullEnd) { hit = level[i]; break; } }
      if (!hit) break;
      chain.push(hit);
      level = depth < 3 ? subPeriods(hit, dasa.birthMs) : null;
    }
    return chain;
  }

  /* ---------- Shadbala (Brihat Parashara Hora Shastra, ch. 27-28) ---------- */
  var SB = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
  var SIGN_LORD = ['Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter'];
  var EXALT = { Sun: 10, Moon: 33, Mars: 298, Mercury: 165, Jupiter: 95, Venus: 357, Saturn: 200 };
  var MOOLA = { Sun: [4, 0, 20], Moon: [1, 3, 30], Mars: [0, 0, 12], Mercury: [5, 16, 20], Jupiter: [8, 0, 10], Venus: [6, 0, 15], Saturn: [10, 0, 20] };
  var FRIENDS = { Sun: ['Moon', 'Mars', 'Jupiter'], Moon: ['Sun', 'Mercury'], Mars: ['Sun', 'Moon', 'Jupiter'], Mercury: ['Sun', 'Venus'],
    Jupiter: ['Sun', 'Moon', 'Mars'], Venus: ['Mercury', 'Saturn'], Saturn: ['Mercury', 'Venus'] };
  var ENEMIES = { Sun: ['Venus', 'Saturn'], Moon: [], Mars: ['Mercury'], Mercury: ['Moon'], Jupiter: ['Mercury', 'Venus'], Venus: ['Sun', 'Moon'],
    Saturn: ['Sun', 'Moon', 'Mars'] };
  var NAISARGIKA = { Sun: 60, Moon: 51.43, Venus: 42.85, Jupiter: 34.28, Mercury: 25.70, Mars: 17.14, Saturn: 8.57 };
  var REQUIRED = { Sun: 390, Moon: 360, Mars: 300, Mercury: 420, Jupiter: 390, Venus: 330, Saturn: 300 };
  var WEEKDAY_LORD = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
  var HORA_ORDER = ['Sun', 'Venus', 'Mercury', 'Moon', 'Saturn', 'Jupiter', 'Mars'];
  var MALE = ['Sun', 'Mars', 'Jupiter'], FEMALE = ['Moon', 'Venus'];
  var MEAN_L = { Mercury: [252.250906, 149474.0722491], Venus: [181.979801, 58519.2130302], Mars: [355.433275, 19141.6964746],
    Jupiter: [34.351484, 3036.3027889], Saturn: [50.077471, 1223.5110141] };
  var HR = 3600000;

  function arcDist(a, b) { var d = norm(a - b); return d > 180 ? 360 - d : d; }

  /* ---- Shodasavarga: the 16 divisional charts of BPHS ch. 6 ---- */
  var VARGAS = [
    { n: 1, name: 'Rasi', skt: 'राशि', area: 'Body and the life as a whole' },
    { n: 2, name: 'Hora', skt: 'होरा', area: 'Wealth' },
    { n: 3, name: 'Drekkana', skt: 'द्रेक्काण', area: 'Siblings, courage' },
    { n: 4, name: 'Chaturthamsa', skt: 'चतुर्थांश', area: 'Fortune, home and property' },
    { n: 7, name: 'Saptamsa', skt: 'सप्तांश', area: 'Children and grandchildren' },
    { n: 9, name: 'Navamsa', skt: 'नवांश', area: 'Spouse, dharma, inner strength' },
    { n: 10, name: 'Dasamsa', skt: 'दशांश', area: 'Career, status and power' },
    { n: 12, name: 'Dvadasamsa', skt: 'द्वादशांश', area: 'Parents' },
    { n: 16, name: 'Shodasamsa', skt: 'षोडशांश', area: 'Vehicles, comforts and happiness' },
    { n: 20, name: 'Vimsamsa', skt: 'विंशांश', area: 'Worship and spiritual pursuits' },
    { n: 24, name: 'Chaturvimsamsa', skt: 'चतुर्विंशांश', area: 'Learning and education' },
    { n: 27, name: 'Saptavimsamsa', skt: 'सप्तविंशांश', area: 'Strengths and weaknesses' },
    { n: 30, name: 'Trimsamsa', skt: 'त्रिंशांश', area: 'Misfortunes and difficulties' },
    { n: 40, name: 'Khavedamsa', skt: 'खवेदांश', area: 'Auspicious and inauspicious effects (maternal line)' },
    { n: 45, name: 'Akshavedamsa', skt: 'अक्षवेदांश', area: 'General character and well-being (paternal line)' },
    { n: 60, name: 'Shashtyamsa', skt: 'षष्ट्यंश', area: 'All matters; past karma' }
  ];
  var MOVABLE_FIXED_DUAL = function (s) { return s % 3; };   // 0 movable, 1 fixed, 2 dual

  /* Sign (0-11) occupied in the Dn chart by a longitude, per Parashara. */
  function vargaSign(L, n) {
    L = norm(L);
    var s = Math.floor(L / 30), d = L - s * 30, odd = s % 2 === 0, q = MOVABLE_FIXED_DUAL(s);
    var part = function (k) { return Math.min(k - 1, Math.floor(d * k / 30)); };
    switch (n) {
      case 1: return s;
      case 2: return (odd ? d < 15 : d >= 15) ? 4 : 3;                    // Sun's hora = Leo, Moon's hora = Cancer
      case 3: return (s + 4 * part(3)) % 12;                              // 1st, 5th, 9th from the sign
      case 4: return (s + 3 * part(4)) % 12;                              // 1st, 4th, 7th, 10th
      case 7: return (s + (odd ? 0 : 6) + part(7)) % 12;                  // odd from itself, even from the 7th
      case 9: return (s * 9 + part(9)) % 12;                              // fire Aries, earth Capricorn, air Libra, water Cancer
      case 10: return (s + (odd ? 0 : 8) + part(10)) % 12;                // odd from itself, even from the 9th
      case 12: return (s + part(12)) % 12;
      case 16: return ([0, 4, 8][q] + part(16)) % 12;                     // movable Aries, fixed Leo, dual Sagittarius
      case 20: return ([0, 8, 4][q] + part(20)) % 12;                     // movable Aries, fixed Sagittarius, dual Leo
      case 24: return ((odd ? 4 : 3) + part(24)) % 12;                    // odd from Leo, even from Cancer
      case 27: return (s * 27 + part(27)) % 12;                           // fire Aries, earth Cancer, air Libra, water Capricorn
      case 30:
        if (odd) return d < 5 ? 0 : d < 10 ? 10 : d < 18 ? 8 : d < 25 ? 2 : 6;   // Mars, Saturn, Jupiter, Mercury, Venus
        return d < 5 ? 1 : d < 12 ? 5 : d < 20 ? 11 : d < 25 ? 9 : 7;              // Venus, Mercury, Jupiter, Saturn, Mars
      case 40: return ((odd ? 0 : 6) + part(40)) % 12;                    // odd from Aries, even from Libra
      case 45: return ([0, 4, 8][q] + part(45)) % 12;                     // movable Aries, fixed Leo, dual Sagittarius
      case 60: return (s + part(60)) % 12;                                // counted from the sign itself
    }
    throw new Error('Unknown varga D' + n);
  }

  /* Sign (0-11) of a longitude in each of the seven vargas used for Saptavargaja bala. */
  function vargaSigns(L) {
    L = norm(L);
    var s = Math.floor(L / 30);
    return {
      d1: s, d2: vargaSign(L, 2), d3: vargaSign(L, 3), d7: vargaSign(L, 7), d9: vargaSign(L, 9), d12: vargaSign(L, 12), d30: vargaSign(L, 30),
      drekkana: Math.min(2, Math.floor((L - s * 30) / 10)), degInSign: L - s * 30
    };
  }

  /* Exaltation, debilitation and own-sign status of a graha in a sign. */
  function dignityIn(id, sign) {
    if (EXALT[id] == null) return '';
    var ex = Math.floor(EXALT[id] / 30);
    if (sign === ex) return 'ex';
    if (sign === (ex + 6) % 12) return 'db';
    if (SIGN_LORD[sign] === id) return 'own';
    return '';
  }

  /* All 16 vargas for the lagna and the nine grahas, in the chosen zodiac. */
  function vargaChart(ch, frame) {
    var sid = frame === 'sidereal';
    var ascL = sid ? ch.asc.sid : ch.asc.trop;
    var asc = {};
    VARGAS.forEach(function (v) { asc[v.n] = vargaSign(ascL, v.n); });
    var bodies = ch.bodies.map(function (b) {
      var L = sid ? b.sid : b.trop, signs = {}, dig = {};
      VARGAS.forEach(function (v) { signs[v.n] = vargaSign(L, v.n); dig[v.n] = dignityIn(b.id, signs[v.n]); });
      return { id: b.id, abbr: b.abbr, signs: signs, dignity: dig };
    });
    return { frame: sid ? 'sidereal' : 'tropical', asc: asc, bodies: bodies };
  }

  function relationPoints(p, q, sp, sq) {   // dignity of planet p in a sign owned by q (compound relationship)
    if (p === q) return 30;
    var nat = FRIENDS[p].indexOf(q) >= 0 ? 1 : ENEMIES[p].indexOf(q) >= 0 ? -1 : 0;
    var h = ((sq - sp + 12) % 12) + 1;
    var tmp = [2, 3, 4, 10, 11, 12].indexOf(h) >= 0 ? 1 : -1;
    if (nat === 1) return tmp === 1 ? 22.5 : 7.5;
    if (nat === 0) return tmp === 1 ? 15 : 3.75;
    return tmp === 1 ? 7.5 : 1.875;
  }

  function drishtiBase(d) {
    d = norm(d);
    if (d < 30) return 0;
    if (d < 60) return (d - 30) / 2;
    if (d < 90) return d - 45;
    if (d < 120) return 30 + (120 - d) / 2;
    if (d < 150) return 150 - d;
    if (d < 180) return (d - 150) * 2;
    if (d < 300) return (300 - d) / 2;
    return 0;
  }
  /* Sphuta drishti of `from` on a point `d` degrees ahead of it, with the special aspects added
     (Mars +15 at 90-120 and 210-240, Jupiter +30 at 120-150 and 240-270, Saturn +45 at 60-90 and 270-300), capped at 60. */
  function sphutaDrishti(from, d) {
    d = norm(d);
    var v = drishtiBase(d);
    if (from === 'Mars' && ((d >= 90 && d < 120) || (d >= 210 && d < 240))) v += 15;
    if (from === 'Jupiter' && ((d >= 120 && d < 150) || (d >= 240 && d < 270))) v += 30;
    if (from === 'Saturn' && ((d >= 60 && d < 90) || (d >= 270 && d < 300))) v += 45;
    return Math.min(60, v);
  }

  /* Cheshta kendra: distance of the "chalita" (mean of true and mean longitude) from the sheeghrocha. */
  function cheshtaKendraFrom(seeghra, madhya, trueLon) {
    var diff = ((trueLon - madhya + 540) % 360) - 180;
    var chalita = norm(madhya + diff / 2);
    var ck = norm(seeghra - chalita);
    return ck > 180 ? 360 - ck : ck;
  }

  /* ---- Sunrise, sunset and the Hindu day ---- */
  function sunAltitude(ms, lat, lon) {
    var T = tOf(ms), eps = (meanObliquity(T) + nutation(T).deps) * D2R;
    var s = bodyLongitude('Sun', ms), l = s.lon * D2R, b = s.lat * D2R;
    var ra = Math.atan2(Math.sin(l) * Math.cos(eps) - Math.tan(b) * Math.sin(eps), Math.cos(l));
    var dec = Math.asin(Math.sin(b) * Math.cos(eps) + Math.cos(b) * Math.sin(eps) * Math.sin(l));
    var H = (gast(ms) + lon) * D2R - ra, phi = lat * D2R;
    return Math.asin(Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(H)) * R2D;
  }
  /* Rise and set of the Sun's upper limb with standard refraction (altitude -0°50'), within 38 h either side of ms. */
  function sunEvents(ms, lat, lon) {
    var H0 = -0.8333, step = 1800000, start = ms - 38 * HR, end = ms + 38 * HR;
    var f = function (t) { return sunAltitude(t, lat, lon) - H0; };
    var rises = [], sets = [], pt = start, pv = f(start);
    for (var t = start + step; t <= end; t += step) {
      var cv = f(t);
      if ((pv < 0) !== (cv < 0)) {
        var lo = pt, hi = t, rising = pv < 0;
        for (var i = 0; i < 26; i++) { var mid = (lo + hi) / 2; if ((f(mid) < 0) === rising) lo = mid; else hi = mid; }
        (rising ? rises : sets).push((lo + hi) / 2);
      }
      pt = t; pv = cv;
    }
    return { rises: rises, sets: sets };
  }
  function weekdayAt(srMs, lon) { return (((Math.floor((srMs + lon * 240000) / 86400000) + 4) % 7) + 7) % 7; }

  /* The Hindu day containing ms: sunrise to sunrise, with the day/night split. */
  function hinduDay(ms, lat, lon) {
    var ev = sunEvents(ms, lat, lon), sr = null, nsr = null, ss = null, i;
    for (i = 0; i < ev.rises.length; i++) { if (ev.rises[i] <= ms) sr = ev.rises[i]; else if (nsr === null) nsr = ev.rises[i]; }
    if (sr !== null) { for (i = 0; i < ev.sets.length; i++) { if (ev.sets[i] > sr) { ss = ev.sets[i]; break; } } }
    var polar = false;
    if (sr === null || nsr === null || ss === null) {   // no usable sunrise (polar day or night): nominal 6h-18h local solar time
      polar = true;
      var local = ms + lon * 240000, dayStart = Math.floor(local / 86400000) * 86400000 - lon * 240000;
      sr = dayStart + 6 * HR; ss = dayStart + 18 * HR; nsr = sr + 24 * HR;
      if (ms < sr) { sr -= 24 * HR; ss -= 24 * HR; nsr -= 24 * HR; }
    }
    return { sr: sr, ss: ss, nsr: nsr, polar: polar, weekday: weekdayAt(sr, lon) };
  }

  function sunFrameLon(ms, frame) {
    var p = bodyLongitude('Sun', ms);
    return frame === 'sidereal' ? siderealOf(p.lon, p.lat, ms) : p.lon;
  }
  /* Last moment at or before ms when the Sun's longitude (in the chosen zodiac) passed `target`. */
  function lastIngress(ms, target, frame) {
    var step = 5 * 86400000, v = function (t) { return norm(sunFrameLon(t, frame) - target); };
    var hi = ms, lo = hi - step, n = 0;
    while (v(lo) < v(hi) && n < 90) { hi = lo; lo = hi - step; n++; }
    if (n >= 90) return null;
    for (var i = 0; i < 40; i++) { var mid = (lo + hi) / 2; if (v(mid) >= 180) lo = mid; else hi = mid; }
    return hi;
  }

  function timeFactors(ms, lat, lon, frame) {
    var day = hinduDay(ms, lat, lon);
    var vara = WEEKDAY_LORD[day.weekday];
    var k = Math.max(0, Math.floor((ms - day.sr) / HR));
    var hora = HORA_ORDER[(HORA_ORDER.indexOf(vara) + k) % 7];
    var isDay = ms < day.ss;
    var tri = isDay ? Math.min(2, Math.floor(3 * (ms - day.sr) / (day.ss - day.sr))) : Math.min(2, Math.floor(3 * (ms - day.ss) / (day.nsr - day.ss)));
    var triLord = (isDay ? ['Mercury', 'Sun', 'Saturn'] : ['Moon', 'Venus', 'Mars'])[tri];
    var noon = (day.sr + day.ss) / 2;
    var off = (((ms - noon) / HR) % 24 + 24) % 24; if (off > 12) off = 24 - off;   // hours from the nearer of noon / midnight-opposite
    var sunLon = sunFrameLon(ms, frame), sign = Math.floor(sunLon / 30);
    var yStart = lastIngress(ms, 0, frame), mStart = lastIngress(ms, sign * 30, frame);
    var yearLord = null, monthLord = null;
    if (yStart !== null) yearLord = WEEKDAY_LORD[hinduDay(yStart, lat, lon).weekday];
    if (mStart !== null) monthLord = WEEKDAY_LORD[hinduDay(mStart, lat, lon).weekday];
    return { sunrise: day.sr, sunset: day.ss, nextSunrise: day.nsr, polar: day.polar, isDay: isDay, weekday: day.weekday, varaLord: vara,
      horaLord: hora, horaNumber: k + 1, tribhagaLord: triLord, tribhagaPart: tri + 1, hoursFromNoon: off, yearStart: yStart, monthStart: mStart,
      yearLord: yearLord, monthLord: monthLord };
  }

  /* ---- The six balas, in virupas (60 virupas = 1 rupa) ---- */
  function strength(ch, opts) {
    var frame = opts.frame === 'sidereal' ? 'sidereal' : 'tropical';
    var ms = opts.ms, T = tOf(ms);
    var tf = timeFactors(ms, opts.lat, opts.lon, frame);
    var body = {}; ch.bodies.forEach(function (b) { body[b.id] = b; });
    var fl = function (id) { return frame === 'sidereal' ? body[id].sid : body[id].trop; };
    var ascSign = Math.floor((frame === 'sidereal' ? ch.asc.sid : ch.asc.trop) / 30);
    var sign = {}; SB.forEach(function (id) { sign[id] = Math.floor(fl(id) / 30); });
    var sunTrop = body.Sun.trop, moonTrop = body.Moon.trop;
    var elong = arcDist(moonTrop, sunTrop);
    var waxing = norm(moonTrop - sunTrop) < 180;
    var benefic = { Sun: false, Moon: waxing, Mars: false, Mercury: true, Jupiter: true, Venus: true, Saturn: false };
    var meanSun = norm(280.4664567 + 36000.76983 * T);
    var asc = ch.asc.trop, mc = ch.mc.trop;
    var weak = { Sun: norm(mc + 180), Mars: norm(mc + 180), Moon: mc, Venus: mc, Mercury: norm(asc + 180), Jupiter: norm(asc + 180), Saturn: asc };
    var res = [];

    SB.forEach(function (id) {
      var L = fl(id), v = vargaSigns(L), sp = sign[id];
      /* Sthana bala */
      var uccha = (180 - arcDist(L, EXALT[id])) / 3;
      var sapta = 0, order = ['d1', 'd2', 'd3', 'd7', 'd9', 'd12', 'd30'];
      var mt = MOOLA[id], inMool = v.d1 === mt[0] && v.degInSign >= mt[1] && v.degInSign < mt[2];
      order.forEach(function (k) {
        var vs = v[k];
        if (k === 'd1' && inMool) sapta += 45;
        else sapta += relationPoints(id, SIGN_LORD[vs], sp, sign[SIGN_LORD[vs]]);
      });
      var odd1 = v.d1 % 2 === 0, odd9 = v.d9 % 2 === 0, ojha = 0;
      if (id === 'Moon' || id === 'Venus') { if (!odd1) ojha += 15; if (!odd9) ojha += 15; }
      else { if (odd1) ojha += 15; if (odd9) ojha += 15; }
      var house = ((sp - ascSign + 12) % 12) + 1;
      var kendra = [1, 4, 7, 10].indexOf(house) >= 0 ? 60 : [2, 5, 8, 11].indexOf(house) >= 0 ? 30 : 15;
      var wantDrek = MALE.indexOf(id) >= 0 ? 0 : FEMALE.indexOf(id) >= 0 ? 2 : 1;
      var drek = v.drekkana === wantDrek ? 15 : 0;
      var sthana = uccha + sapta + ojha + kendra + drek;
      /* Dig bala */
      var dig = arcDist(body[id].trop, weak[id]) / 3;
      /* Kala bala */
      var diurnal = id === 'Sun' || id === 'Jupiter' || id === 'Venus';
      var nata = id === 'Mercury' ? 60 : diurnal ? 60 - 5 * tf.hoursFromNoon : 5 * tf.hoursFromNoon;
      var pk = elong / 3;
      var paksha = id === 'Moon' ? pk * 2 : (benefic[id] ? pk : 60 - pk);
      var tribhaga = id === 'Jupiter' ? 60 : (tf.tribhagaLord === id ? 60 : 0);
      var abda = tf.yearLord === id ? 15 : 0, masa = tf.monthLord === id ? 30 : 0;
      var vara = tf.varaLord === id ? 45 : 0, hora = tf.horaLord === id ? 60 : 0;
      var decl = body[id].decl, ayana;
      if (id === 'Moon' || id === 'Saturn') ayana = (23.45 - decl) / 46.9 * 60;
      else if (id === 'Mercury') ayana = (23.45 + Math.abs(decl)) / 46.9 * 60;
      else ayana = (23.45 + decl) / 46.9 * 60;
      ayana = Math.max(0, ayana);
      if (id === 'Sun') ayana *= 2;
      var kala = nata + paksha + tribhaga + abda + masa + vara + hora + ayana;
      /* Cheshta bala */
      var cheshta, ck = null;
      if (id === 'Sun') cheshta = ayana;
      else if (id === 'Moon') cheshta = paksha;
      else {
        var pm = norm(MEAN_L[id][0] + MEAN_L[id][1] * T);
        var inner = id === 'Mercury' || id === 'Venus';
        ck = cheshtaKendraFrom(inner ? pm : meanSun, inner ? meanSun : pm, body[id].trop);
        cheshta = ck / 3;
      }
      /* Naisargika and Drik */
      var drik = 0;
      SB.forEach(function (a) {
        if (a === id) return;
        var val = sphutaDrishti(a, body[id].trop - body[a].trop);
        drik += benefic[a] ? val : -val;
      });
      drik /= 4;
      var total = sthana + dig + kala + cheshta + NAISARGIKA[id] + drik;
      var uc = Math.min(60, Math.max(0, uccha)), ch60 = Math.min(60, Math.max(0, cheshta));
      res.push({
        id: id, house: house, sign: sp,
        sthana: { uccha: uccha, sapta: sapta, ojha: ojha, kendra: kendra, drekkana: drek, total: sthana },
        dig: dig,
        kala: { nata: nata, paksha: paksha, tribhaga: tribhaga, abda: abda, masa: masa, vara: vara, hora: hora, ayana: ayana, total: kala },
        cheshta: cheshta, cheshtaKendra: ck, naisargika: NAISARGIKA[id], drik: drik,
        total: total, rupas: total / 60, required: REQUIRED[id], requiredRupas: REQUIRED[id] / 60, ratio: total / REQUIRED[id],
        meets: total >= REQUIRED[id],
        ishta: Math.sqrt(uc * ch60), kashta: Math.sqrt((60 - uc) * (60 - ch60))
      });
    });
    var ranked = res.slice().sort(function (a, b) { return b.ratio - a.ratio; });
    res.forEach(function (r) { r.rank = ranked.indexOf(r) + 1; });
    var war = [], pl = ['Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
    for (var i = 0; i < pl.length; i++) for (var j = i + 1; j < pl.length; j++) {
      var sep = arcDist(body[pl[i]].trop, body[pl[j]].trop);
      if (sep < 1) war.push({ a: pl[i], b: pl[j], separation: sep });
    }
    return { frame: frame, planets: res, time: tf, war: war, elongation: elong, waxing: waxing };
  }

  /* ---------- Lajjitaadi avasthas (BPHS ch. 45), scored the way Ernst Wilhelm's Kala does ----------
     Every influence is the influencing planet's Shadbala times a 0-60 drishti/yuti value / 60:
       rasi lord 60 · same-sign conjunction 60 · same-lord conjunction 30 (milder) · aspect = sphuta drishti.
     Each state's figure is the planet's own Shadbala minus (or, for Mudita, plus) those amounts, in virupas. */
  var WATER = [3, 7, 11];
  function relOf(a, b) { return FRIENDS[a].indexOf(b) >= 0 ? 1 : ENEMIES[a].indexOf(b) >= 0 ? -1 : 0; }

  function avasthas(ch, sb, frame) {
    var sid = frame === 'sidereal';
    var L = {}, sign = {}, trop = {};
    ch.bodies.forEach(function (b) { L[b.id] = sid ? b.sid : b.trop; trop[b.id] = b.trop; sign[b.id] = Math.floor(L[b.id] / 30); });
    var ascSign = Math.floor((sid ? ch.asc.sid : ch.asc.trop) / 30);
    var SBv = {}; sb.planets.forEach(function (p) { SBv[p.id] = p.total; });
    var benefic = { Jupiter: true, Venus: true, Mercury: true, Moon: !!sb.waxing };

    function joinWeight(a, b) {           // 60 same sign, 30 same lord, 0 otherwise
      if (sign[a] === sign[b]) return 60;
      if (SIGN_LORD[sign[a]] === SIGN_LORD[sign[b]]) return 30;
      return 0;
    }
    /* The drishti/yuti matrix, as Kala shows it: dy[from][to]. */
    var dy = {};
    SB.forEach(function (f) {
      dy[f] = {};
      SB.forEach(function (t) {
        if (f === t) return;
        var w = joinWeight(f, t);
        dy[f][t] = w ? { kind: w === 60 ? 'conj' : 'lord', value: w } : { kind: 'aspect', value: sphutaDrishti(f, trop[t] - trop[f]) };
      });
    });

    var out = SB.map(function (P) {
      var base = SBv[P], inf = [];
      var push = function (state, from, how, value) {
        var amt = SBv[from] * value / 60;
        if (amt > 0) inf.push({ state: state, from: from, how: how, value: value, amount: amt });
      };
      /* Rasi lord */
      var lord = SIGN_LORD[sign[P]];
      if (lord !== P) {
        var r = relOf(P, lord);
        if (r === -1) push('kshudhita', lord, 'rasi', 60);
        else if (r === 1 && lord !== 'Saturn') push('mudita', lord, 'rasi', 60);
      }
      /* Conjunctions and aspects of the other six */
      var enemyAsp = [], beneficAsp = [], aspectedBy = {};
      SB.forEach(function (X) {
        if (X === P) return;
        var e = dy[X][P], r = relOf(P, X);
        if (e.kind !== 'aspect') {
          var how = e.kind === 'conj' ? 'conjunction' : 'same-lord conjunction', lordJoin = e.kind === 'lord';
          if (X === 'Sun') { if (lordJoin && r === 1) push('mudita', 'Sun', how, e.value); else push('kshobhita', 'Sun', how, e.value); }
          else if (X === 'Saturn') { if (lordJoin && r === 1) push('mudita', 'Saturn', how, e.value); else push('kshudhita', 'Saturn', how, e.value); }
          else if (X === 'Jupiter') push('mudita', 'Jupiter', how, e.value);
          else if (r === 1) push('mudita', X, how, e.value);
          else if (r === -1) push('kshudhita', X, how, e.value);
          return;
        }
        if (e.value <= 0) return;
        aspectedBy[X] = e.value;
        if (r === -1) { push('kshudhita', X, 'aspect', e.value); enemyAsp.push(X); }
        else {
          if (r === 1 && X !== 'Saturn') push('mudita', X, 'aspect', e.value);
          if (benefic[X]) beneficAsp.push(X);
        }
      });
      /* Trishita: water sign, aspected by an enemy (never the Moon); benefic aspects offset it */
      if (WATER.indexOf(sign[P]) >= 0 && P !== 'Moon' && enemyAsp.length) {
        enemyAsp.forEach(function (X) { push('trishita', X, 'aspect', aspectedBy[X]); });
        beneficAsp.forEach(function (X) { push('trishita+', X, 'benefic aspect', aspectedBy[X]); });
      }
      /* Kshobhita by aspect: Sun, Mars and Saturn all aspect, and at least one enemy aspects */
      if (aspectedBy.Sun && aspectedBy.Mars && aspectedBy.Saturn && enemyAsp.length) {
        enemyAsp.forEach(function (X) { push('kshobhita', X, 'aspect', aspectedBy[X]); });
      }
      /* Lajjita: in the 5th house or joined by Rahu/Ketu, and joined by the Sun, Saturn or Mars */
      var house = ((sign[P] - ascSign + 12) % 12) + 1;
      var nodeJoin = ['Rahu', 'Ketu'].filter(function (n) { return joinWeight(P, n) > 0; });
      if (house === 5 || nodeJoin.length) {
        ['Sun', 'Saturn', 'Mars'].forEach(function (X) {
          if (X === P) return;
          var w = joinWeight(P, X);
          if (w) push('lajjita', X, (w === 60 ? 'conjunction' : 'same-lord conjunction') + (house === 5 ? ' in the 5th' : ' with ' + nodeJoin.join(' and ')), w);
        });
      }
      /* Garvita */
      var deg = L[P] - sign[P] * 30, mt = MOOLA[P];
      var exalted = dignityIn(P, sign[P]) === 'ex', moola = sign[P] === mt[0] && deg >= mt[1] && deg < mt[2];
      var garvita = exalted || moola;
      var cushion = garvita ? base : 0;

      var sum = function (st) { return inf.filter(function (i) { return i.state === st; }).reduce(function (s, i) { return s + i.amount; }, 0); };
      var has = function (st) { return inf.some(function (i) { return i.state === st; }); };
      var req = REQUIRED[P];
      var grade = function (v) { var e = v + cushion; return e >= req ? 'mild' : e > 0 ? 'felt' : 'devastating'; };
      var neg = function (st, extra) { if (!has(st)) return null; var v = base - sum(st) + (extra || 0); return { value: v, grade: grade(v) }; };
      var states = {
        lajjita: neg('lajjita'),
        garvita: garvita ? { value: base, reason: exalted ? 'exalted' : 'moolatrikona' } : null,
        kshudhita: neg('kshudhita'),
        trishita: has('trishita') ? (function () { var v = base - sum('trishita') + sum('trishita+'); return { value: v, grade: grade(v) }; })() : null,
        mudita: has('mudita') ? { value: base + sum('mudita'), gain: sum('mudita') } : null,
        kshobhita: neg('kshobhita')
      };
      return { id: P, shadbala: base, required: req, house: house, sign: sign[P], states: states, influences: inf, garvita: garvita, cushion: cushion };
    });
    return { frame: sid ? 'sidereal' : 'tropical', planets: out, matrix: dy, benefic: benefic };
  }

  /* ---------- Bhava cusps as points of concrete manifestation (Campanus) ---------- */
  var CUSP_ORB = 15;
  function bhavaCusps(ch, frame) {
    var sid = frame === 'sidereal', ay = ch.ayanamsa;
    var cc = campanusCusps(ch.ms, ch.lat, ch.lon);
    var ascSign = Math.floor((sid ? ch.asc.sid : ch.asc.trop) / 30);
    var trop = {}; ch.bodies.forEach(function (b) { trop[b.id] = b.trop; });
    var cusps = cc.cusps.map(function (c, i) {
      var sidL = norm(c - ay), L = sid ? sidL : c, s = Math.floor(L / 30);
      var near = ch.bodies.map(function (b) { return { id: b.id, abbr: b.abbr, dist: arcDist(b.trop, c), ahead: norm(b.trop - c) < 180 }; })
        .filter(function (x) { return x.dist <= CUSP_ORB; }).sort(function (a, b) { return a.dist - b.dist; });
      var asp = SB.map(function (id) { return { id: id, value: sphutaDrishti(id, c - trop[id]) }; })
        .filter(function (x) { return x.value >= 30; }).sort(function (a, b) { return b.value - a.value; });
      return { house: i + 1, trop: c, sid: sidL, sign: s, deg: L - s * 30, lord: SIGN_LORD[s], rasiHouse: ((s - ascSign + 12) % 12) + 1,
        nak: nakshatraOf(sidL), near: near, aspects: asp };
    });
    var place = function (mode) {
      return ch.bodies.map(function (b) {
        var bs = Math.floor((sid ? b.sid : b.trop) / 30);
        return { id: b.id, rasiHouse: ((bs - ascSign + 12) % 12) + 1, bhava: bhavaOf(b.trop, cc.cusps, mode) };
      });
    };
    return { frame: sid ? 'sidereal' : 'tropical', cusps: cusps, place: place, orb: CUSP_ORB };
  }

  /* ---------- Ashtakavarga (BPHS ch. 66): houses, counted from each of the eight references, where a planet gets a bindu ---------- */
  var AV_REFS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Lagna'];
  var AV_TABLE = {
    Sun: { Sun: [1, 2, 4, 7, 8, 9, 10, 11], Moon: [3, 6, 10, 11], Mars: [1, 2, 4, 7, 8, 9, 10, 11], Mercury: [3, 5, 6, 9, 10, 11, 12],
      Jupiter: [5, 6, 9, 11], Venus: [6, 7, 12], Saturn: [1, 2, 4, 7, 8, 9, 10, 11], Lagna: [3, 4, 6, 10, 11, 12] },
    Moon: { Sun: [3, 6, 7, 8, 10, 11], Moon: [1, 3, 6, 7, 10, 11], Mars: [2, 3, 5, 6, 9, 10, 11], Mercury: [1, 3, 4, 5, 7, 8, 10, 11],
      Jupiter: [1, 4, 7, 8, 10, 11, 12], Venus: [3, 4, 5, 7, 9, 10, 11], Saturn: [3, 5, 6, 11], Lagna: [3, 6, 10, 11] },
    Mars: { Sun: [3, 5, 6, 10, 11], Moon: [3, 6, 11], Mars: [1, 2, 4, 7, 8, 10, 11], Mercury: [3, 5, 6, 11],
      Jupiter: [6, 10, 11, 12], Venus: [6, 8, 11, 12], Saturn: [1, 4, 7, 8, 9, 10, 11], Lagna: [1, 3, 6, 10, 11] },
    Mercury: { Sun: [5, 6, 9, 11, 12], Moon: [2, 4, 6, 8, 10, 11], Mars: [1, 2, 4, 7, 8, 9, 10, 11], Mercury: [1, 3, 5, 6, 9, 10, 11, 12],
      Jupiter: [6, 8, 11, 12], Venus: [1, 2, 3, 4, 5, 8, 9, 11], Saturn: [1, 2, 4, 7, 8, 9, 10, 11], Lagna: [1, 2, 4, 6, 8, 10, 11] },
    Jupiter: { Sun: [1, 2, 3, 4, 7, 8, 9, 10, 11], Moon: [2, 5, 7, 9, 11], Mars: [1, 2, 4, 7, 8, 10, 11], Mercury: [1, 2, 4, 5, 6, 9, 10, 11],
      Jupiter: [1, 2, 3, 4, 7, 8, 10, 11], Venus: [2, 5, 6, 9, 10, 11], Saturn: [3, 5, 6, 12], Lagna: [1, 2, 4, 5, 6, 7, 9, 10, 11] },
    Venus: { Sun: [8, 11, 12], Moon: [1, 2, 3, 4, 5, 8, 9, 11, 12], Mars: [3, 5, 6, 9, 11, 12], Mercury: [3, 5, 6, 9, 11],
      Jupiter: [5, 8, 9, 10, 11], Venus: [1, 2, 3, 4, 5, 8, 9, 10, 11], Saturn: [3, 4, 5, 8, 9, 10, 11], Lagna: [1, 2, 3, 4, 5, 8, 9, 11] },
    Saturn: { Sun: [1, 2, 4, 7, 8, 10, 11], Moon: [3, 6, 11], Mars: [3, 5, 6, 10, 11, 12], Mercury: [6, 8, 9, 10, 11, 12],
      Jupiter: [5, 6, 11, 12], Venus: [6, 11, 12], Saturn: [3, 5, 6, 11], Lagna: [1, 3, 4, 6, 10, 11] }
  };
  var KAKSHYA = ['Saturn', 'Jupiter', 'Mars', 'Sun', 'Venus', 'Mercury', 'Moon', 'Lagna'];   // eight 3°45' parts of each sign

  function ashtakavarga(ch, frame) {
    var sid = frame === 'sidereal', sign = {};
    ch.bodies.forEach(function (b) { sign[b.id] = Math.floor((sid ? b.sid : b.trop) / 30); });
    sign.Lagna = Math.floor((sid ? ch.asc.sid : ch.asc.trop) / 30);
    var bav = {}, contrib = {}, sav = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    SB.forEach(function (p) {
      bav[p] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; contrib[p] = [[], [], [], [], [], [], [], [], [], [], [], []];
      AV_REFS.forEach(function (r) {
        AV_TABLE[p][r].forEach(function (h) { var s = (sign[r] + h - 1) % 12; bav[p][s]++; contrib[p][s].push(r); sav[s]++; });
      });
    });
    return { frame: sid ? 'sidereal' : 'tropical', bav: bav, sav: sav, contrib: contrib, refSigns: sign };
  }

  /* ---------- Transits ---------- */
  var ASPECT_ANGLES = { Sun: [180], Moon: [180], Mercury: [180], Venus: [180], Mars: [90, 180, 210], Jupiter: [120, 180, 240], Saturn: [60, 180, 270], Rahu: [], Ketu: [] };
  var ASPECT_NAME = { 60: '3rd-house aspect', 90: '4th-house aspect', 120: '5th-house aspect', 180: 'opposition', 210: '8th-house aspect', 240: '9th-house aspect', 270: '10th-house aspect' };

  /* The natal points transits can touch: the nine grahas, the lagna and the Campanus cusps 2-12 (cusp 1 is the lagna). */
  function natalPoints(natal) {
    var pts = natal.bodies.map(function (b) { return { id: b.id, kind: 'planet', lon: b.trop }; });
    pts.push({ id: 'Lagna', kind: 'lagna', lon: natal.asc.trop });
    campanusCusps(natal.ms, natal.lat, natal.lon).cusps.forEach(function (c, i) { if (i > 0) pts.push({ id: 'Cusp ' + (i + 1), kind: 'cusp', house: i + 1, lon: c }); });
    return pts;
  }
  function contactsAt(id, lonDeg, pts, orb) {
    var out = [];
    pts.forEach(function (p) {
      if (p.id === id && p.kind === 'planet') return;
      var d = norm(p.lon - lonDeg);
      if (arcDist(lonDeg, p.lon) <= orb) out.push({ to: p.id, kind: p.kind, aspect: 0, name: 'conjunction', orb: arcDist(lonDeg, p.lon) });
      (ASPECT_ANGLES[id] || []).forEach(function (a) {
        var off = Math.abs(((d - a) % 360 + 540) % 360 - 180);
        if (off <= orb) out.push({ to: p.id, kind: p.kind, aspect: a, name: ASPECT_NAME[a], orb: off });
      });
    });
    return out.sort(function (a, b) { return a.orb - b.orb; });
  }

  /* Kala-style influence of the transiting grahas on each natal graha: same rules as the natal avasthas
     (natural friendship; Saturn starves and Jupiter delights by conjunction; the Sun agitates), weighted by
     the transiting planet's Shadbala at that moment times the conjunction (60, same lord 30) or sphuta drishti value. */
  function transitInfluences(natal, transit, sbTransit, frame) {
    var sid = frame === 'sidereal', SBt = {};
    sbTransit.planets.forEach(function (p) { SBt[p.id] = p.total; });
    var nb = {}, tb = {};
    natal.bodies.forEach(function (b) { nb[b.id] = b; });
    transit.bodies.forEach(function (b) { tb[b.id] = b; });
    var sgn = function (b) { return Math.floor((sid ? b.sid : b.trop) / 30); };
    return SB.map(function (P) {
      var inf = [], sp = sgn(nb[P]);
      SB.forEach(function (X) {
        var sx = sgn(tb[X]), w = sx === sp ? 60 : SIGN_LORD[sx] === SIGN_LORD[sp] ? 30 : 0, r = relOf(P, X), state = null, how, value;
        if (w) {
          how = w === 60 ? 'conjunction' : 'same-lord conjunction'; value = w;
          if (X === 'Sun') state = (w === 30 && r === 1) ? 'mudita' : 'kshobhita';
          else if (X === 'Saturn') state = (w === 30 && r === 1) ? 'mudita' : 'kshudhita';
          else if (X === 'Jupiter') state = 'mudita';
          else state = r === 1 ? 'mudita' : r === -1 ? 'kshudhita' : null;
        } else {
          value = sphutaDrishti(X, nb[P].trop - tb[X].trop); how = 'aspect';
          if (value > 0) state = r === -1 ? 'kshudhita' : (r === 1 && X !== 'Saturn') ? 'mudita' : null;
        }
        if (state && value > 0) inf.push({ from: X, state: state, how: how, value: value, amount: SBt[X] * value / 60 });
      });
      var plus = inf.filter(function (i) { return i.state === 'mudita'; }).reduce(function (s, i) { return s + i.amount; }, 0);
      var minus = inf.filter(function (i) { return i.state !== 'mudita'; }).reduce(function (s, i) { return s + i.amount; }, 0);
      return { id: P, influences: inf.sort(function (a, b) { return b.amount - a.amount; }), delight: plus, affliction: minus, net: plus - minus };
    });
  }

  /* Everything about the sky at one moment, read against the natal chart. opts.lat/lon is where the
     transits are observed (default: the birthplace). Planet positions are geocentric and the same anywhere;
     the place sets the rising sign and the transit Shadbala (sunrise, day/night, directional strength). */
  function transitSnapshot(natal, ms, opts) {
    opts = opts || {};
    var frame = opts.frame === 'sidereal' ? 'sidereal' : 'tropical', sid = frame === 'sidereal';
    var obsLat = opts.lat != null ? opts.lat : natal.lat, obsLon = opts.lon != null ? opts.lon : natal.lon;
    var tc = chart({ ms: ms, lat: obsLat, lon: obsLon, nodeType: opts.nodeType || 'mean' });
    var nb = {}; natal.bodies.forEach(function (b) { nb[b.id] = b; });
    var lagSign = Math.floor((sid ? natal.asc.sid : natal.asc.trop) / 30), moonSign = Math.floor((sid ? nb.Moon.sid : nb.Moon.trop) / 30);
    var av = opts.av || ashtakavarga(natal, frame), pts = natalPoints(natal);
    var bodies = tc.bodies.map(function (b) {
      var L = sid ? b.sid : b.trop, s = Math.floor(L / 30), deg = L - s * 30;
      var row = { id: b.id, abbr: b.abbr, trop: b.trop, sid: b.sid, sign: s, deg: deg, retro: b.retro || ((b.id === 'Rahu' || b.id === 'Ketu') && false), nak: b.nak,
        house: ((s - lagSign + 12) % 12) + 1, fromMoon: ((s - moonSign + 12) % 12) + 1, contacts: contactsAt(b.id, b.trop, pts, b.id === 'Moon' ? 6 : 3) };
      if (av.bav[b.id]) {
        var k = Math.min(7, Math.floor(deg / 3.75)), lord = KAKSHYA[k];
        row.av = { bindus: av.bav[b.id][s], sav: av.sav[s], kakshya: lord, kakshyaGood: av.contrib[b.id][s].indexOf(lord) >= 0 };
      } else row.av = { bindus: null, sav: av.sav[s], kakshya: null, kakshyaGood: null };
      return row;
    });
    var sbT = strength(tc, { ms: ms, lat: obsLat, lon: obsLon, frame: frame });
    var ascL = sid ? tc.asc.sid : tc.asc.trop, ascS = Math.floor(ascL / 30);
    var rising = { trop: tc.asc.trop, sign: ascS, deg: ascL - ascS * 30, house: ((ascS - lagSign + 12) % 12) + 1, nak: tc.asc.nak };
    return { ms: ms, frame: frame, lat: obsLat, lon: obsLon, rising: rising, chart: tc, bodies: bodies, strength: sbT, avasthas: avasthas(tc, sbT, frame),
      influences: transitInfluences(natal, tc, sbT, frame), av: av };
  }

  /* ---------- Timeline of transit events ---------- */
  function nodeTrack(startMs, endMs, type) {
    if (type !== 'interpolated') return function (t) { return lunarNode(t, type || 'mean'); };
    var DAY = 86400000, cr = [], cursor = startMs - 40 * DAY;
    while (cursor < endMs + 40 * DAY) {          // the crossing finder looks ahead at most 80 days, so walk in steps
      var batch = moonCrossings(cursor, 1, 4);
      if (!batch.length) break;
      batch.forEach(function (c) { if (!cr.length || c.ms > cr[cr.length - 1].ms + DAY) cr.push(c); });
      cursor = batch[batch.length - 1].ms + DAY;
    }
    return function (t) {
      var i = 0; while (i < cr.length && cr[i].ms <= t) i++;
      var pts = cr.slice(Math.max(0, i - 2), Math.min(cr.length, i + 2));
      if (pts.length < 2) return lunarNode(t, 'true');
      var ys = [pts[0].rahu]; for (var j = 1; j < pts.length; j++) ys.push(ys[j - 1] + ((pts[j].rahu - pts[j - 1].rahu + 540) % 360) - 180);
      var v = 0;
      for (j = 0; j < pts.length; j++) { var w = 1; for (var k = 0; k < pts.length; k++) if (k !== j) w *= (t - pts[k].ms) / (pts[j].ms - pts[k].ms); v += w * ys[j]; }
      return norm(v);
    };
  }

  function transitTimeline(natal, dasa, startMs, endMs, opts) {
    opts = opts || {};
    var DAY = 86400000, frame = opts.frame === 'sidereal' ? 'sidereal' : 'tropical', sid = frame === 'sidereal';
    var node = nodeTrack(startMs, endMs, opts.nodeType);
    var MOVERS = ['Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Rahu', 'Ketu'];
    var trop = function (id, t) { if (id === 'Rahu') return node(t); if (id === 'Ketu') return norm(node(t) + 180); return bodyLongitude(id, t).lon; };
    var frameLon = function (id, t) {
      if (!sid) return trop(id, t);
      if (id === 'Rahu' || id === 'Ketu') return siderealOf(trop(id, t), 0, t);
      var p = bodyLongitude(id, t); return siderealOf(p.lon, p.lat, t);
    };
    var nakLon = function (id, t) {
      if (id === 'Rahu' || id === 'Ketu') return siderealOf(trop(id, t), 0, t);
      var p = bodyLongitude(id, t); return siderealOf(p.lon, p.lat, t);
    };
    var wrap = function (x) { return ((x % 360) + 540) % 360 - 180; };
    var root = function (f, a, b) {   // f(a), f(b) differ in sign
      var fa = f(a);
      for (var i = 0; i < 22; i++) { var m = (a + b) / 2, fm = f(m); if ((fm < 0) === (fa < 0)) { a = m; fa = fm; } else b = m; }
      return (a + b) / 2;
    };
    var times = []; for (var t = startMs; t <= endMs + DAY; t += DAY) times.push(t);
    var samples = {};
    MOVERS.forEach(function (id) { samples[id] = times.map(function (tt) { return { trop: trop(id, tt), fr: frameLon(id, tt) }; }); });
    var ev = [], add = function (e) { if (e.ms >= startMs && e.ms <= endMs) ev.push(e); };

    MOVERS.forEach(function (id) {
      var s = samples[id];
      for (var i = 1; i < s.length; i++) {
        /* sign changes, in the chosen zodiac */
        var a = Math.floor(s[i - 1].fr / 30), b = Math.floor(s[i].fr / 30);
        if (a !== b) {
          var bound = (Math.abs(b - a) === 11 ? 0 : Math.max(a, b)) * 30;
          var tIn = root(function (x) { return wrap(frameLon(id, x) - bound); }, times[i - 1], times[i]);
          add({ ms: tIn, kind: 'ingress', body: id, sign: b, retro: ((b - a + 12) % 12) === 11 });
        }
        /* retrograde and direct stations */
        if (i >= 2 && id !== 'Sun' && id !== 'Rahu' && id !== 'Ketu') {
          var v1 = wrap(s[i - 1].trop - s[i - 2].trop), v2 = wrap(s[i].trop - s[i - 1].trop);
          if ((v1 < 0) !== (v2 < 0)) {
            var speed = function (x) { return wrap(trop(id, x + DAY / 4) - trop(id, x - DAY / 4)); };
            var tSt = root(speed, times[i - 2] + DAY / 2, times[i] - DAY / 2 + 1);
            add({ ms: tSt, kind: 'station', body: id, retro: v2 < 0, lon: trop(id, tSt) });
          }
        }
      }
      /* nakshatra changes of the slow movers */
      if (id === 'Jupiter' || id === 'Saturn' || id === 'Rahu') {
        var span = 360 / 27, prev = Math.floor(nakLon(id, times[0]) / span);
        for (i = 1; i < times.length; i++) {
          var cur = Math.floor(nakLon(id, times[i]) / span);
          if (cur !== prev) {
            var nb2 = (Math.abs(cur - prev) === 26 ? 0 : Math.max(cur, prev)) * span;
            var tN = root(function (x) { return wrap(nakLon(id, x) - nb2); }, times[i - 1], times[i]);
            add({ ms: tN, kind: 'nakshatra', body: id, nak: cur, name: NAKSHATRAS[cur][0], retro: ((cur - prev + 27) % 27) === 26 });
            prev = cur;
          }
        }
      }
    });

    /* exact contacts with natal planets, lagna and cusps (tropical longitudes; the angle between two points is the same in any zodiac) */
    var pts = natalPoints(natal);
    MOVERS.forEach(function (id) {
      var angles = [0].concat(ASPECT_ANGLES[id]), s = samples[id];
      pts.forEach(function (p) {
        if (p.id === id && p.kind === 'planet') return;
        angles.forEach(function (A) {
          var f = function (x) { return wrap(trop(id, x) - p.lon - A); };
          for (var i = 1; i < s.length; i++) {
            var f0 = wrap(s[i - 1].trop - p.lon - A), f1 = wrap(s[i].trop - p.lon - A);
            if ((f0 < 0) !== (f1 < 0) && Math.abs(f0) < 20 && Math.abs(f1) < 20) {
              var tc = root(f, times[i - 1], times[i]);
              add({ ms: tc, kind: 'contact', body: id, to: p.id, toKind: p.kind, aspect: A, name: A ? ASPECT_NAME[A] : 'conjunction',
                retro: wrap(trop(id, tc + DAY / 4) - trop(id, tc - DAY / 4)) < 0 });
            }
          }
        });
      });
    });

    /* dasa changes: every mahadasha, antardasha and pratyantardasha that begins inside the window */
    if (dasa) {
      var walk = function (list, level) {
        list.forEach(function (pd) {
          if (pd.fullEnd < startMs || pd.fullStart > endMs) return;
          if (pd.fullStart >= startMs && pd.fullStart > dasa.birthMs) {
            var chain = []; for (var q = pd; q; q = q.parent) chain.unshift(q.lord);
            add({ ms: pd.fullStart, kind: 'dasa', level: level, lords: chain, end: pd.fullEnd });
          }
          if (level < 2) walk(subPeriods(pd, dasa.birthMs), level + 1);
        });
      };
      walk(dasa.periods, 0);
    }
    return ev.sort(function (a, b) { return a.ms - b.ms; });
  }

  /* ---------- Time zones ---------- */
  function utcFromParts(y, mo, d, h, mi, s) {
    var dt = new Date(0);
    dt.setUTCFullYear(y, mo - 1, d);
    dt.setUTCHours(h, mi, s, 0);
    return dt.getTime();
  }
  function parseZone(str) {
    str = (str || '').trim();
    var m = str.match(/^(?:UTC|GMT)?\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?$/i);
    if (m) {
      var off = (m[1] === '-' ? -1 : 1) * (parseInt(m[2], 10) * 60 + (parseInt(m[3], 10) || 0)) * 60000;
      return { label: str, offsetAt: function () { return off; } };
    }
    if (/^(UTC|GMT|Z)$/i.test(str)) return { label: 'UTC', offsetAt: function () { return 0; } };
    try {
      var dtf = new Intl.DateTimeFormat('en-US', { timeZone: str, hourCycle: 'h23', year: 'numeric', month: 'numeric',
        day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
      return {
        label: str,
        offsetAt: function (ms) {
          var p = {};
          dtf.formatToParts(new Date(ms)).forEach(function (x) { p[x.type] = x.value; });
          var wall = utcFromParts(+p.year, +p.month, +p.day, (+p.hour) % 24, +p.minute, +p.second);
          return wall - Math.floor(ms / 1000) * 1000;
        }
      };
    } catch (e) { return null; }
  }
  function localToUtc(y, mo, d, h, mi, s, zone) {
    var guess = utcFromParts(y, mo, d, h, mi, s);
    var u = guess - zone.offsetAt(guess);
    return guess - zone.offsetAt(u);
  }

  return {
    SIGNS: SIGNS, NAKSHATRAS: NAKSHATRAS, DASA_ORDER: DASA_ORDER, DASA_YEARS: DASA_YEARS, NAK_SPAN: NAK_SPAN,
    GC: { ra: GC_RA, dec: GC_DEC, sidereal: GC_SIDEREAL },
    norm: norm, tOf: tOf, jdOf: jdOf, nutation: nutation, meanObliquity: meanObliquity, gast: gast, angles: angles,
    eqjToTrueEcliptic: eqjToTrueEcliptic, dhruvaAyanamsa: dhruvaAyanamsa, lunarNode: lunarNode,
    interpolatedNode: interpolatedNode, moonCrossings: moonCrossings,
    ashtakavarga: ashtakavarga, AV_TABLE: AV_TABLE, KAKSHYA: KAKSHYA, transitSnapshot: transitSnapshot, transitInfluences: transitInfluences,
    transitTimeline: transitTimeline, natalPoints: natalPoints, contactsAt: contactsAt, nodeTrack: nodeTrack,
    setAyanamsaMode: setAyanamsaMode, STD_AYANAMSA: STD_AYANAMSA, standardAyanamsa: standardAyanamsa, generalPrecession: generalPrecession, siderealOf: siderealOf, equatorialOffset: equatorialOffset, raFromEcl: raFromEcl, ayanamsaOffset: ayanamsaOffset, WILHELM_2000: WILHELM_2000,
    campanusCusps: campanusCusps, campanusPoleForm: campanusPoleForm, bhavaOf: bhavaOf, bhavaCusps: bhavaCusps,
    nakshatraOf: nakshatraOf, chart: chart, buildDasa: buildDasa, subPeriods: subPeriods, runningAt: runningAt,
    parseZone: parseZone, localToUtc: localToUtc, utcFromParts: utcFromParts,
    strength: strength, timeFactors: timeFactors, sunEvents: sunEvents, hinduDay: hinduDay, lastIngress: lastIngress,
    vargaSigns: vargaSigns, vargaSign: vargaSign, vargaChart: vargaChart, dignityIn: dignityIn, VARGAS: VARGAS, avasthas: avasthas, relOf: relOf, sphutaDrishti: sphutaDrishti, drishtiBase: drishtiBase, cheshtaKendraFrom: cheshtaKendraFrom, relationPoints: relationPoints,
    arcDist: arcDist, SIGN_LORD: SIGN_LORD, REQUIRED: REQUIRED, WEEKDAY_LORD: WEEKDAY_LORD, SB: SB
  };
}
if (typeof module !== 'undefined') module.exports = createCore;
