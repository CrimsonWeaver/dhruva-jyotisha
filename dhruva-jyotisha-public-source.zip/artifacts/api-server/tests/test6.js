// Interpolated true node, checked against a Moon built from the main terms of Meeus ch. 47 (longitude and latitude).
const createCore = require('./core.js');
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
const norm = a => ((a % 360) + 360) % 360, sin = a => Math.sin(a * D2R);
const sep = (a, b) => Math.abs(((a - b) % 360 + 540) % 360 - 180);
let fails = 0, n = 0;
const ok = (name, cond, extra) => { n++; if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };

function moonMeeus(T) {
  const Lp = 218.3164477 + 481267.88123421 * T, D = 297.8501921 + 445267.1114034 * T, M = 357.5291092 + 35999.0502909 * T;
  const Mp = 134.9633964 + 477198.8675055 * T, F = 93.272095 + 483202.0175233 * T, E = 1 - 0.002516 * T;
  const lon = Lp + 1e-6 * (6288774 * sin(Mp) + 1274027 * sin(2 * D - Mp) + 658314 * sin(2 * D) + 213618 * sin(2 * Mp) - 185116 * E * sin(M)
    - 114332 * sin(2 * F) + 58793 * sin(2 * D - 2 * Mp) + 57066 * E * sin(2 * D - M - Mp) + 53322 * sin(2 * D + Mp) + 45758 * E * sin(2 * D - M)
    - 40923 * E * sin(M - Mp) - 34720 * sin(D) - 30383 * E * sin(M + Mp) + 15327 * sin(2 * D - 2 * F) - 12528 * sin(Mp + 2 * F) + 10980 * sin(Mp - 2 * F)
    + 10675 * sin(4 * D - Mp) + 10034 * sin(3 * Mp) + 8548 * sin(4 * D - 2 * Mp) - 7888 * E * sin(2 * D + M - Mp) - 6766 * E * sin(2 * D + M) - 5163 * sin(D - Mp));
  const lat = 1e-6 * (5128122 * sin(F) + 280602 * sin(Mp + F) + 277693 * sin(Mp - F) + 173237 * sin(2 * D - F) + 55413 * sin(2 * D - Mp + F)
    + 46271 * sin(2 * D - Mp - F) + 32573 * sin(2 * D + F) + 17198 * sin(2 * Mp + F) + 9266 * sin(2 * D + Mp - F) + 8822 * sin(2 * Mp - F)
    + 8216 * E * sin(2 * D - M - F) + 4324 * sin(2 * D - 2 * Mp - F) + 4200 * sin(2 * D + Mp + F) - 3359 * E * sin(2 * D + M - F)
    + 2463 * E * sin(2 * D - M - Mp + F) + 2211 * E * sin(2 * D - M + F) + 2065 * E * sin(2 * D - M - Mp - F) - 1870 * E * sin(M - Mp - F)
    + 1828 * sin(4 * D - Mp - F) - 1794 * E * sin(M + F) - 1749 * sin(3 * F) - 1565 * E * sin(M - Mp + F) - 1491 * sin(D + F));
  return { lon: norm(lon), lat };
}
// Express the ecliptic-of-date position as a J2000 equatorial vector by inverting the core's own transform.
const base = createCore(() => ({ x: 1, y: 0, z: 0 }));
function vecFromEcl(T, lonDeg, latDeg) {
  const cols = [[0, 0], [90, 0], [0, 90]].map(([ra, dec]) => { const e = base.eqjToTrueEcliptic(ra, dec, T); const l = e.lon * D2R, b = e.lat * D2R; return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)]; });
  const nut = base.nutation(T).dpsi;
  const l = (lonDeg + nut) * D2R, b = latDeg * D2R, v = [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
  const dot = u => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  return { x: dot(cols[0]), y: dot(cols[1]), z: dot(cols[2]) };
}
const C = createCore((name, date) => {
  const T = (+date / 864e5 + 2440587.5 - 2451545) / 36525;
  if (name === 'Moon') { const m = moonMeeus(T); return vecFromEcl(T, m.lon, m.lat); }
  return vecFromEcl(T, 280.46646 + 36000.76983 * T, 0);   // only the Moon matters here
});

// Osculating (true) node of the test Moon, straight from its position and velocity: the orbit normal h = r x v.
function oscNode(ms) {
  const T = t => (t / 864e5 + 2440587.5 - 2451545) / 36525;
  const u = t => { const m = moonMeeus(T(t)), l = m.lon * D2R, b = m.lat * D2R; return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)]; };
  const dt = 60000, a = u(ms - dt), c = u(ms + dt), r = u(ms), v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  const h = [r[1] * v[2] - r[2] * v[1], r[2] * v[0] - r[0] * v[2], r[0] * v[1] - r[1] * v[0]];
  return norm(Math.atan2(h[0], -h[1]) * R2D + base.nutation(T(ms)).dpsi);
}
const around = (ms, k) => C.moonCrossings(ms, -1, k).reverse().concat(C.moonCrossings(ms, 1, k));

// 1. Crossings are real and regular
const ms0 = Date.UTC(2000, 0, 1, 12);
const cr = around(ms0, 2);
ok('two crossings found on each side', cr.length === 4 && cr[1].ms <= ms0 && cr[2].ms > ms0);
ok('Moon latitude is ~0 at each crossing', cr.every(c => Math.abs(moonMeeus((c.ms / 864e5 + 2440587.5 - 2451545) / 36525).lat) < 1e-6));
ok('crossings alternate north/south', cr.every((c, i) => i === 0 || c.ascending !== cr[i - 1].ascending));
const gaps = cr.slice(1).map((c, i) => (c.ms - cr[i].ms) / 864e5);
ok('crossings 12.5-15 days apart', gaps.every(g => g > 12.5 && g < 15), gaps.map(g => g.toFixed(2)).join(', '));

// 2. At every real crossing, the crossing longitude IS the true (osculating) node
let worstOsc = 0, worstSeries = 0, worstMean = 0, cnt = 0;
for (let k = 0; k < 60; k++) {
  const ms = Date.UTC(1950, 0, 1) + k * 37.3 * 864e5 * 11;
  for (const c of around(ms, 2)) {
    worstOsc = Math.max(worstOsc, sep(c.rahu, oscNode(c.ms)));
    worstSeries = Math.max(worstSeries, sep(c.rahu, C.lunarNode(c.ms, 'true')));
    worstMean = Math.max(worstMean, sep(c.rahu, C.lunarNode(c.ms, 'mean')));
    cnt++;
  }
}
ok('at ' + cnt + ' crossings (1950-2018) the crossing longitude equals the osculating node', worstOsc < 0.001, 'worst ' + (worstOsc * 3600).toFixed(2) + '"');
ok('the 5-term true-node series stays close to them (limited by its truncation)', worstSeries < 0.3, 'worst ' + worstSeries.toFixed(3) + '°');
ok('the mean node is off by over a degree at times', worstMean > 1.0, 'worst ' + worstMean.toFixed(3) + '°');

// 3. The interpolated node passes through the crossings, tracks the true node, and is smoother
const at = cr.map(c => sep(C.interpolatedNode(c.ms + 1000).rahu, c.rahu));
ok('interpolated node equals the crossing value at crossings', at.every(d => d < 0.001), at.map(d => (d * 3600).toFixed(2) + '"').join(', '));
let maxIO = 0, maxOM = 0, rI = 0, rO = 0, p1 = null, p2 = null, q1 = null, q2 = null;
for (let h = 0; h < 24 * 60; h += 6) {
  const ms = Date.UTC(2003, 4, 1) + h * 3600000;
  const I = C.interpolatedNode(ms).rahu, O = oscNode(ms), M = C.lunarNode(ms, 'mean');
  maxIO = Math.max(maxIO, sep(I, O)); maxOM = Math.max(maxOM, sep(O, M));
  if (p2 !== null) { rI = Math.max(rI, Math.abs(((I - 2 * p1 + p2) + 540) % 360 - 180)); rO = Math.max(rO, Math.abs(((O - 2 * q1 + q2) + 540) % 360 - 180)); }
  p2 = p1; p1 = I; q2 = q1; q1 = O;
}
console.log('60 days from 2003-05-01: |interpolated - osculating| max ' + maxIO.toFixed(3) + '°, |osculating - mean| max ' + maxOM.toFixed(3) + '°');
console.log('6-hourly wobble (second differences): interpolated ' + (rI * 3600).toFixed(1) + '", osculating ' + (rO * 3600).toFixed(1) + '"');
ok('interpolated stays within 0.5° of the osculating node', maxIO < 0.5);
ok('interpolated is much smoother than the osculating node', rI < rO / 3);
const y0 = C.interpolatedNode(Date.UTC(2003, 0, 1)).rahu, y1 = C.interpolatedNode(Date.UTC(2004, 0, 1)).rahu;
ok('over a year Rahu moves backward about 19°', Math.abs(norm(y0 - y1) - 19.35) < 2, norm(y0 - y1).toFixed(2) + '°');

// 4. Through the chart
for (const ms of [Date.UTC(1879, 2, 14, 10, 50), Date.UTC(1961, 7, 5, 5, 24), Date.UTC(2026, 9, 29, 17)]) {
  const ch = C.chart({ ms, lat: 40, lon: -74, nodeType: 'interpolated' });
  const ra = ch.bodies.find(b => b.id === 'Rahu'), ke = ch.bodies.find(b => b.id === 'Ketu');
  ok('chart ' + new Date(ms).toISOString().slice(0, 10) + ': Ketu opposite, within 0.5° of osculating', Math.abs(sep(ra.trop, ke.trop) - 180) < 1e-9 && sep(ra.trop, oscNode(ms)) < 0.5 && ch.nodeInfo && !ch.nodeInfo.fallback,
    'interp ' + ra.trop.toFixed(3) + '  osc ' + oscNode(ms).toFixed(3) + '  series ' + C.lunarNode(ms, 'true').toFixed(3) + '  mean ' + C.lunarNode(ms, 'mean').toFixed(3));
}
ok('lunarNode(ms, "interpolated") returns a number', typeof C.lunarNode(ms0, 'interpolated') === 'number');
console.log(fails ? fails + ' FAILED of ' + n : 'ALL PASSED (' + n + ')');
process.exit(fails ? 1 : 0);
