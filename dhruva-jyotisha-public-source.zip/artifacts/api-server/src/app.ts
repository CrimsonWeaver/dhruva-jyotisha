import express, { type Express, type ErrorRequestHandler } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { authMiddleware } from "./middlewares/authMiddleware";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.set("trust proxy", 1);
app.use(cors({ origin: false }));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method) && req.headers.origin) {
    try {
      const originHost = new URL(req.headers.origin).host;
      const host = req.get("x-forwarded-host")?.split(",")[0]?.trim() ?? req.get("host");
      if (originHost !== host) { res.status(403).json({ error: "Cross-origin requests are not allowed." }); return; }
    } catch { res.status(403).json({ error: "Invalid request origin." }); return; }
  }
  next();
});
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(authMiddleware);

app.use("/api", router);
const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  // Driver error messages can contain SQL parameter values. Do not log them.
  req.log.error({ errorType: error?.name ?? "Error" }, "Request failed");
  if (res.headersSent) { res.end(); return; }
  res.status(error?.type === "entity.parse.failed" ? 400 : 500).json({ error: "The request could not be completed. Please try again." });
};
app.use(errorHandler);

export default app;
