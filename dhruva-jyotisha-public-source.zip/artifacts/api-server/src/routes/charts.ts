import { randomBytes } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, desc, eq, inArray, isNull } from "drizzle-orm";
import { db, chartsTable, readingsTable, shareLinksTable, userSettingsTable } from "@workspace/db";
import * as api from "@workspace/api-zod";
import { normalizeBirth } from "../lib/chart-input";
import { ENGINE_VERSION } from "../lib/engine";

const router: IRouter = Router();
const defaults = { nodeType: "mean", dasaYear: 365.25, zodiac: "tropical", ayanamsaMode: "equatorial", sbFrame: "tropical", hereLabel: null, hereLat: null, hereLon: null, hereTz: null };
// Shared responses intentionally exclude ownership, saved readings and private settings.
router.get("/shared/:token", async (req, res): Promise<void> => {
  const parsed = api.GetSharedChartParams.safeParse(req.params);
  if (!parsed.success) { res.status(404).json({ error: "Share link not found." }); return; }
  const [row] = await db.select({ chart: chartsTable }).from(shareLinksTable)
    .innerJoin(chartsTable, eq(shareLinksTable.chartId, chartsTable.id))
    .where(and(eq(shareLinksTable.token, parsed.data.token), isNull(shareLinksTable.revokedAt)));
  if (!row) { res.status(404).json({ error: "Share link not found or revoked." }); return; }
  res.setHeader("Cache-Control", "no-store");
  res.json(api.GetSharedChartResponse.parse({ chart: row.chart }));
});

// Every private endpoint below requires a real session; never accept a client user ID.
router.use(["/charts", "/settings", "/export"], (req, res, next) => {
  if (!req.isAuthenticated()) { res.status(401).json({ error: "Sign in to access saved charts." }); return; }
  res.setHeader("Cache-Control", "no-store");
  next();
});

router.get("/charts/summary", async (req, res): Promise<void> => {
  const charts = await db.select().from(chartsTable).where(eq(chartsTable.userId, req.user!.id)).orderBy(desc(chartsTable.updatedAt));
  res.json(api.GetChartsSummaryResponse.parse({ chartCount: charts.length, recentCharts: charts.slice(0, 4) }));
});
router.get("/charts", async (req, res): Promise<void> => {
  const parsed = api.ListChartsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: "Invalid search." }); return; }
  const charts = await db.select().from(chartsTable).where(eq(chartsTable.userId, req.user!.id)).orderBy(desc(chartsTable.updatedAt));
  const q = parsed.data.q?.trim().toLocaleLowerCase();
  res.json(api.ListChartsResponse.parse(q ? charts.filter(c => `${c.name} ${c.placeLabel}`.toLocaleLowerCase().includes(q)) : charts));
});
router.post("/charts", async (req, res): Promise<void> => {
  const parsed = api.CreateChartBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid chart inputs." }); return; }
  let input;
  try { input = normalizeBirth(parsed.data); } catch (error) { res.status(400).json({ error: (error as Error).message }); return; }
  const [chart] = await db.insert(chartsTable).values({ ...input, userId: req.user!.id, engineVersion: ENGINE_VERSION }).returning();
  res.status(201).json(api.CreateChartResponse.parse(chart));
});

router.use("/charts/:id", async (req, res, next): Promise<void> => {
  const parsed = api.GetChartParams.safeParse(req.params);
  if (!parsed.success) { res.status(404).json({ error: "Chart not found." }); return; }
  const [chart] = await db.select().from(chartsTable).where(and(eq(chartsTable.id, parsed.data.id), eq(chartsTable.userId, req.user!.id)));
  if (!chart) { res.status(404).json({ error: "Chart not found." }); return; }
  res.locals.chart = chart;
  next();
});
router.get("/charts/:id", (_req, res): void => { res.json(api.GetChartResponse.parse(res.locals.chart)); });
// Retire old clients explicitly, after the same authentication and ownership checks.
// Historical records remain available only through the owner's full data export.
router.all(["/charts/:id/reading", "/charts/:id/readings"], (_req, res): void => {
  res.status(410).json({ error: "AI readings are no longer available. Historical records are included in your private data export." });
});
router.patch("/charts/:id", async (req, res): Promise<void> => {
  const parsed = api.UpdateChartBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid chart inputs." }); return; }
  let input;
  try { input = normalizeBirth({ ...res.locals.chart, ...parsed.data }); } catch (error) { res.status(400).json({ error: (error as Error).message }); return; }
  const { id: _id, userId: _owner, createdAt: _created, ...updates } = input;
  const [chart] = await db.update(chartsTable).set({ ...updates, updatedAt: new Date() }).where(and(eq(chartsTable.id, res.locals.chart.id), eq(chartsTable.userId, req.user!.id))).returning();
  res.json(api.UpdateChartResponse.parse(chart));
});
router.delete("/charts/:id", async (req, res): Promise<void> => {
  await db.delete(chartsTable).where(and(eq(chartsTable.id, res.locals.chart.id), eq(chartsTable.userId, req.user!.id)));
  res.sendStatus(204);
});
router.post("/charts/:id/share", async (req, res): Promise<void> => {
  const share = await db.transaction(async tx => {
    await tx.select({ id: chartsTable.id }).from(chartsTable).where(eq(chartsTable.id, res.locals.chart.id)).for("update");
    const [existing] = await tx.select().from(shareLinksTable).where(and(eq(shareLinksTable.chartId, res.locals.chart.id), isNull(shareLinksTable.revokedAt)));
    if (existing) return existing;
    const [created] = await tx.insert(shareLinksTable).values({ chartId: res.locals.chart.id, token: randomBytes(32).toString("hex") }).returning();
    return created;
  });
  // Return a relative link; the browser knows its public origin without trusting Host headers.
  res.status(201).json(api.CreateChartShareLinkResponse.parse({ ...share, url: `/shared/${share.token}` }));
});
router.delete("/charts/:id/share", async (_req, res): Promise<void> => {
  await db.update(shareLinksTable).set({ revokedAt: new Date() }).where(eq(shareLinksTable.chartId, res.locals.chart.id));
  res.sendStatus(204);
});
router.get("/settings", async (req, res): Promise<void> => {
  const [settings] = await db.select().from(userSettingsTable).where(eq(userSettingsTable.userId, req.user!.id));
  res.json(api.GetSettingsResponse.parse(settings ?? defaults));
});
router.patch("/settings", async (req, res): Promise<void> => {
  const parsed = api.UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid preferences." }); return; }
  const [settings] = await db.insert(userSettingsTable).values({ userId: req.user!.id, ...parsed.data }).onConflictDoUpdate({ target: userSettingsTable.userId, set: { ...parsed.data, updatedAt: new Date() } }).returning();
  res.json(api.UpdateSettingsResponse.parse(settings));
});
router.get("/export", async (req, res): Promise<void> => {
  const charts = await db.select().from(chartsTable).where(eq(chartsTable.userId, req.user!.id));
  const readings = charts.length ? await db.select().from(readingsTable).where(inArray(readingsTable.chartId, charts.map(c => c.id))) : [];
  const [settings] = await db.select().from(userSettingsTable).where(eq(userSettingsTable.userId, req.user!.id));
  res.json(api.ExportUserDataResponse.parse({ exportedAt: new Date(), charts, readings, settings: settings ?? defaults }));
});

export default router;
