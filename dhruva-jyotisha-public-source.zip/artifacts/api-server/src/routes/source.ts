import { Router, type IRouter } from "express";
import path from "node:path";
import { APP_ROOT } from "../lib/paths";

const router: IRouter = Router();
router.get("/source", (_req, res): void => {
  res.setHeader("Cache-Control", "no-cache");
  res.download(path.join(APP_ROOT, "dist/dhruva-source.tar.gz"), "dhruva-jyotisha-source.tar.gz");
});
export default router;
