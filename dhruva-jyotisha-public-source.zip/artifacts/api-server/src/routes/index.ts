import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import chartsRouter from "./charts";
import placesRouter from "./places";
import calculationsRouter from "./calculations";
import sourceRouter from "./source";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(placesRouter);
router.use(calculationsRouter);
router.use(sourceRouter);
router.use(chartsRouter);

export default router;
