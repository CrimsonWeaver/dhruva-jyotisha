import { Router, type IRouter } from "express";
import { CalculateChartBody, CalculateChartResponse } from "@workspace/api-zod";
import { calculate } from "../lib/engine";
import { birthInstant } from "../lib/chart-input";
import { transitData } from "../lib/transits";

const router: IRouter = Router();
router.post("/calculate", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = CalculateChartBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid chart inputs." }); return; }
  try { birthInstant(parsed.data); } catch (error) { res.status(400).json({ error: (error as Error).message }); return; }
  try {
    const { result } = await calculate(parsed.data);
    const transitMs = parsed.data.transitMs ?? Date.now();
    const year = new Date(transitMs).getUTCFullYear();
    if (!Number.isFinite(transitMs) || year < 1800 || year > 2398) { res.status(400).json({ error: "Choose a transit date between 1800 and 2398." }); return; }
    const controller = new AbortController();
    res.on("close", () => { if (!res.writableEnded) controller.abort(); });
    const transits = await transitData({
      chart: result.chart, dasa: result.dasa, start: transitMs, months: 12,
      frame: parsed.data.sbFrame, nodeType: parsed.data.nodeType,
      lat: parsed.data.transitLat ?? parsed.data.lat, lon: parsed.data.transitLon ?? parsed.data.lon,
      mode: parsed.data.ayanamsaMode,
    }, controller.signal);
    if (!res.destroyed) res.json(CalculateChartResponse.parse({ ...result, ...transits }));
  } catch {
    res.status(503).json({ error: "The Swiss Ephemeris calculation service is unavailable. No substitute values were generated." });
  }
});
export default router;
