import { Router, type IRouter } from "express";
import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";
import { dataset } from "../lib/datasets";
import { SearchPlacesQueryParams, SearchPlacesResponse } from "@workspace/api-zod";
import { APP_ROOT } from "../lib/paths";

const require = createRequire(import.meta.url);
const createPlaceIndex = require(`${APP_ROOT}/vendor/placesearch.js`);
let indexPromise: Promise<ReturnType<typeof createPlaceIndex>> | undefined;
const router: IRouter = Router();
router.get("/places", async (req, res): Promise<void> => {
  const parsed = SearchPlacesQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: "Enter a place name of at least two characters." }); return; }
  try {
    indexPromise ??= dataset("places.txt").then(file => readFile(file, "utf8")).then(createPlaceIndex).catch(error => { indexPromise = undefined; throw error; });
    const index = await indexPromise;
    const results = index.search(parsed.data.q, parsed.data.limit);
    res.json(SearchPlacesResponse.parse({ results }));
  } catch {
    res.status(503).json({ error: "Place search data is temporarily unavailable." });
  }
});
export default router;
