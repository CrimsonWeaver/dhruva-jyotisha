import { createRequire } from "node:module";
import path from "node:path";
import { dataset } from "./datasets";
import { normalizeBirth } from "./chart-input";
import { APP_ROOT } from "./paths";

const require = createRequire(import.meta.url);
const sweph = require("sweph");
const createCore = require(`${APP_ROOT}/vendor/core.js`);
const { createSwissVector } = require(`${APP_ROOT}/vendor/engine-swisseph.js`);
export const ENGINE_VERSION = "Swiss Ephemeris 2.10.3 / Dhruva core";
let ready: Promise<void> | undefined;
async function initialize() {
  ready ??= Promise.all([dataset("ephe/sepl_18.se1"), dataset("ephe/semo_18.se1")])
    .then(([file]) => { sweph.set_ephe_path(path.dirname(file)); })
    .catch(error => { ready = undefined; throw error; });
  await ready;
}
export async function coreFor(mode: string) {
  await initialize();
  const swe = {
    usedFlags: 0,
    calcUt(jd: number, body: number, flags: number) {
      const result = sweph.calc_ut(jd, body, flags);
      if (result.flag < 0 || !result.data) throw new Error(result.error || "Swiss Ephemeris calculation failed.");
      this.usedFlags = result.flag;
      return result.data;
    },
  };
  const core = createCore(createSwissVector(swe));
  core.setAyanamsaMode(mode);
  return core;
}
export async function calculate(input: {
  localDate: string; localTime: string; tz: string; lat: number; lon: number;
  nodeType: string; zodiac: string; sbFrame: string; ayanamsaMode: string; dasaYear: number;
}) {
  const normalized = normalizeBirth(input);
  const core = await coreFor(input.ayanamsaMode);
  const chart = core.chart({ ms: normalized.utcMs, lat: input.lat, lon: input.lon, nodeType: input.nodeType, zodiac: input.sbFrame });
  const strength = core.strength(chart, { ms: normalized.utcMs, lat: input.lat, lon: input.lon, frame: input.sbFrame });
  const dasa = core.buildDasa(chart.bodies.find((b: { id: string }) => b.id === "Moon").sid, normalized.utcMs, input.dasaYear * 86400000);
  const bhavas = core.bhavaCusps(chart, input.sbFrame);
  return {
    core, normalized, result: {
      chart, strength, dasa, avasthas: core.avasthas(chart, strength, input.sbFrame),
      ashtakavarga: core.ashtakavarga(chart, input.sbFrame), cusps: bhavas.cusps,
      vargas: core.vargaChart(chart, input.sbFrame), engineVersion: ENGINE_VERSION,
    },
  };
}
