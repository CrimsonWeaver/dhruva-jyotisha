import { DateTime } from "luxon";

export function birthInstant(input: { localDate: Date | string; localTime: string; tz: string }): number {
  const day = input.localDate instanceof Date ? input.localDate.toISOString().slice(0, 10) : input.localDate;
  const iso = `${day}T${input.localTime.slice(0, 5)}`;
  const date = DateTime.fromISO(iso, { zone: input.tz });
  if (!date.isValid || date.toFormat("yyyy-MM-dd'T'HH:mm") !== iso) {
    throw new Error("Invalid birth date, time, or time zone. This local time may not exist because of daylight saving.");
  }
  if (date.year < 1800 || date.year > 2399) throw new Error("The installed Swiss Ephemeris files cover 1800–2399.");
  if (date.getPossibleOffsets().length > 1) throw new Error("This birth time occurs twice during a daylight-saving change. Choose an unambiguous time.");
  return date.toMillis();
}

export function normalizeBirth<T extends { localDate: Date | string; localTime: string; tz: string }>(input: T) {
  return {
    ...input,
    localDate: input.localDate instanceof Date ? input.localDate.toISOString().slice(0, 10) : input.localDate,
    localTime: input.localTime.slice(0, 5),
    utcMs: birthInstant(input),
  };
}
