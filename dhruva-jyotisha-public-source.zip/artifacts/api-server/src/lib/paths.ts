import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Managed production runs from the workspace root; pnpm dev runs from the package.
// Locate packaged resources independently of the process working directory.
let root = path.dirname(fileURLToPath(import.meta.url));
while (!existsSync(path.join(root, "vendor", "core.js"))) {
  const parent = path.dirname(root);
  if (parent === root) throw new Error("Dhruva application resources are missing.");
  root = parent;
}
export const APP_ROOT = root;
export const WORKSPACE_ROOT = path.resolve(root, "../..");
