import { Storage } from "@google-cloud/storage";
import { mkdir, access } from "node:fs/promises";
import path from "node:path";
import { WORKSPACE_ROOT } from "./paths";

// Credentials are obtained from the Replit sidecar, never from application code.
export const assetStorage = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: "http://127.0.0.1:1106/token",
    type: "external_account",
    credential_source: {
      url: "http://127.0.0.1:1106/credential",
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export const datasetDir = path.join(WORKSPACE_ROOT, "generated-artifacts");
export async function dataset(name: string): Promise<string> {
  const destination = path.join(datasetDir, name);
  try { await access(destination); return destination; } catch { /* Download a cache miss. */ }
  await mkdir(path.dirname(destination), { recursive: true });
  const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
  if (!bucketId) throw new Error("Application datasets are not configured.");
  await assetStorage.bucket(bucketId).file(`dhruva-datasets/${name}`).download({ destination });
  return destination;
}
