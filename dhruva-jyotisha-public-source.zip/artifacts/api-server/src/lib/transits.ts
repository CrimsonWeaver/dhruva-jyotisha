import { fork } from "node:child_process";
import path from "node:path";
import { dataset } from "./datasets";
import { APP_ROOT } from "./paths";

let active = 0;
// Swiss C settings are process-wide, even in worker_threads. Child processes
// keep concurrent 12-month scans truly isolated as the binding recommends.
export async function transitData(data: {
  chart: unknown; dasa: unknown; start: number; months: number; frame: string;
  nodeType: string; lat: number; lon: number; mode: string;
}, signal?: AbortSignal): Promise<{ transit: Record<string, unknown>; events: Record<string, unknown>[] }> {
  if (active >= 2) throw new Error("Calculation service is busy. Please try again shortly.");
  active++;
  try {
    const file = await dataset("ephe/sepl_18.se1");
    return await new Promise((resolve, reject) => {
      const worker = fork(path.join(APP_ROOT, "vendor/transits-worker.cjs"), [], { stdio: ["ignore", "ignore", "ignore", "ipc"] });
      let settled = false;
      const finish = (error?: Error, result?: { transit: Record<string, unknown>; events: Record<string, unknown>[] }) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
        worker.kill();
        if (error) reject(error); else resolve(result!);
      };
      const abort = () => finish(new Error("Calculation stopped."));
      const timer = setTimeout(() => finish(new Error("Transit calculation timed out.")), 60000);
      signal?.addEventListener("abort", abort, { once: true });
      if (signal?.aborted) { abort(); return; }
      worker.once("message", message => {
        const result = message as { error?: string; transit?: Record<string, unknown>; events?: Record<string, unknown>[] } | null;
        if (!result || typeof result !== "object" || result.error || !result.transit || !Array.isArray(result.events)) {
          finish(new Error(result?.error ?? "Invalid transit result."));
        } else finish(undefined, { transit: result.transit, events: result.events });
      });
      worker.once("error", () => finish(new Error("Transit calculation failed.")));
      worker.once("exit", code => { if (!settled) finish(new Error(`Transit worker exited (${code}).`)); });
      worker.send({ ...data, end: data.start + data.months * 30.44 * 86400000, ephePath: path.dirname(file) });
    });
  } finally { active--; }
}
