#!/usr/bin/env python3
"""Convert GeoNames city data into the compact place file the app loads for birthplace search.

Usage: python3 -I build_places.py <cities1000.zip|cities*.txt> <admin1CodesASCII.txt> <out places.txt>

Output (UTF-8, tab separated):
  line 1  "#places v1\t<count>\tGeoNames CC BY 4.0"
  line 2  "TZ\t" + time zone ids joined by "|"
  line 3  "A1\t" + state/province entries "Name=code" joined by "|" (US codes are postal abbreviations)
  rows    name \t search aliases ("|" joined) \t country code \t admin1 index \t lat \t lon \t tz index \t population
Rows are sorted by population, largest first.
"""
import io, re, sys, unicodedata, zipfile

# Places of 50,000+ keep every Latin-script alternate name (Bombay, Peking, Leningrad, Königsberg ...). GeoNames lists
# alternates alphabetically, so any cap drops well-known names; tested on 40 former/English names: all found.
ALIAS_MIN_POP = 50000
MAX_ALIASES = 10 ** 6
LATIN = re.compile(r"^[A-Za-zÀ-ɏḀ-ỿ' .\-()]+$")


def fold(s):
    """Lower case without accents, the key the page searches on."""
    return ''.join(c for c in unicodedata.normalize('NFD', s.lower()) if unicodedata.category(c) != 'Mn')


def read_cities(path):
    if path.endswith('.zip'):
        z = zipfile.ZipFile(path)
        name = next(n for n in z.namelist() if n.endswith('.txt'))
        return io.TextIOWrapper(z.open(name), encoding='utf-8')
    return open(path, encoding='utf-8')


def main(cities_path, admin1_path, out_path):
    admin1 = {}
    with open(admin1_path, encoding='utf-8') as f:
        for line in f:
            p = line.rstrip('\n').split('\t')
            if len(p) >= 2 and p[0]:
                admin1[p[0]] = p[1]

    tz_index, a1_index, rows = {}, {}, []
    skipped = 0
    for line in read_cities(cities_path):
        p = line.rstrip('\n').split('\t')
        if len(p) < 19:
            skipped += 1
            continue
        name, ascii_name, alts = p[1].strip(), p[2].strip(), p[3]
        try:
            lat, lon, pop = float(p[4]), float(p[5]), int(p[14] or 0)
        except ValueError:
            skipped += 1
            continue
        cc, a1code, tz = p[8].strip(), p[10].strip(), p[17].strip()
        if not name or not tz or not (-90 <= lat <= 90 and -180 <= lon <= 180):
            skipped += 1
            continue
        keys = {fold(name)}
        aliases = []
        if ascii_name and fold(ascii_name) not in keys:
            aliases.append(ascii_name); keys.add(fold(ascii_name))
        if pop >= ALIAS_MIN_POP and alts:
            for a in alts.split(','):
                a = a.strip()
                if len(aliases) >= MAX_ALIASES + 1:
                    break
                if not (3 <= len(a) <= 40) or not LATIN.match(a):
                    continue
                if a.isupper() and len(a) <= 4:      # airport and other codes
                    continue
                k = fold(a)
                if k in keys:
                    continue
                keys.add(k); aliases.append(a)
        a1name = admin1.get(cc + '.' + a1code, '')
        a1key = (cc, a1code)
        if a1name and a1key not in a1_index:
            a1_index[a1key] = (len(a1_index), a1name)
        if tz not in tz_index:
            tz_index[tz] = len(tz_index)
        clean = lambda s: s.replace('\t', ' ').replace('|', ' ')
        rows.append((pop, clean(name), '|'.join(clean(a) for a in aliases), cc,
                     a1_index[a1key][0] if a1name else -1, round(lat, 3), round(lon, 3), tz_index[tz]))

    rows.sort(key=lambda r: (-r[0], r[1]))
    tzs = [t for t, _ in sorted(tz_index.items(), key=lambda kv: kv[1])]
    a1s = [v[1].replace('|', ' ').replace('=', ' ') + '=' + k[1] for k, v in sorted(a1_index.items(), key=lambda kv: kv[1][0])]
    with open(out_path, 'w', encoding='utf-8', newline='\n') as out:
        out.write('#places v1\t%d\tGeoNames CC BY 4.0\n' % len(rows))
        out.write('TZ\t' + '|'.join(tzs) + '\n')
        out.write('A1\t' + '|'.join(a1s) + '\n')
        for pop, name, aliases, cc, a1, lat, lon, tz in rows:
            out.write('%s\t%s\t%s\t%d\t%s\t%s\t%d\t%d\n' % (name, aliases, cc, a1, ('%.3f' % lat).rstrip('0').rstrip('.'),
                                                       ('%.3f' % lon).rstrip('0').rstrip('.'), tz, pop))
    print('places %d, time zones %d, regions %d, skipped %d' % (len(rows), len(tzs), len(a1s), skipped))


if __name__ == '__main__':
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:])
