import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, existsSync, symlinkSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const places = path.join(app, "tests/places.txt");
if (!existsSync(places)) symlinkSync(path.resolve(app, "../../generated-artifacts/places.txt"), places);
const digest = file => createHash("sha256").update(readFileSync(file)).digest("hex");
if (digest(path.join(app, "vendor/core.js")) !== digest(path.join(app, "tests/core.js")) ||
    digest(path.join(app, "vendor/core.js")) !== digest(path.join(app, "../dhruva-jyotisha/reference/core.js")) ||
    digest(path.join(app, "vendor/core.js")) !== digest(path.join(app, "../dhruva-jyotisha/public/core.js")) ||
    digest(path.join(app, "vendor/placesearch.js")) !== digest(path.join(app, "tests/placesearch.js"))) {
  throw new Error("The protected calculation core differs between runtime and regression tests.");
}
for (const name of ["test-engine", "test", ...Array.from({ length: 10 }, (_, i) => `test${i + 2}`)]) {
  const result = spawnSync(process.execPath, [path.join(app, "tests", `${name}.js`)], { encoding: "utf8", cwd: path.join(app, "tests") });
  const output = `${result.stdout ?? ""}\n${result.stderr ?? ""}`;
  process.stdout.write(`\n${name}: ${output.trim().split("\n").slice(-3).join("\n")}\n`);
  if (result.status !== 0 || /^FAIL/m.test(output)) process.exit(1);
}
