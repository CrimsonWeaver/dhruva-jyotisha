import { createRequire } from "node:module";
import { randomBytes, randomUUID } from "node:crypto";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(path.resolve(app, "../../lib/db/package.json"));
const { Pool } = require("pg");
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
const users = [randomUUID(), randomUUID()];
const tokens = [randomBytes(32).toString("hex"), randomBytes(32).toString("hex")];
let checks = 0;
async function request(route, { user, method = "GET", body, status = 200 } = {}) {
  const response = await fetch(`${origin}/api${route}`, {
    method,
    headers: { ...(user == null ? {} : { Authorization: `Bearer ${tokens[user]}` }), ...(body ? { "Content-Type": "application/json" } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  assert.equal(response.status, status, `${method} ${route} status`);
  checks++;
  return response.status === 204 ? null : response;
}
try {
  for (let i = 0; i < 2; i++) {
    await pool.query("INSERT INTO users (id, first_name) VALUES ($1, 'API verification')", [users[i]]);
    await pool.query("INSERT INTO sessions (sid, sess, expire) VALUES ($1, $2, NOW() + INTERVAL '10 minutes')", [
      tokens[i], JSON.stringify({ user: { id: users[i], email: null, firstName: "API verification", lastName: null, profileImageUrl: null }, access_token: "", expires_at: Math.floor(Date.now() / 1000) + 600 }),
    ]);
  }
  await request("/charts", { status: 401 });
  const body = { name: "API verification chart", placeLabel: "Greenwich", lat: 51.48, lon: 0, tz: "Europe/London", localDate: "2000-01-01", localTime: "12:00", nodeType: "mean", dasaYear: 365.25, zodiac: "tropical", sbFrame: "tropical", ayanamsaMode: "equatorial" };
  const created = await (await request("/charts", { user: 0, method: "POST", body, status: 201 })).json();
  assert.equal(created.localDate, body.localDate);
  assert.equal(created.utcMs, Date.UTC(2000, 0, 1, 12));
  const id = created.id;
  await request("/export", { status: 401 });
  // Seed only synthetic historical records to verify preservation and owner isolation.
  const legacyText = "Synthetic historical record retained for export.";
  const legacy = await pool.query(
    "INSERT INTO readings (chart_id, transit_ms, months, focus, model, text) VALUES ($1, $2, 3, '', 'retired-test-model', $3) RETURNING id",
    [id, Date.UTC(2026, 0, 1), legacyText],
  );
  for (const route of ["reading", "readings"]) {
    await request(`/charts/${id}/${route}`, { method: "POST", body: { months: 3 }, status: 401 });
    await request(`/charts/${id}/${route}`, { user: 1, method: "POST", body: { months: 3 }, status: 404 });
    const gone = await request(`/charts/${id}/${route}`, { user: 0, method: "POST", body: { months: 3 }, status: 410 });
    assert.match(gone.headers.get("content-type"), /application\/json/);
    assert.match((await gone.json()).error, /no longer available/);
    await request(`/charts/${id}/${route}`, { user: 0, status: 410 });
  }
  await request(`/charts/${id}`, { user: 1, status: 404 });
  await request(`/charts/${id}`, { user: 1, method: "PATCH", body: { name: "Unauthorized edit" }, status: 404 });
  await request(`/charts/${id}/readings`, { user: 1, status: 404 });
  await request(`/charts/${id}/share`, { user: 1, method: "POST", status: 404 });
  const updated = await (await request(`/charts/${id}`, { user: 0, method: "PATCH", body: { name: "API verification updated" } })).json();
  assert.equal(updated.name, "API verification updated");
  await request(`/charts/${id}`, { user: 0, method: "PATCH", body: { tz: "Invalid/Zone" }, status: 400 });
  const settings = await (await request("/settings", { user: 0, method: "PATCH", body: { nodeType: "true", ayanamsaMode: "lahiri" } })).json();
  assert.equal(settings.nodeType, "true");
  const summary = await (await request("/charts/summary", { user: 0 })).json();
  assert.equal(summary.chartCount, 1);
  const share = await (await request(`/charts/${id}/share`, { user: 0, method: "POST", status: 201 })).json();
  const shared = await (await request(`/shared/${share.token}`)).json();
  assert.equal(shared.chart.name, updated.name);
  assert.equal(shared.chart.userId, undefined);
  assert.equal(shared.readings, undefined);
  await request(`/charts/${id}/share`, { user: 0, method: "DELETE", status: 204 });
  await request(`/shared/${share.token}`, { status: 404 });
  const exported = await (await request("/export", { user: 0 })).json();
  assert.equal(exported.charts.length, 1);
  assert.equal(exported.settings.nodeType, "true");
  assert.equal(exported.readings.length, 1);
  assert.equal(exported.readings[0].id, legacy.rows[0].id);
  assert.equal(exported.readings[0].text, legacyText);
  const otherExport = await (await request("/export", { user: 1 })).json();
  assert.equal(otherExport.readings.length, 0);
  assert.equal(otherExport.charts.length, 0);
  const calculation = await (await request("/calculate", { method: "POST", body })).json();
  assert.equal(calculation.chart.bodies.length, 9);
  assert.equal(calculation.cusps.length, 12);
  assert.equal(Object.keys(calculation.vargas.asc).length, 16);
  assert.ok(calculation.events.length > 0);
  await request("/calculate", { method: "POST", body: { ...body, localDate: "2024-03-10", localTime: "02:30", tz: "America/New_York" }, status: 400 });
  await request(`/charts/${id}`, { user: 0, method: "DELETE", status: 204 });
  await request(`/charts/${id}`, { user: 0, status: 404 });
  console.log(`PASS API integration checks (${checks} requests), retired AI endpoints, owner-only historical export, sharing, input validation and real calculations`);
} finally {
  await pool.query("DELETE FROM sessions WHERE sid = ANY($1::varchar[])", [tokens]);
  await pool.query("DELETE FROM users WHERE id = ANY($1::varchar[])", [users]);
  await pool.end();
}
