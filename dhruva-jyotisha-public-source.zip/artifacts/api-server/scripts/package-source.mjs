import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { mkdirSync } from "node:fs";

const app = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const root = path.resolve(app, "../..");
// Explicit allowlist: never archive environment files, uploads, personal data,
// local conversations, Git history, credentials or runtime caches.
const entries = [
  "LICENSE", "LICENSE-NOTICE.md", "README.md", ".gitignore", "package.json", "pnpm-lock.yaml",
  "pnpm-workspace.yaml", "tsconfig.json", "tsconfig.base.json",
  ".github/workflows/engine-regressions.yml", ".github/workflows/chart-downloads.yml",
  "lib/api-client-react", "lib/api-spec", "lib/api-zod", "lib/db", "lib/replit-auth-web",
  "scripts/package.json", "scripts/tsconfig.json", "scripts/src",
  "artifacts/api-server/src", "artifacts/api-server/vendor", "artifacts/api-server/tests",
  "artifacts/api-server/scripts", "artifacts/api-server/package.json", "artifacts/api-server/tsconfig.json",
  "artifacts/api-server/build.mjs",
  "artifacts/dhruva-jyotisha/src", "artifacts/dhruva-jyotisha/public",
  "artifacts/dhruva-jyotisha/reference", "artifacts/dhruva-jyotisha/package.json",
  "artifacts/dhruva-jyotisha/tsconfig.json", "artifacts/dhruva-jyotisha/vite.config.ts",
  "artifacts/dhruva-jyotisha/index.html", "artifacts/dhruva-jyotisha/components.json",
  "artifacts/dhruva-jyotisha/tests", "artifacts/dhruva-jyotisha/playwright.config.ts",
  "artifacts/dhruva-jyotisha/tsconfig.browser.json",
];
const output = path.resolve(process.argv[2] ?? path.join(app, "dist/dhruva-source.tar.gz"));
mkdirSync(path.dirname(output), { recursive: true });
execFileSync("tar", [
  "--exclude=node_modules", "--exclude=dist", "--exclude=*.tsbuildinfo",
  "--exclude=.env", "--exclude=.env.*", "--exclude=.git", "--exclude=.local",
  "--exclude=.agents", "--exclude=.cache", "--exclude=generated-artifacts",
  "--exclude=artifacts/api-server/tests/places.txt",
  "-czf", output, "-C", root, ...entries,
]);
