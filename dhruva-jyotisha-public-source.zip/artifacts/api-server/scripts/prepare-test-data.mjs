import { mkdir, writeFile, access } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const app = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = path.resolve(app, "../../generated-artifacts");
await mkdir(path.join(out, "ephe"), { recursive: true });
async function download(url, file) {
  try { await access(file); return; } catch { /* Download missing public data. */ }
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Dataset download failed (${response.status}).`);
  await writeFile(file, Buffer.from(await response.arrayBuffer()));
}
for (const name of ["sepl_18.se1", "semo_18.se1"]) {
  await download(`https://raw.githubusercontent.com/aloistr/swisseph/master/ephe/${name}`, path.join(out, "ephe", name));
}
try { await access(path.join(out, "places.txt")); } catch {
  await download("https://download.geonames.org/export/dump/cities1000.zip", path.join(out, "cities1000.zip"));
  await download("https://download.geonames.org/export/dump/admin1CodesASCII.txt", path.join(out, "admin1CodesASCII.txt"));
  execFileSync("python3", ["-I", path.join(app, "scripts/build_places.py"), path.join(out, "cities1000.zip"), path.join(out, "admin1CodesASCII.txt"), path.join(out, "places.txt")], { stdio: "inherit" });
}
