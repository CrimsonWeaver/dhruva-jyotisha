import { Storage } from "@google-cloud/storage";
import path from "node:path";

const root = process.env.DATASET_SOURCE_DIR;
if (!root) throw new Error("Set DATASET_SOURCE_DIR to the extracted source directory.");
const storage = new Storage({
  credentials: {
    audience: "replit", subject_token_type: "access_token",
    token_url: "http://127.0.0.1:1106/token", type: "external_account",
    credential_source: { url: "http://127.0.0.1:1106/credential", format: { type: "json", subject_token_field_name: "access_token" } },
    universe_domain: "googleapis.com",
  }, projectId: "",
});
const bucket = storage.bucket(process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID);
for (const name of ["places.txt", "ephe/sepl_18.se1", "ephe/semo_18.se1"]) {
  const source = name === "places.txt" ? path.join(root, name) : path.resolve("../../generated-artifacts", name);
  await bucket.upload(source, { destination: `dhruva-datasets/${name}` });
  console.log(`Uploaded application dataset: ${name}`);
}
