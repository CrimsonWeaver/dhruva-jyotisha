import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { renderToStaticMarkup } from 'react-dom/server';
import { NORTH_CELLS, SOUTH_POS, signForHouse } from '../src/lib/chart-layout';
import { canExportChart, chartPdfFilename } from '../src/lib/chart-export-data';
import { NorthChart, NorthChartSvg } from '../src/components/north-chart';
import { chartReport } from '../src/components/chart-pdf';
import { natalItems, RashiGrid } from '../src/components/astro-ui';
import { TABS, TabBar, resolveChartTab } from '../src/components/chart-workspace';
import type { TDocumentDefinitions } from 'pdfmake/interfaces';
import { fixture, input } from './fixtures/chart';

export async function run(pdf: { createPdf: (doc: TDocumentDefinitions) => { getBuffer: () => Promise<Buffer> } }, output: string) {
  assert.deepEqual(TABS.map(tab => tab.key), ['overview', 'chart', 'strength', 'dasa', 'transits', 'method']);
  for (const tab of TABS) assert.equal(resolveChartTab(tab.key), tab.key);
  assert.equal(resolveChartTab('reading'), 'overview', 'Legacy reading URLs resolve to the overview');
  assert.equal(resolveChartTab(undefined), 'overview');
  assert.equal(resolveChartTab('unsupported'), 'overview');
  const tabs = renderToStaticMarkup(<TabBar tab="overview" onTab={() => {}}/>);
  assert.equal((tabs.match(/role="tab"/g) || []).length, 6);
  assert.ok(!/reading/i.test(tabs), 'Navigation has no AI reading tools for any chart audience');
  assert.equal(NORTH_CELLS.length, 12);
  assert.deepEqual(SOUTH_POS[11], [0, 0]);
  assert.deepEqual(SOUTH_POS[0], [1, 0]);
  assert.ok(NORTH_CELLS[0].points.startsWith('200,0'));
  assert.ok(NORTH_CELLS[1].x < NORTH_CELLS[0].x, 'House 2 advances counterclockwise to upper left');
  const c = fixture(), original = JSON.stringify(c);
  for (let asc = 0; asc < 12; asc++) {
    const signs = Array.from({ length: 12 }, (_, h) => signForHouse(asc, h));
    assert.deepEqual([...signs].sort((a, b) => a - b), Array.from({ length: 12 }, (_, i) => i));
    assert.equal(signs[0], asc);
    assert.equal(signs[11], (asc + 11) % 12);
    const markup = renderToStaticMarkup(<NorthChartSvg items={natalItems(c, true)} lagna={asc}/>);
    for (let h = 0; h < 12; h++) assert.ok(markup.includes(`data-house="${h + 1}" data-sign="${signs[h]}"`));
  }
  const cuspItems = natalItems(c, true);
  assert.ok(cuspItems[c.cusps[4].sign].some(it => it.key === 'c5'), 'Cusps remain in computed signs');
  const crowded = { 3: Array.from({ length: 24 }, (_, i) => ({ key: `p${i}`, text: `P${i}`, tone: i % 2 ? 'tr' as const : 'cusp' as const })) };
  const markup = renderToStaticMarkup(<NorthChart items={crowded} lagna={3} title="Crowded transit chart"/>);
  assert.ok(markup.includes('+22 in key'));
  assert.ok(markup.includes('>P23'), 'Full crowded annotations remain visible in the key');
  const sav = renderToStaticMarkup(<NorthChartSvg items={{}} lagna={8} heat={{ 0: 33, 8: 27 }}/>);
  assert.ok(sav.includes('>33</text>') && sav.includes('>27</text>'));
  assert.ok(renderToStaticMarkup(<RashiGrid items={natalItems(c)} lagna={3} title="Default"/>).includes('data-chart-style="south"'));
  assert.equal(JSON.stringify(c), original, 'Rendering never mutates calculated values');
  assert.ok(canExportChart(c));
  assert.equal(chartPdfFilename('PDF परीक्षण', 'north'), 'PDF-परीक्षण-north-indian.pdf');
  assert.equal(chartPdfFilename('../Unsafe:/Name', 'south'), '-Unsafe-Name-south-indian.pdf');
  assert.equal(canExportChart(null), false);
  const invalid = fixture(); invalid.chart.bodies[0].degInSign = NaN;
  assert.equal(canExportChart(invalid), false);
  assert.throws(() => chartReport(input, invalid, 'north'), /complete calculation/);
  for (const style of ['north', 'south'] as const) {
    const doc = chartReport(input, c, style);
    const serialized = JSON.stringify(doc);
    assert.ok(serialized.includes('Devanagari') && serialized.includes('Asia/Kolkata'));
    assert.ok(serialized.includes('headerRows') && serialized.includes('dontBreakRows'));
    const buffer = await pdf.createPdf(doc).getBuffer();
    assert.equal(buffer.subarray(0, 5).toString(), '%PDF-');
    const file = `${output}/${style}.pdf`;
    await writeFile(file, buffer);
    const text = execFileSync('pdftotext', ['-layout', file, '-'], { encoding: 'utf8' });
    for (const term of ['Asia/Kolkata', '1990-01-01', '12:00', 'Swiss Ephemeris', 'Planetary positions', 'Campanus', 'Calculation settings', 'Sun', 'Ketu']) assert.ok(text.includes(term), `PDF contains ${term}`);
    const fonts = execFileSync('pdffonts', [file], { encoding: 'utf8' });
    assert.ok(fonts.includes('NotoSansDevanagari') && fonts.includes('Roboto'), 'PDF embeds fonts, preserving Unicode');
    const bounds = execFileSync('pdftotext', ['-bbox', file, '-'], { encoding: 'utf8' });
    for (const word of bounds.matchAll(/<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)"/g)) {
      assert.ok(Number(word[1]) >= 39 && Number(word[3]) <= 557, 'Text fits horizontal page margins');
      assert.ok(Number(word[2]) >= 40 && Number(word[4]) <= 820, 'Text fits vertical page margins');
    }
    console.log(`${style}: valid ${buffer.length}-byte PDF; required content, fonts and page bounds passed`);
  }
  console.log('Chart presentation tests passed: all ascendants, cusp signs, crowded annotations, SAV, defaults, PDF guards and both reports.');
}
