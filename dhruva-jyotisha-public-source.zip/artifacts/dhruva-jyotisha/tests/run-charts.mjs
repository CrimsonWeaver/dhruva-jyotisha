import { build } from 'esbuild';
import { mkdir, readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const output = new URL('../../../generated-artifacts/chart-tests/', import.meta.url);
await mkdir(output, { recursive: true });
await build({
  entryPoints: [fileURLToPath(new URL('./chart-presentation.tsx', import.meta.url))],
  outfile: fileURLToPath(new URL('presentation.mjs', output)),
  bundle: true, platform: 'node', format: 'esm', jsx: 'automatic',
  banner: { js: 'import { createRequire } from "node:module"; const require = createRequire(import.meta.url);' },
  tsconfig: fileURLToPath(new URL('../tsconfig.json', import.meta.url)),
  loader: { '.ttf': 'dataurl' },
  external: ['pdfmake/build/pdfmake', 'pdfmake/build/vfs_fonts'],
});
// Display helpers require the core at module initialization, but these tests must
// never request astronomy or modify the supplied engine.
globalThis.window = { createCore: () => ({}) };
const require = createRequire(new URL('../package.json', import.meta.url));
const pdf = require('pdfmake/build/pdfmake');
pdf.addVirtualFileSystem({
  ...require('pdfmake/build/vfs_fonts'),
  'NotoSansDevanagari-Regular.ttf': (await readFile(new URL('../src/assets/fonts/NotoSansDevanagari-Regular.ttf', import.meta.url))).toString('base64'),
});
pdf.addFonts({ Devanagari: Object.fromEntries(['normal', 'bold', 'italics', 'bolditalics'].map(key => [key, 'NotoSansDevanagari-Regular.ttf'])) });
const { run } = await import(new URL('presentation.mjs', output));
await run(pdf, fileURLToPath(output));
