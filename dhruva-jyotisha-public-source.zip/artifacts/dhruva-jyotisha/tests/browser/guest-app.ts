import { test as base, expect, type Page } from '@playwright/test';
import type { Chart, ChartInput } from '@workspace/api-client-react';
import { fixture, input } from '../fixtures/chart';

export const FONT_REQUEST = /\/[^/?]*NotoSansDevanagari[^/?]*\.ttf(?:\?.*)?$/;
const STYLE_KEY = 'dhruva-chart-style';
const CHART_ID = '11111111-1111-4111-8111-111111111111';
const SHARE_TOKEN = 'synthetic-read-only-share-token';

export type RouteMode = 'guest' | 'owned' | 'shared';

function savedChart(mode: Exclude<RouteMode, 'guest'>): Chart {
  const owned = mode === 'owned';
  const chartInput: ChartInput = {
    ...input,
    name: owned ? 'Owned synthetic chart' : 'Shared synthetic chart',
    placeLabel: owned ? 'Owned fixture location' : 'Shared fixture location',
    localDate: owned ? '2001-05-06' : '2002-06-07',
    localTime: owned ? '07:08' : '08:09',
    tz: 'Etc/UTC',
    lat: owned ? 1.2345 : 3.4567,
    lon: owned ? 2.3456 : 4.5678,
  };
  const utcMs = Date.parse(`${chartInput.localDate}T${chartInput.localTime}:00.000Z`);
  return {
    ...chartInput,
    nodeType: chartInput.nodeType ?? 'mean',
    dasaYear: chartInput.dasaYear ?? 365.25,
    zodiac: chartInput.zodiac ?? chartInput.sbFrame ?? 'sidereal',
    ayanamsaMode: chartInput.ayanamsaMode ?? 'lahiri',
    sbFrame: chartInput.sbFrame ?? 'sidereal',
    id: CHART_ID,
    utcMs,
    engineVersion: owned ? 'saved-engine-owned-fixture-v7' : 'saved-engine-shared-fixture-v9',
    createdAt: '2026-01-02T03:04:05.000Z',
    updatedAt: '2026-02-03T04:05:06.000Z',
  };
}

async function storage(page: Page) {
  return page.evaluate(() => ({
    local: { ...localStorage },
    session: { ...sessionStorage },
  }));
}

type GuestApp = {
  downloads: string[];
  calculations: unknown[];
  expectedInput: ChartInput;
  expectedAscendant: string;
  chart?: Chart;
  routeMode: RouteMode;
  checkPrivacy: () => Promise<void>;
};

export const test = base.extend<{ app: GuestApp; routeMode: RouteMode }>({
  routeMode: ['guest', { option: true }],
  app: async ({ page, context, baseURL, routeMode }, use) => {
    const origin = new URL(baseURL!).origin;
    const forbidden: string[] = [];
    const calculations: unknown[] = [];
    const downloads: string[] = [];
    const errors: string[] = [];
    const apiRequests: { method: string; path: string }[] = [];
    const chart = routeMode === 'guest' ? undefined : savedChart(routeMode);
    const expectedAscendant = routeMode === 'guest' ? 'Cancer' : routeMode === 'owned' ? 'Leo' : 'Virgo';
    const expectedInput: ChartInput = chart ? {
      name: chart.name,
      placeLabel: chart.placeLabel,
      lat: chart.lat,
      lon: chart.lon,
      tz: chart.tz,
      localDate: chart.localDate,
      localTime: chart.localTime,
      nodeType: chart.nodeType,
      dasaYear: chart.dasaYear,
      ayanamsaMode: chart.ayanamsaMode,
      sbFrame: chart.sbFrame,
      zodiac: chart.sbFrame,
    } : input;
    page.on('download', download => downloads.push(download.suggestedFilename()));
    page.on('pageerror', error => errors.push(error.message));

    // Only the exact synthetic reads and calculation are allowed. Block AND record
    // everything else, including GETs and writes via sendBeacon.
    await context.route('**/*', async route => {
      const request = route.request();
      const url = new URL(request.url());
      if (url.pathname.startsWith('/api/')) {
        const method = request.method();
        apiRequests.push({ method, path: url.pathname });
        if (url.origin === origin && method === 'GET' && url.pathname === '/api/auth/user') {
          const user = routeMode === 'owned'
            ? { id: 'synthetic-browser-test-user', email: 'synthetic@example.invalid', firstName: 'Test', lastName: 'Owner', profileImageUrl: null }
            : null;
          await route.fulfill({ json: { user } });
        } else if (url.origin === origin && method === 'POST' && url.pathname === '/api/calculate') {
          const calculationInput = request.postDataJSON() as ChartInput;
          calculations.push(calculationInput);
          const result = fixture();
          if (chart) {
            result.chart.ms = chart.utcMs;
            result.chart.asc.sign = routeMode === 'owned' ? 4 : 5;
          }
          await route.fulfill({ json: result });
        } else if (url.origin === origin && method === 'GET' && routeMode === 'owned' && url.pathname === `/api/charts/${CHART_ID}`) {
          await route.fulfill({ json: chart });
        } else if (url.origin === origin && method === 'GET' && routeMode === 'shared' && url.pathname === `/api/shared/${SHARE_TOKEN}`) {
          await route.fulfill({ json: { chart } });
        } else if (url.origin === origin && method === 'GET' && routeMode === 'owned' && url.pathname === '/api/settings') {
          await route.fulfill({ json: {
            nodeType: 'mean', dasaYear: 365.25, zodiac: 'sidereal', ayanamsaMode: 'lahiri', sbFrame: 'sidereal',
            hereLabel: null, hereLat: null, hereLon: null, hereTz: null,
          } });
        } else {
          forbidden.push(`${request.method()} ${url.pathname}`);
          await route.abort('blockedbyclient');
        }
      } else if (url.origin !== origin && !['blob:', 'data:'].includes(url.protocol)) {
        // External visual fonts/telemetry are irrelevant; never depend on them.
        forbidden.push(`${request.method()} ${url.origin}${url.pathname}`);
        await route.abort('blockedbyclient');
      } else if (!['GET', 'HEAD'].includes(request.method())) {
        forbidden.push(`${request.method()} ${url.pathname}`);
        await route.abort('blockedbyclient');
      } else {
        await route.continue();
      }
    });
    // Visual Google fonts are not the PDF's local embedded fonts.
    await context.route(/https:\/\/fonts\.(googleapis|gstatic)\.com\//, route => route.fulfill({ body: '' }));
    await context.addInitScript(({ input, routeMode }) => {
      // Seed just the tab-local preview, as if the guest submitted the birth form.
      // Never reset it on reload: a privacy regression must remain observable.
      if (!sessionStorage.getItem('browser-test-seeded')) {
        if (routeMode === 'guest') sessionStorage.setItem('dhruva-preview-input', JSON.stringify(input));
        sessionStorage.setItem('browser-test-seeded', 'yes');
        localStorage.setItem('browser-test-sentinel', 'unchanged');
        if (routeMode !== 'guest') localStorage.setItem('dhruva-chart-style', 'north');
      }
    }, { input, routeMode });

    const path = routeMode === 'guest' ? 'preview'
      : routeMode === 'owned' ? `chart/${CHART_ID}`
      : `shared/${SHARE_TOKEN}`;
    await page.goto(path);
    await expect(page.getByTestId('text-user')).toHaveText(routeMode === 'owned' ? 'Test' : 'Guest session');
    await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
    if (routeMode === 'guest') await expect(page.getByTestId('table-grahas')).toBeVisible();
    if (routeMode === 'owned') await expect(page.getByTestId('text-chart-name')).toHaveText(chart!.name);
    if (routeMode === 'shared') {
      await expect(page.getByTestId('text-chart-name')).toHaveText(chart!.name);
      await expect(page.getByText('Shared chart · read only')).toBeVisible();
    }
    expect(calculations).toEqual([expectedInput]);
    const initial = await storage(page);
    const initialState = await context.storageState({ indexedDB: true });
    const checkPrivacy = async () => {
      expect(forbidden, 'No unexpected API calls or external data requests').toEqual([]);
      expect(errors, 'No uncaught browser errors').toEqual([]);
      for (const calculation of calculations) expect(calculation).toEqual(expectedInput);
      expect(apiRequests.filter(({ method, path }) => method !== 'GET' && path !== '/api/calculate'),
        'No chart, share-link, account, or report mutations').toEqual([]);
      if (routeMode === 'owned') expect(apiRequests).toContainEqual({ method: 'GET', path: `/api/charts/${CHART_ID}` });
      if (routeMode === 'shared') expect(apiRequests).toContainEqual({ method: 'GET', path: `/api/shared/${SHARE_TOKEN}` });
      const current = await storage(page);
      expect(current.session, 'Birth input stays tab-local and unchanged').toEqual(initial.session);
      const withoutStyle = (values: Record<string, string>) =>
        Object.fromEntries(Object.entries(values).filter(([key]) => key !== STYLE_KEY));
      expect(withoutStyle(current.local), 'No birth details or PDFs written to localStorage').toEqual(withoutStyle(initial.local));
      if (current.local[STYLE_KEY]) expect(['north', 'south']).toContain(current.local[STYLE_KEY]);
      const state = await context.storageState({ indexedDB: true });
      expect(state.cookies, 'No new account/session cookies').toEqual(initialState.cookies);
      expect(state.origins.map(({ localStorage: _, ...rest }) => rest), 'No IndexedDB report storage')
        .toEqual(initialState.origins.map(({ localStorage: _, ...rest }) => rest));
    };
    await use({ downloads, calculations, expectedInput, expectedAscendant, chart, routeMode, checkPrivacy });
    await checkPrivacy();
  },
});

export { expect };
