import { execFileSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import type { Download, Page, TestInfo } from '@playwright/test';
import type { Chart } from '@workspace/api-client-react';
import { test, expect, FONT_REQUEST } from './guest-app';
import { chartPdfFilename } from '../../src/lib/chart-export-data';
import { input } from '../fixtures/chart';

type Style = 'south' | 'north';

async function verifyDownload(
  download: Download,
  style: Style,
  testInfo: TestInfo,
  label: string = style,
  expectedInput = input,
  chart?: Chart,
  expectedAscendant?: string,
) {
  expect(download.suggestedFilename()).toBe(chartPdfFilename(expectedInput.name, style));
  expect(await download.failure()).toBeNull();
  const path = testInfo.outputPath(`${label}.pdf`);
  await download.saveAs(path);
  const bytes = await readFile(path);
  expect(bytes.subarray(0, 5).toString()).toBe('%PDF-');
  expect(bytes.length).toBeGreaterThan(10_000);
  const text = execFileSync('pdftotext', ['-layout', path, '-'], { encoding: 'utf8' });
  for (const term of [
    expectedInput.name, expectedInput.localDate, expectedInput.localTime, expectedInput.placeLabel, expectedInput.tz,
    'Planetary positions',
    'Swiss Ephemeris presentation-test', 'Calculation settings', 'Sun', 'Ketu',
    style === 'south' ? 'South Indian' : 'North Indian',
  ]) expect(text).toContain(term);
  if (chart) {
    expect(text).toContain(new Date(chart.utcMs).toISOString());
    expect(text).toContain(chart.engineVersion);
  }
  if (expectedAscendant) expect(text).toContain(expectedAscendant);
  expect(text).not.toContain(style === 'south' ? 'North Indian' : 'South Indian');
  const fonts = execFileSync('pdffonts', [path], { encoding: 'utf8' });
  expect(fonts).toContain('NotoSansDevanagari');
  expect(fonts).toContain('Roboto');
  await testInfo.attach(`${label} PDF`, { path, contentType: 'application/pdf' });
}

async function download(
  page: Page,
  style: Style,
  info: TestInfo,
  expectedInput = input,
  chart?: Chart,
  label: string = style,
  expectedAscendant?: string,
) {
  const event = page.waitForEvent('download');
  await page.getByTestId('button-download-pdf').click();
  await verifyDownload(await event, style, info, label, expectedInput, chart, expectedAscendant);
  await expect(page.getByRole('status')).toHaveText('PDF ready. Your browser will download the file.');
  await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
}

test('guest downloads both layouts and keeps only the layout preference after reload', async ({ page, app }, info) => {
  await expect(page.getByRole('radio', { name: 'South Indian' })).toBeChecked();
  await expect(page.locator('[data-chart-style="south"]')).toBeVisible();
  await download(page, 'south', info);
  await page.getByRole('radio', { name: 'North Indian' }).check();
  await expect(page.locator('[data-chart-style="north"]')).toBeVisible();
  await download(page, 'north', info);
  expect(app.downloads).toHaveLength(2);
  expect(app.calculations).toHaveLength(1);
  await app.checkPrivacy();

  await page.reload();
  await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
  await expect(page.getByRole('radio', { name: 'North Indian' })).toBeChecked();
  await expect(page.locator('[data-chart-style="north"]')).toBeVisible();
  expect(app.calculations).toHaveLength(2); // reload, not layout/export, recalculates
});

test('font failure emits no download and retries successfully on the same page', async ({ page, app }, info) => {
  let fontRequests = 0;
  let failFont = true;
  await page.route(FONT_REQUEST, async route => {
    // In Vite dev mode the asset also has a JS ?import wrapper. Intercept
    // only pdfEngine's fetch of the actual font, not that module import.
    if (route.request().resourceType() !== 'fetch') return route.continue();
    fontRequests++;
    if (failFont) await route.fulfill({ status: 503, body: 'Injected PDF font failure' });
    else await route.continue();
  });
  const pageIdentity = await page.evaluate(() => performance.timeOrigin);
  await page.getByTestId('button-download-pdf').click();
  await expect(page.getByRole('alert')).toHaveText('PDF export failed: The PDF font could not be loaded. Please retry.');
  await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
  await expect(page.getByTestId('button-download-pdf')).toHaveAttribute('aria-busy', 'false');
  expect(fontRequests).toBe(1);
  expect(app.downloads).toHaveLength(0);
  await app.checkPrivacy();

  failFont = false;
  await download(page, 'south', info);
  await expect(page.getByRole('alert')).toHaveCount(0);
  expect(fontRequests, 'Retry must refetch the font rather than reuse a rejected promise').toBe(2);
  expect(app.downloads).toHaveLength(1);
  expect(app.calculations).toHaveLength(1);
  expect(await page.evaluate(() => performance.timeOrigin)).toBe(pageIdentity);
});

for (const start of ['south', 'north'] as const) {
  const next = start === 'south' ? 'north' : 'south';
  test(`pending ${start} export keeps its original layout when switched to ${next}`, async ({ page, app }, info) => {
    if (start === 'north') await page.getByRole('radio', { name: 'North Indian' }).check();
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const reached = page.waitForRequest(request =>
      FONT_REQUEST.test(request.url()) && request.resourceType() === 'fetch', { timeout: 15_000 });
    await page.route(FONT_REQUEST, async route => {
      if (route.request().resourceType() !== 'fetch') return route.continue();
      await gate;
      await route.continue();
    });
    const event = page.waitForEvent('download');
    try {
      await page.getByTestId('button-download-pdf').click();
      await reached; // deterministic barrier, not a timing-dependent sleep
      await expect(page.getByTestId('button-download-pdf')).toBeDisabled();
      await expect(page.getByTestId('button-download-pdf')).toHaveAttribute('aria-busy', 'true');
      await expect(page.getByRole('status')).toContainText('Preparing PDF');
      expect(app.downloads).toHaveLength(0);
      await page.getByRole('radio', { name: next === 'north' ? 'North Indian' : 'South Indian' }).check();
      await expect(page.locator(`[data-chart-style="${next}"]`)).toBeVisible();
      await expect(page.getByTestId('button-download-pdf')).toBeDisabled();
      await expect(page.getByRole('status')).toHaveCount(0); // no feedback for the wrong layout
    } finally {
      release(); // never strand the intercepted request, even when an assertion fails
    }
    await verifyDownload(await event, start, info, `pending-${start}`);
    await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
    await expect(page.getByRole('status')).toHaveCount(0);
    expect(app.downloads).toHaveLength(1);
    expect(app.calculations).toHaveLength(1);
    await app.checkPrivacy();

    // The next click uses the newly selected layout, not the pending job's closure.
    await download(page, next, info);
    expect(app.downloads).toHaveLength(2);
    expect(app.calculations).toHaveLength(1);
    await page.getByRole('radio', { name: start === 'north' ? 'North Indian' : 'South Indian' }).check();
    await expect(page.getByRole('status')).toHaveCount(0); // don't resurrect the earlier job's success
  });
}

for (const routeMode of ['owned', 'shared'] as const) {
  test.describe(`${routeMode} chart downloads`, () => {
    test.use({ routeMode });

    test('downloads the saved chart with its engine and UTC metadata using the local layout', async ({ page, app }, info) => {
      const chart = app.chart!;
      const name = routeMode === 'owned' ? 'owned' : 'shared';
      await expect(page.getByRole('radio', { name: 'North Indian' })).toBeChecked();
      await download(page, 'north', info, app.expectedInput, chart, `${name}-north`, app.expectedAscendant);
      await page.getByRole('radio', { name: 'South Indian' }).check();
      await expect(page.getByRole('radio', { name: 'South Indian' })).toBeChecked();
      await download(page, 'south', info, app.expectedInput, chart, `${name}-south`, app.expectedAscendant);
      await app.checkPrivacy();

      await page.reload();
      await expect(page.getByTestId('button-download-pdf')).toBeEnabled();
      await expect(page.getByRole('radio', { name: 'South Indian' })).toBeChecked();
      await download(page, 'south', info, app.expectedInput, chart, `${name}-south-after-reload`, app.expectedAscendant);
      expect(app.downloads).toHaveLength(3);
      expect(app.calculations).toHaveLength(2);
    });
  });
}
