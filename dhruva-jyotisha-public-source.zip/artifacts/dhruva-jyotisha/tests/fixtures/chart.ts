import type { ChartInput } from '@workspace/api-client-react';
import type { Calc } from '../../src/lib/astro';

// Synthetic presentation data, not an astronomical reference or a real birth record.
const nak = { index: 0, name: 'Ashwini', sanskrit: 'अश्विनी', lord: 'Ketu', pada: 1, fraction: 0.2 };
const ids = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

export const fixture = () => ({
  engineVersion: 'Swiss Ephemeris presentation-test',
  chart: {
    ms: 631175400000, nodeType: 'mean', zodiac: 'sidereal', ayanamsa: 24.1234, ayMode: 'lahiri', ayStandard: true,
    asc: { sign: 3, degInSign: 12.34, trop: 126.4634, nak },
    bodies: ids.map((id, i) => ({
      id, abbr: id.slice(0, 2), sign: i % 12, degInSign: i + 1.25, trop: i * 30 + 25.3734,
      nak, house: (i - 3 + 12) % 12 + 1, retro: i > 5,
    })),
  },
  cusps: Array.from({ length: 12 }, (_, i) => ({ house: i + 1, sign: (i + 3) % 12, deg: 7.5 })),
  // Only the overview fields used by the guest preview are needed by browser tests.
  strength: { planets: [{ id: 'Sun', rank: 1, rupas: 7, ratio: 1.2 }] },
  dasa: { nak, birthMs: 631175400000, yearMs: 365.25 * 86400000, periods: [] },
}) as unknown as Calc;

export const input: ChartInput = {
  name: 'PDF परीक्षण', placeLabel: 'Chennai चेन्नई, India', localDate: '1990-01-01', localTime: '12:00',
  tz: 'Asia/Kolkata', lat: 13.0827, lon: 80.2707, nodeType: 'mean', dasaYear: 365.25,
  ayanamsaMode: 'lahiri', sbFrame: 'sidereal', zodiac: 'sidereal',
};
