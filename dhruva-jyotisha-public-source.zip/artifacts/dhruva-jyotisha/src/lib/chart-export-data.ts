import type { Calc } from './astro';
import type { ChartStyle } from './chart-layout';

export const chartPdfFilename = (name: string, style: ChartStyle) =>
  `${name.normalize('NFC').replace(/[^\p{L}\p{M}\p{N}_-]+/gu, '-').slice(0, 70) || 'chart'}-${style}-indian.pdf`;

/** Reject partial/non-finite data rather than export a misleading report. */
export function canExportChart(c: Calc | null): c is Calc {
  return !!c && !!c.engineVersion && Number.isFinite(c.chart?.ms) &&
    Number.isInteger(c.chart.asc.sign) && c.chart.asc.sign >= 0 && c.chart.asc.sign < 12 &&
    Number.isFinite(c.chart.asc.degInSign) && Number.isFinite(c.chart.ayanamsa) &&
    c.chart.bodies.length === 9 && c.chart.bodies.every(b => Number.isInteger(b.sign) && b.sign >= 0 && b.sign < 12 && Number.isFinite(b.degInSign) && Number.isFinite(b.trop));
}
