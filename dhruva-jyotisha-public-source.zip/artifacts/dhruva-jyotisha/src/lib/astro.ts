// Focused shapes of the Dhruva core output (see api-server/vendor/core.js). Values are only displayed, never derived astronomically here.
import type { ChartCalculation } from '@workspace/api-client-react';

export interface Nak { index: number; name: string; sanskrit: string; lord: string; pada: number; fraction: number }
export interface Body {
  id: string; abbr: string; trop: number; sid: number; speed: number; eclLat: number; decl: number; retro: boolean;
  sign: number; signName: string; signSanskrit: string; degInSign: number; lon: number; nak: Nak; house: number;
}
export interface CoreChart {
  ms: number; nodeType: string; zodiac: string; ayanamsa: number; ayanamsaMean?: number; ayStandard: boolean; ayMode: string;
  gcLon: number; gcLat: number; gcSidereal: number; lat: number; lon: number;
  asc: { trop: number; sid: number; sign: number; signName: string; signSanskrit: string; degInSign: number; lon: number; nak: Nak };
  mc: { trop: number; sign: number; signName: string; degInSign: number };
  bodies: Body[];
}
export interface SbPlanet {
  id: string; house: number; sign: number;
  sthana: { uccha: number; sapta: number; ojha: number; kendra: number; drekkana: number; total: number };
  dig: number;
  kala: { nata: number; paksha: number; tribhaga: number; abda: number; masa: number; vara: number; hora: number; ayana: number; total: number };
  cheshta: number; cheshtaKendra: number | null; naisargika: number; drik: number;
  total: number; rupas: number; required: number; requiredRupas: number; ratio: number; meets: boolean; ishta: number; kashta: number; rank: number;
}
export interface TimeFactors {
  sunrise: number; sunset: number; nextSunrise: number; polar?: boolean; isDay: boolean; weekday: number; varaLord: string; horaLord: string;
  horaNumber: number; tribhagaLord: string; tribhagaPart: number; hoursFromNoon: number; yearLord: string | null; monthLord: string | null;
}
export interface Strength { frame: string; planets: SbPlanet[]; time: TimeFactors; war: { a: string; b: string; separation: number }[]; elongation: number; waxing: boolean }
export interface AvState { value: number; grade?: string; reason?: string; gain?: number }
export interface AvInfluence { state: string; from: string; how: string; value: number; amount: number }
export interface AvPlanet {
  id: string; shadbala: number; required: number; house: number; sign: number;
  states: Record<string, AvState | null>; influences: AvInfluence[]; garvita: boolean; cushion: number;
}
export interface Avasthas { frame: string; planets: AvPlanet[]; matrix: Record<string, Record<string, { kind: string; value: number }>> }
export interface Ashtakavarga { frame: string; bav: Record<string, number[]>; sav: number[]; contrib: Record<string, string[][]>; refSigns: Record<string, number> }
export interface Period { lord: string; level: number; fullStart: number; fullEnd: number }
export interface Dasa { nak: Nak; lord: string; balanceYears: number; elapsedYears: number; periods: Period[]; birthMs: number; yearMs: number }
export interface Cusp {
  house: number; trop: number; sid: number; sign: number; deg: number; lord: string; rasiHouse: number; nak: Nak;
  near: { id: string; abbr: string; dist: number; ahead: boolean }[]; aspects: { id: string; value: number }[];
}
export interface Vargas { frame: string; asc: Record<string, number>; bodies: { id: string; abbr: string; signs: Record<string, number>; dignity: Record<string, string> }[] }
export interface Contact { to: string; kind: string; aspect: number; name: string; orb: number }
export interface TransitBody {
  id: string; abbr: string; trop: number; sid: number; sign: number; deg: number; retro: boolean; nak: Nak; house: number; fromMoon: number;
  contacts: Contact[]; av: { bindus: number | null; sav: number; kakshya: string | null; kakshyaGood: boolean | null };
}
export interface Transit {
  ms: number; frame: string; lat: number; lon: number; rising: { trop: number; sign: number; deg: number; house: number; nak: Nak };
  bodies: TransitBody[]; strength?: Strength;
  influences?: { id: string; influences: { from: string; state: string; how: string; value: number; amount: number }[]; delight: number; affliction: number; net: number }[];
}
export interface TEvent { ms: number; kind: string; body?: string; sign?: number; retro?: boolean; nak?: number; name?: string; to?: string; toKind?: string; aspect?: number; level?: number; lords?: string[]; end?: number }
export interface Calc {
  chart: CoreChart; strength: Strength; avasthas: Avasthas; ashtakavarga: Ashtakavarga; dasa: Dasa; cusps: Cusp[]; vargas: Vargas;
  engineVersion: string; transit?: Transit; events?: TEvent[];
}
export const asCalc = (c: ChartCalculation) => c as unknown as Calc;

export const SIGNS = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
export const SIGN_SHORT = ['Ar', 'Ta', 'Ge', 'Cn', 'Le', 'Vi', 'Li', 'Sc', 'Sg', 'Cp', 'Aq', 'Pi'];
export const SKT: Record<string, string> = { Sun: 'सूर्य', Moon: 'चन्द्र', Mars: 'मंगल', Mercury: 'बुध', Jupiter: 'गुरु', Venus: 'शुक्र', Saturn: 'शनि', Rahu: 'राहु', Ketu: 'केतु' };
export const VARGA_META: { n: number; name: string; area: string }[] = [
  { n: 1, name: 'Rasi', area: 'Body and the life as a whole' }, { n: 2, name: 'Hora', area: 'Wealth' },
  { n: 3, name: 'Drekkana', area: 'Siblings, courage' }, { n: 4, name: 'Chaturthamsa', area: 'Fortune, home and property' },
  { n: 7, name: 'Saptamsa', area: 'Children and grandchildren' }, { n: 9, name: 'Navamsa', area: 'Spouse, dharma, inner strength' },
  { n: 10, name: 'Dasamsa', area: 'Career, status and power' }, { n: 12, name: 'Dvadasamsa', area: 'Parents' },
  { n: 16, name: 'Shodasamsa', area: 'Vehicles, comforts and happiness' }, { n: 20, name: 'Vimsamsa', area: 'Worship and spiritual pursuits' },
  { n: 24, name: 'Chaturvimsamsa', area: 'Learning and education' }, { n: 27, name: 'Saptavimsamsa', area: 'Strengths and weaknesses' },
  { n: 30, name: 'Trimsamsa', area: 'Misfortunes and difficulties' }, { n: 40, name: 'Khavedamsa', area: 'Auspicious and inauspicious effects (maternal)' },
  { n: 45, name: 'Akshavedamsa', area: 'General character (paternal)' }, { n: 60, name: 'Shashtyamsa', area: 'All matters; past karma' },
];

export function dms(deg: number) {
  const sign = deg < 0 ? '-' : ''; let a = Math.abs(deg);
  let d = Math.floor(a); a = (a - d) * 60; let m = Math.floor(a); let s = Math.round((a - m) * 60);
  if (s === 60) { s = 0; m += 1; } if (m === 60) { m = 0; d += 1; }
  return `${sign}${d}°${String(m).padStart(2, '0')}′${String(s).padStart(2, '0')}″`;
}
export const fx = (n: number | null | undefined, p = 2) => (n == null || !Number.isFinite(n) ? '—' : n.toFixed(p));
export const fmtDate = (ms: number, tz?: string) => new Date(ms).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric', timeZone: tz });
export const fmtDateTime = (ms: number, tz?: string) => new Date(ms).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: tz });
export const fmtTime = (ms: number, tz?: string) => new Date(ms).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', timeZone: tz });
export function safeTz(tz?: string) { try { if (tz) new Intl.DateTimeFormat(undefined, { timeZone: tz }); return tz; } catch { return undefined; } }

declare global {
  interface Window {
    createCore(vector: (body: string, date: Date) => { x: number; y: number; z: number }): {
      subPeriods(period: Period, birthMs: number): Period[];
      runningAt(dasa: Dasa, ms: number): Period[];
    };
  }
}
// Use the supplied, unmodified engine even for date subdivisions. No astrology
// is reimplemented by presentation components; browser position requests fail.
const displayCore = window.createCore(() => { throw new Error('New astronomical positions require the Swiss Ephemeris server.'); });
export function subPeriods(p: Period, birthMs: number): Period[] {
  return displayCore.subPeriods(p, birthMs);
}
export function runningChain(d: Dasa, ms: number, depth = 4) {
  return displayCore.runningAt(d, ms).slice(0, depth);
}
export const LEVELS = ['Mahadasa', 'Antardasa', 'Pratyantar', 'Sukshma', 'Prana'];
export function spanLabel(ms: number) {
  const days = ms / 86400000;
  if (days >= 365) return `${(days / 365.25).toFixed(1)} y`;
  if (days >= 45) return `${(days / 30.44).toFixed(1)} mo`;
  if (days >= 1) return `${days.toFixed(1)} d`;
  return `${(days * 24).toFixed(1)} h`;
}
