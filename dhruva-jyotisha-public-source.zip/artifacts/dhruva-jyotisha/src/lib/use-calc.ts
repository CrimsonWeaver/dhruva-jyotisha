import { useCallback, useEffect, useRef, useState } from 'react';
import { useCalculateChart } from '@workspace/api-client-react';
import type { ChartInput } from '@workspace/api-client-react';
import { asCalc, type Calc } from './astro';

export function errorText(err: unknown, fallback: string) {
  const e = err as { data?: { error?: string }; message?: string } | null;
  return e?.data?.error || (e?.message && !/^HTTP|fetch/i.test(e.message) ? e.message : '') || fallback;
}

export function birthInput(c: Pick<ChartInput, 'name' | 'placeLabel' | 'lat' | 'lon' | 'tz' | 'localDate' | 'localTime' | 'nodeType' | 'dasaYear' | 'zodiac' | 'ayanamsaMode' | 'sbFrame'>): ChartInput {
  return { name: c.name, placeLabel: c.placeLabel, lat: c.lat, lon: c.lon, tz: c.tz, localDate: c.localDate, localTime: c.localTime,
    nodeType: c.nodeType, dasaYear: c.dasaYear, zodiac: c.sbFrame ?? c.zodiac, ayanamsaMode: c.ayanamsaMode, sbFrame: c.sbFrame };
}

export interface TransitArgs { transitMs?: number; transitLat?: number; transitLon?: number }

/** Calls POST /api/calculate whenever the input (plus transit options) changes. Results are kept in memory only. */
export function useChartCalc(input: ChartInput | null, transit?: TransitArgs) {
  const calc = useCalculateChart();
  const mutateRef = useRef(calc.mutateAsync); mutateRef.current = calc.mutateAsync;
  const [data, setData] = useState<Calc | null>(null);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  const key = input ? JSON.stringify({ ...input, ...transit }) : '';
  const seq = useRef(0);
  const run = useCallback(() => {
    if (!key) return;
    const body = JSON.parse(key) as ChartInput; const n = ++seq.current;
    setPending(true); setError('');
    mutateRef.current({ data: body }).then(res => { if (n === seq.current) setData(asCalc(res)); })
      .catch(err => { if (n === seq.current) setError(errorText(err, 'The calculation service did not respond. No values were estimated.')); })
      .finally(() => { if (n === seq.current) setPending(false); });
  }, [key]);
  useEffect(() => { run(); }, [run]);
  return { data, error, pending, retry: run };
}
