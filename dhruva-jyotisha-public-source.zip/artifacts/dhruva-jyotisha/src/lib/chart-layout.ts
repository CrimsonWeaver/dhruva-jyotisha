/** Presentation only: sign-indexed values never become computed bhava houses. */
export type ChartStyle = 'south' | 'north';
export const SOUTH_POS: Record<number, [number, number]> = { 11: [0, 0], 0: [1, 0], 1: [2, 0], 2: [3, 0], 3: [3, 1], 4: [3, 2], 5: [3, 3], 6: [2, 3], 7: [1, 3], 8: [0, 3], 9: [0, 2], 10: [0, 1] };
export const NORTH_CELLS = [
  { points: '200,0 300,100 200,200 100,100', x: 200, y: 72, width: 120 },
  { points: '0,0 200,0 100,100', x: 100, y: 16, width: 102 },
  { points: '0,0 100,100 0,200', x: 39, y: 81, width: 62 },
  { points: '0,200 100,100 200,200 100,300', x: 100, y: 172, width: 120 },
  { points: '0,200 100,300 0,400', x: 39, y: 281, width: 62 },
  { points: '0,400 100,300 200,400', x: 100, y: 342, width: 102 },
  { points: '200,200 300,300 200,400 100,300', x: 200, y: 272, width: 120 },
  { points: '200,400 300,300 400,400', x: 300, y: 342, width: 102 },
  { points: '400,200 400,400 300,300', x: 361, y: 281, width: 62 },
  { points: '200,200 300,100 400,200 300,300', x: 300, y: 172, width: 120 },
  { points: '400,0 400,200 300,100', x: 361, y: 81, width: 62 },
  { points: '200,0 400,0 300,100', x: 300, y: 16, width: 102 },
];
export const signForHouse = (lagna: number, houseIndex: number) => (lagna + houseIndex) % 12;
