import { createContext, useContext, useEffect, useState } from 'react';
import type { ChartStyle } from './chart-layout';

const KEY = 'dhruva-chart-style';
const StyleContext = createContext<{ style: ChartStyle; setStyle: (style: ChartStyle) => void }>({ style: 'south', setStyle: () => {} });
export function ChartStyleProvider({ children }: { children: React.ReactNode }) {
  const [style, update] = useState<ChartStyle>(() => {
    try { return localStorage.getItem(KEY) === 'north' ? 'north' : 'south'; } catch { return 'south'; }
  });
  const setStyle = (value: ChartStyle) => {
    update(value);
    try { localStorage.setItem(KEY, value); } catch { /* Private browsing may deny storage; the control still works. */ }
  };
  useEffect(() => {
    const sync = (event: StorageEvent) => { if (event.key === KEY) update(event.newValue === 'north' ? 'north' : 'south'); };
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);
  return <StyleContext.Provider value={{ style, setStyle }}>{children}</StyleContext.Provider>;
}
export const useChartStyle = () => useContext(StyleContext);
export function ChartStyleToggle() {
  const { style, setStyle } = useChartStyle();
  return <fieldset className="min-w-0">
    <legend className="mono mb-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">Chart layout</legend>
    <div className="flex flex-wrap gap-2">{(['south', 'north'] as const).map(value => <label key={value} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded border px-3 text-xs ${style === value ? 'border-primary bg-primary/10 text-primary' : 'border-border'}`}>
      <input type="radio" name="chart-layout" value={value} checked={style === value} onChange={() => setStyle(value)} className="accent-current" data-testid={`layout-${value}`}/>
      {value === 'south' ? 'South Indian' : 'North Indian'}
    </label>)}</div>
  </fieldset>;
}
