import { SIGNS, SIGN_SHORT } from '@/lib/astro';
import { NORTH_CELLS, signForHouse } from '@/lib/chart-layout';
import type { GridItem } from './astro-ui';

export const visibleItems = (items: GridItem[]) => items.length > 3 ? items.slice(0, 2) : items;
const colors: Record<string, string> = { moon: 'hsl(var(--accent))', asc: 'hsl(var(--primary))', tr: 'hsl(var(--primary))', muted: 'hsl(var(--muted-foreground))', cusp: 'hsl(var(--muted-foreground))', ex: '#047857', db: 'hsl(var(--primary))' };

/** One shared SVG for the screen and PDF. Crowded houses have a complete key below. */
export function NorthChartSvg({ items, lagna, heat, print = false }: { items: Record<number, GridItem[]>; lagna: number; heat?: Record<number, React.ReactNode>; print?: boolean }) {
  return <svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 402 402" width={print ? 402 : '100%'} height={print ? 402 : undefined} role="img" aria-label={`North Indian chart, ascendant ${SIGNS[lagna]}`} style={{ display: 'block', fontFamily: 'sans-serif', color: print ? '#262233' : 'hsl(var(--foreground))' }}>
    {NORTH_CELLS.map((cell, h) => {
      const sign = signForHouse(lagna, h), entries = items[sign] || [], shown = visibleItems(entries);
      return <g key={h} data-house={h + 1} data-sign={sign}>
        <title>{`House ${h + 1}, ${SIGNS[sign]}${h === 0 ? ', ascendant' : ''}: ${entries.map(it => `${it.text}${it.sup || ''}`).join(', ')}`}</title>
        <polygon points={cell.points} fill={h === 0 ? (print ? '#f7eef1' : 'hsl(var(--primary)/.09)') : (print ? '#ffffff' : 'hsl(var(--card))')} stroke={print ? '#8c8795' : 'hsl(var(--foreground)/.4)'} strokeWidth="1"/>
        <text x={cell.x} y={cell.y} textAnchor="middle" fill={print ? '#762b46' : 'hsl(var(--primary))'} fontSize="13" fontWeight="bold">{sign + 1} {SIGN_SHORT[sign]}</text>
        <text x={cell.x} y={cell.y + 12} textAnchor="middle" fill={print ? '#615b6b' : 'hsl(var(--muted-foreground))'} fontSize="8">H{h + 1}{h === 0 ? ' · Asc' : ''}</text>
        {heat?.[sign] != null && <text x={cell.x} y={cell.y + 33} textAnchor="middle" fill="currentColor" fontSize="20">{heat[sign]}</text>}
        {shown.map((it, i) => <text key={it.key} x={cell.x} y={cell.y + 27 + i * 14} textAnchor="middle" fill={print ? '#262233' : colors[it.tone || ''] || 'currentColor'} fontSize="13" textDecoration={it.tone === 'own' ? 'underline' : undefined}>{it.text}{it.sup && <tspan baselineShift="super" fontSize="8">{it.sup}</tspan>}</text>)}
        {entries.length > 3 && <text x={cell.x} y={cell.y + 55} textAnchor="middle" fill={print ? '#615b6b' : 'hsl(var(--muted-foreground))'} fontSize="10">+{entries.length - 2} in key</text>}
      </g>;
    })}
  </svg>;
}

export function NorthChart({ items, lagna, title, sub, heat }: { items: Record<number, GridItem[]>; lagna: number; title: string; sub?: string; heat?: Record<number, React.ReactNode> }) {
  const crowded = Object.entries(items).filter(([, entries]) => entries.length > 3);
  return <figure className="north-chart m-0 w-full max-w-[460px] self-start" data-testid="grid-rashi" data-chart-style="north">
    <figcaption className="mb-2 break-words text-center"><div className="display text-lg">{title}</div><div className="mono text-[9px] text-muted-foreground">{sub}</div></figcaption>
    <NorthChartSvg items={items} lagna={lagna} heat={heat}/>
    <p className="mt-2 text-[11px] text-muted-foreground">Fixed houses · signs numbered 1 (Aries) to 12 (Pisces), counterclockwise from Asc. C = computed Campanus cusp.</p>
    {crowded.length > 0 && <dl className="mt-2 grid gap-2 rounded border border-border p-2 text-xs" aria-label="Crowded signs, complete annotations">{crowded.map(([sign, entries]) => <div key={sign}><dt className="font-semibold">{SIGNS[Number(sign)]} · H{(Number(sign) - lagna + 12) % 12 + 1}</dt><dd className="m-0 flex flex-wrap gap-x-2 gap-y-1">{entries.map(it => <span key={it.key}>{it.text}{it.sup && <sup>{it.sup}</sup>}{it.tone === 'tr' ? ' (transit)' : it.tone === 'muted' ? ' (natal)' : ''}</span>)}</dd></div>)}</dl>}
  </figure>;
}
