import { useState } from 'react';
import { AlertTriangle, RotateCw } from 'lucide-react';
import { SIGNS, SIGN_SHORT, SKT, VARGA_META, dms, fx, type Calc, type Cusp } from '@/lib/astro';
import { useChartStyle } from '@/lib/chart-style';
import { NorthChart } from './north-chart';

export function Section({ eyebrow, title, note, children, aside }: { eyebrow?: string; title: string; note?: string; children: React.ReactNode; aside?: React.ReactNode }) {
  return <section className="surface min-w-0 rounded-md p-4 sm:p-6">
    <div className="flex flex-wrap items-end justify-between gap-3"><div className="min-w-0">{eyebrow && <div className="mono text-[9px] uppercase tracking-[.18em] text-primary">{eyebrow}</div>}<h2 className="display mt-1 text-2xl sm:text-[28px]">{title}</h2>{note && <p className="mt-1 max-w-3xl text-sm leading-6 text-muted-foreground">{note}</p>}</div>{aside}</div>
    <div className="mt-5 min-w-0">{children}</div>
  </section>;
}

export function CalcSkeleton() {
  return <div className="grid gap-5 lg:grid-cols-[minmax(0,460px)_minmax(0,1fr)]" data-testid="status-calculating">
    <div className="surface aspect-square animate-pulse rounded-md bg-muted/60"/>
    <div className="surface space-y-3 rounded-md p-6">{[70, 90, 55, 80, 60, 75].map((w, i) => <div key={i} className="h-4 animate-pulse rounded bg-muted" style={{ width: `${w}%` }}/>)}</div>
  </div>;
}

export function CalcError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <div className="flex flex-wrap items-start gap-4 border border-destructive/40 bg-destructive/5 p-4 sm:p-5" role="alert" data-testid="status-calc-error">
    <AlertTriangle size={19} className="mt-0.5 text-destructive"/>
    <div className="min-w-0 flex-1"><div className="text-sm font-semibold">Calculation failed</div><p className="mt-1 max-w-3xl text-xs leading-5 text-muted-foreground">{message} Nothing has been estimated or substituted; panels stay empty until the engine returns real values.</p></div>
    <button onClick={onRetry} className="flex min-h-9 items-center gap-2 rounded border border-border bg-card px-3 text-xs hover:bg-muted" data-testid="button-retry-calc"><RotateCw size={13}/> Recalculate</button>
  </div>;
}

/* South Indian layout: signs fixed, Pisces top-left. */
const POS: Record<number, [number, number]> = { 11: [1, 1], 0: [1, 2], 1: [1, 3], 2: [1, 4], 3: [2, 4], 4: [3, 4], 5: [4, 4], 6: [4, 3], 7: [4, 2], 8: [4, 1], 9: [3, 1], 10: [2, 1] };
export interface GridItem { key: string; text: string; sup?: string; tone?: 'moon' | 'asc' | 'ex' | 'db' | 'own' | 'muted' | 'tr' | 'cusp' }
const toneCls: Record<string, string> = { moon: 'text-accent', asc: 'text-primary font-semibold', ex: 'text-emerald-700 dark:text-emerald-400', db: 'text-primary', own: 'underline underline-offset-2', muted: 'text-muted-foreground text-[10px]', tr: 'text-primary font-semibold', cusp: 'rounded-sm border border-border px-0.5 text-[9px] text-muted-foreground' };

export function RashiGrid({ items, lagna, title, sub, heat }: { items: Record<number, GridItem[]>; lagna: number; title: string; sub?: string; heat?: Record<number, React.ReactNode> }) {
  const { style } = useChartStyle();
  if (style === 'north') return <NorthChart items={items} lagna={lagna} title={title} sub={sub} heat={heat}/>;
  return <div className="rashi-grid" data-testid="grid-rashi" data-chart-style="south">
    {Array.from({ length: 12 }, (_, s) => <div key={s} className={`rashi-cell ${s === lagna ? 'is-lagna' : ''}`} style={{ gridRow: POS[s][0], gridColumn: POS[s][1] }}>
      <div className="flex justify-between text-[9px] uppercase tracking-wider text-muted-foreground"><span className={s === lagna ? 'text-primary' : ''}>{SIGN_SHORT[s]}</span><span>{s === lagna ? 'Asc' : ((s - lagna + 12) % 12) + 1}</span></div>
      {heat?.[s] != null && <div className={`display text-center text-2xl tabular-nums ${Number(heat[s]) >= 30 ? 'text-accent' : Number(heat[s]) < 25 ? 'text-muted-foreground' : ''}`}>{heat[s]}</div>}
      <div className="flex flex-wrap gap-x-1.5 gap-y-0.5">{(items[s] || []).map(it => <span key={it.key} className={toneCls[it.tone || ''] || ''}>{it.text}{it.sup && <sup className="ml-px text-[0.6em]">{it.sup}</sup>}</span>)}</div>
    </div>)}
    <div className="rashi-center"><div className="display text-base leading-tight sm:text-lg">{title}</div>{sub && <div className="mono mt-1 text-[9px] uppercase tracking-wider text-muted-foreground">{sub}</div>}</div>
  </div>;
}

export function natalItems(c: Calc, withCusps = false): Record<number, GridItem[]> {
  const out: Record<number, GridItem[]> = {};
  const push = (s: number, it: GridItem) => { (out[s] ||= []).push(it); };
  push(c.chart.asc.sign, { key: 'As', text: `As ${Math.floor(c.chart.asc.degInSign)}°`, tone: 'asc' });
  c.chart.bodies.forEach(b => push(b.sign, { key: b.id, text: `${b.abbr} ${Math.floor(b.degInSign)}°`, sup: b.retro ? 'R' : undefined, tone: b.id === 'Moon' ? 'moon' : undefined }));
  if (withCusps) c.cusps.forEach(cp => cp.house > 1 && push(cp.sign, { key: `c${cp.house}`, text: `C${cp.house}`, tone: 'cusp' }));
  return out;
}

export function GrahaTable({ c }: { c: Calc }) {
  const rows = [{ id: 'Lagna', abbr: 'As', sign: c.chart.asc.sign, degInSign: c.chart.asc.degInSign, nak: c.chart.asc.nak, house: 1, retro: false, speed: null as number | null, decl: null as number | null, trop: c.chart.asc.trop, sid: c.chart.asc.sid }, ...c.chart.bodies];
  return <div className="table-wrap"><table className="data-table min-w-[760px]" data-testid="table-grahas"><thead><tr><th>Graha</th><th>Sign</th><th>Longitude</th><th>Nakshatra</th><th>Pada</th><th>Nak lord</th><th>House</th><th>Speed °/d</th><th>Decl.</th><th>Tropical</th></tr></thead><tbody>
    {rows.map(b => <tr key={b.id} className={b.id === 'Moon' ? 'row-moon' : ''} data-testid={`row-graha-${b.id}`}><td><span className="font-semibold">{b.id}</span>{SKT[b.id] && <span className="deva ml-1.5 text-muted-foreground">{SKT[b.id]}</span>}{b.retro && <span className="tag-retro">R</span>}</td><td>{SIGNS[b.sign]}</td><td className="num">{dms(b.degInSign)}</td><td>{b.nak.name}</td><td className="num">{b.nak.pada}</td><td>{b.nak.lord}</td><td className="num">{b.house}</td><td className="num">{b.speed == null ? '—' : fx(b.speed, 4)}</td><td className="num">{b.decl == null ? '—' : fx(b.decl, 2)}</td><td className="num">{dms(b.trop)}</td></tr>)}
  </tbody></table></div>;
}

const tag: Record<string, string> = { ex: 'ex', db: 'db', own: 'own' };
export function VargaPanel({ c }: { c: Calc }) {
  const [n, setN] = useState(9);
  const meta = VARGA_META.find(v => v.n === n)!;
  const items: Record<number, GridItem[]> = {};
  const ascS = c.vargas.asc[n];
  (items[ascS] ||= []).push({ key: 'As', text: 'As', tone: 'asc' });
  c.vargas.bodies.forEach(b => { const s = b.signs[n]; const d = b.dignity[n]; (items[s] ||= []).push({ key: b.id, text: b.abbr, tone: (tag[d] as GridItem['tone']) || (b.id === 'Moon' ? 'moon' : undefined), sup: d === 'ex' ? '↑' : d === 'db' ? '↓' : undefined }); });
  return <Section eyebrow="Shodasavarga / 16 divisions" title="Divisional charts" note={`Read in the ${c.vargas.frame} zodiac. Exalted green, debilitated rose, own sign underlined.`}>
    <div className="mb-4 flex flex-wrap gap-1.5" role="group" aria-label="Choose varga">{VARGA_META.map(v => <button key={v.n} aria-pressed={v.n === n} onClick={() => setN(v.n)} className={`mono min-h-9 min-w-11 rounded border px-2 text-xs ${v.n === n ? 'border-foreground bg-foreground text-background' : 'border-border bg-card hover:border-primary'}`} data-testid={`button-varga-${v.n}`}>D{v.n}</button>)}</div>
    <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
      <RashiGrid items={items} lagna={ascS} title={`D${n} ${meta.name}`} sub={meta.area}/>
      <div className="min-w-0"><h3 className="display text-2xl">{meta.name}</h3><p className="text-sm text-muted-foreground">{meta.area}</p>
        <div className="table-wrap mt-4"><table className="data-table min-w-[520px] text-center"><thead><tr><th>Graha</th>{[1, 9, 10, n].filter((v, i, a) => a.indexOf(v) === i).map(v => <th key={v}>D{v}</th>)}<th>Dignity D{n}</th></tr></thead><tbody>
          {c.vargas.bodies.map(b => <tr key={b.id}><td className="text-left font-semibold">{b.id}</td>{[1, 9, 10, n].filter((v, i, a) => a.indexOf(v) === i).map(v => <td key={v} className={`num dg-${b.dignity[v] || 'none'}`}>{SIGN_SHORT[b.signs[v]]}</td>)}<td className="mono text-xs">{({ ex: 'Exalted', db: 'Debilitated', own: 'Own sign' } as Record<string, string>)[b.dignity[n]] || '—'}</td></tr>)}
        </tbody></table></div></div>
    </div>
    <details className="mt-5"><summary className="cursor-pointer py-2 text-sm">All sixteen vargas in one table</summary><div className="table-wrap mt-2"><table className="data-table min-w-[900px] text-center"><thead><tr><th>Graha</th>{VARGA_META.map(v => <th key={v.n}>D{v.n}</th>)}</tr></thead><tbody>
      <tr><td className="text-left font-semibold text-primary">Lagna</td>{VARGA_META.map(v => <td key={v.n} className="num">{SIGN_SHORT[c.vargas.asc[v.n]]}</td>)}</tr>
      {c.vargas.bodies.map(b => <tr key={b.id}><td className="text-left font-semibold">{b.id}</td>{VARGA_META.map(v => <td key={v.n} className={`num dg-${b.dignity[v.n] || 'none'}`}>{SIGN_SHORT[b.signs[v.n]]}</td>)}</tr>)}
    </tbody></table></div></details>
  </Section>;
}

export function CuspsPanel({ cusps }: { cusps: Cusp[] }) {
  return <Section eyebrow="Bhava / Campanus cusps" title="House cusps" note="Points of concrete manifestation. Grahas within 15° and sphuta aspects of 30 virupas or more are listed for each cusp.">
    <div className="table-wrap"><table className="data-table min-w-[820px]" data-testid="table-cusps"><thead><tr><th>Bhava</th><th>Sign</th><th>Longitude</th><th>Nakshatra</th><th>Lord</th><th>Rasi house</th><th>Near (orb)</th><th>Aspects (virupas)</th></tr></thead><tbody>
      {cusps.map(cp => <tr key={cp.house}><td className="num font-semibold">{cp.house}</td><td>{SIGNS[cp.sign]}</td><td className="num">{dms(cp.deg)}</td><td>{cp.nak.name} {cp.nak.pada}</td><td>{cp.lord}</td><td className="num">{cp.rasiHouse}</td><td className="text-xs">{cp.near.length ? cp.near.map(x => `${x.abbr} ${fx(x.dist, 1)}°`).join(', ') : '—'}</td><td className="text-xs">{cp.aspects.length ? cp.aspects.map(a => `${a.id} ${fx(a.value, 1)}`).join(', ') : '—'}</td></tr>)}
    </tbody></table></div>
  </Section>;
}
