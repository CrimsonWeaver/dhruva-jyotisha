import { Link } from 'wouter';
import { Activity, Clock3, Compass, Globe2, Grid2X2, Settings2 } from 'lucide-react';
import type { ChartInput } from '@workspace/api-client-react';
import { SIGNS, dms, fmtDate, fx, runningChain, safeTz, LEVELS } from '@/lib/astro';
import { useChartCalc } from '@/lib/use-calc';
import { CalcError, CalcSkeleton, CuspsPanel, GrahaTable, RashiGrid, Section, VargaPanel, natalItems } from './astro-ui';
import { AshtakavargaPanel, AvasthaPanel, ShadbalaPanel } from './astro-strength';
import { DasaPanel, TransitPanel } from './astro-time';
import { ChartTools } from './chart-tools';

export const TABS = [
  { key: 'overview', label: 'Overview', icon: <Compass size={14}/> }, { key: 'chart', label: 'Chart', icon: <Grid2X2 size={14}/> },
  { key: 'strength', label: 'Strength', icon: <Activity size={14}/> }, { key: 'dasa', label: 'Dasa', icon: <Clock3 size={14}/> },
  { key: 'transits', label: 'Transits', icon: <Globe2 size={14}/> },
  { key: 'method', label: 'Method', icon: <Settings2 size={14}/> },
];

export function resolveChartTab(tab?: string): string {
  return TABS.some(item => item.key === tab) ? tab! : 'overview';
}

export function TabBar({ tab, hrefFor, onTab }: { tab: string; hrefFor?: (k: string) => string; onTab?: (k: string) => void }) {
  const cls = (on: boolean) => `flex min-h-11 items-center gap-2 whitespace-nowrap border-b-2 px-3 text-xs no-underline ${on ? 'border-primary font-semibold text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`;
  return <div className="sticky-tabs -mx-4 mb-6 px-4 sm:-mx-7 sm:px-7 lg:-mx-10 lg:px-10"><nav className="no-scrollbar flex gap-1 overflow-x-auto" role="tablist">
    {TABS.map(t => hrefFor ? <Link key={t.key} href={hrefFor(t.key)} role="tab" aria-selected={tab === t.key} className={cls(tab === t.key)} data-testid={`tab-${t.key}`}>{t.icon}{t.label}</Link>
      : <button key={t.key} role="tab" aria-selected={tab === t.key} onClick={() => onTab?.(t.key)} className={cls(tab === t.key)} data-testid={`tab-${t.key}`}>{t.icon}{t.label}</button>)}
  </nav></div>;
}

export interface WorkspaceProps { input: ChartInput; tab: string; transitPlace?: { label: string; lat: number; lon: number } | null; meta?: { utcMs?: number; savedEngine?: string } }

export function ChartWorkspace(props: WorkspaceProps) {
  // Reset results synchronously when birth data changes; never export old positions with new details.
  return <CalculatedWorkspace key={JSON.stringify(props.input)} {...props} tab={resolveChartTab(props.tab)}/>;
}

function CalculatedWorkspace(props: WorkspaceProps) {
  const calc = useChartCalc(props.input);
  return <><ChartTools input={props.input} c={calc.data} disabled={calc.pending || !!calc.error || !calc.data} meta={props.meta}/><WorkspacePanels {...props} calc={calc}/></>;
}

function WorkspacePanels({ input, tab, transitPlace, meta, calc }: WorkspaceProps & { calc: ReturnType<typeof useChartCalc> }) {
  const tz = safeTz(input.tz);
  if (tab === 'transits') return <TransitPanel input={input} defaultPlace={transitPlace} tz={tz}/>;
  if (calc.error && !calc.data) return <CalcError message={calc.error} onRetry={calc.retry}/>;
  if (!calc.data) return <CalcSkeleton/>;
  const c = calc.data;
  const body = <div className={`grid gap-5 ${calc.pending ? 'opacity-60 transition-opacity' : ''}`}>{calc.error && <CalcError message={calc.error} onRetry={calc.retry}/>}</div>;
  if (tab === 'chart') return <div className="grid gap-5">{body}
    <div className="grid gap-5 lg:grid-cols-[minmax(0,440px)_minmax(0,1fr)]"><RashiGrid items={natalItems(c, true)} lagna={c.chart.asc.sign} title={input.name} sub={`D1 · ${c.chart.zodiac}`}/>
      <Section eyebrow="Angles" title="Lagna & midheaven"><dl className="grid gap-3 sm:grid-cols-2">{[['Lagna', `${SIGNS[c.chart.asc.sign]} ${dms(c.chart.asc.degInSign)}`], ['Lagna nakshatra', `${c.chart.asc.nak.name} pada ${c.chart.asc.nak.pada}`], ['Midheaven (tropical)', `${c.chart.mc.signName} ${dms(c.chart.mc.degInSign)}`], ['Ayanamsa', dms(c.chart.ayanamsa)]].map(([a, b]) => <div key={a} className="border-b border-border pb-2"><dt className="mono text-[9px] uppercase tracking-widest text-muted-foreground">{a}</dt><dd className="m-0 mt-0.5 text-sm">{b}</dd></div>)}</dl></Section></div>
    <Section eyebrow="Rashi / nine grahas" title="Graha positions" note={`Signs and degrees in the ${c.chart.zodiac} zodiac; nakshatras always sidereal.`}><GrahaTable c={c}/></Section>
    <VargaPanel c={c}/><CuspsPanel cusps={c.cusps}/></div>;
  if (tab === 'strength') return <div className="grid gap-5">{body}<ShadbalaPanel s={c.strength} tz={tz}/><AvasthaPanel a={c.avasthas}/><AshtakavargaPanel av={c.ashtakavarga} lagna={c.chart.asc.sign}/></div>;
  if (tab === 'dasa') return <div className="grid gap-5">{body}<DasaPanel d={c.dasa} tz={tz}/></div>;
  if (tab === 'method') return <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]"><Section eyebrow="Method record" title="Calculation method" note="Conventions sent with this calculation and the engine values that came back.">
    <div className="divide-y divide-border border-y border-border">{([['Ephemeris engine', c.engineVersion], ['Zodiac / Shadbala frame', `${input.sbFrame} (frame decides zodiac)`], ['Ayanamsa mode', `${c.chart.ayMode}${c.chart.ayStandard ? ' (standard, Swiss definition)' : ''}`], ['Ayanamsa value', `${dms(c.chart.ayanamsa)} (${fx(c.chart.ayanamsa, 6)}°)`], ['Mean ayanamsa', c.chart.ayanamsaMean != null ? dms(c.chart.ayanamsaMean) : '—'], ['Galactic Center', `${dms(c.chart.gcLon)} tropical · ${dms(c.chart.gcSidereal)} sidereal`], ['Lunar node', c.chart.nodeType], ['Dasa year length', `${input.dasaYear} days`], ['House system', 'Campanus (bhava cusps), whole-sign rasi houses'], ['Universal time', new Date(meta?.utcMs ?? c.chart.ms).toISOString()], ['Coordinates', `${input.lat.toFixed(5)}, ${input.lon.toFixed(5)} · ${input.tz}`], ...(meta?.savedEngine ? [['Recorded with', meta.savedEngine]] : [])] as [string, string][]).map(([l, v]) => <div key={l} className="grid gap-1 py-3 sm:grid-cols-[220px_minmax(0,1fr)] sm:items-center"><span className="mono text-[10px] uppercase tracking-widest text-muted-foreground">{l}</span><span className="break-words text-sm">{v}</span></div>)}</div></Section>
    <Section title="No hidden inference" note="Every value on these panels came from the server's Swiss Ephemeris calculation. If the engine fails, the panels show the failure instead of an estimate."><p className="text-xs text-muted-foreground">Dasa sub-periods are proportional divisions of the engine's mahadasa boundaries.</p></Section></div>;
  // overview
  const chain = runningChain(c.dasa, Date.now(), 3); const moon = c.chart.bodies.find(b => b.id === 'Moon')!;
  const strongest = [...c.strength.planets].sort((a, b) => a.rank - b.rank)[0];
  return <div className="grid gap-5">{body}<div className="grid gap-5 lg:grid-cols-[minmax(0,440px)_minmax(0,1fr)]">
    <RashiGrid items={natalItems(c)} lagna={c.chart.asc.sign} title={input.name} sub={`${input.localDate} · ${input.localTime}`}/>
    <div className="grid content-start gap-3 sm:grid-cols-2">
      {[['Lagna', `${SIGNS[c.chart.asc.sign]} ${dms(c.chart.asc.degInSign)}`, `${c.chart.asc.nak.name} pada ${c.chart.asc.nak.pada}`], ['Moon', `${SIGNS[moon.sign]} ${dms(moon.degInSign)}`, `${moon.nak.name} pada ${moon.nak.pada} · lord ${moon.nak.lord}`],
        ['Running dasa', chain.map(p => p.lord).join(' / ') || '—', chain.length ? `${LEVELS[chain.length - 1]} ends ${fmtDate(chain[chain.length - 1].fullEnd, tz)}` : 'Outside the cycle'], ['Strongest by ratio', strongest.id, `${fx(strongest.rupas, 2)} rupas · ${fx(strongest.ratio * 100, 0)}% of required`],
        ['Ayanamsa', dms(c.chart.ayanamsa), `${c.chart.ayMode} · ${c.chart.zodiac}`], ['Birth place', input.placeLabel, `${input.lat.toFixed(4)}, ${input.lon.toFixed(4)} · ${input.tz}`]].map(([a, b, s]) => <div key={a} className="surface min-w-0 rounded-md p-4" data-testid={`card-${a.toLowerCase().replaceAll(' ', '-')}`}><div className="mono text-[9px] uppercase tracking-widest text-muted-foreground">{a}</div><div className="display mt-1 break-words text-xl">{b}</div><div className="mt-0.5 text-xs text-muted-foreground">{s}</div></div>)}
    </div></div>
    <Section eyebrow="Rashi" title="Grahas at a glance"><GrahaTable c={c}/></Section></div>;
}

