import { useMemo, useState } from 'react';
import { ChevronRight, Crosshair, MapPin } from 'lucide-react';
import type { ChartInput, Place } from '@workspace/api-client-react';
import { LEVELS, SIGNS, SIGN_SHORT, dms, fmtDate, fmtDateTime, fx, runningChain, spanLabel, subPeriods, type Dasa, type Period, type TEvent } from '@/lib/astro';
import { useChartCalc } from '@/lib/use-calc';
import { CalcError, CalcSkeleton, RashiGrid, Section, type GridItem } from './astro-ui';
import { PlacePicker } from './place-picker';

function DasaRows({ list, d, depth, now, tz }: { list: Period[]; d: Dasa; depth: number; now: number; tz?: string }) {
  const [open, setOpen] = useState<number | null>(() => { const i = list.findIndex(p => now >= p.fullStart && now < p.fullEnd); return depth < 1 && i >= 0 ? i : null; });
  return <ul className={depth ? 'ml-2 border-l border-border pl-3' : ''}>{list.map((p, i) => {
    const run = now >= p.fullStart && now < p.fullEnd, past = p.fullEnd <= now, canOpen = depth < 4;
    const start = Math.max(p.fullStart, d.birthMs);
    return <li key={`${p.lord}-${p.fullStart}`}>
      <button disabled={!canOpen} aria-expanded={canOpen ? open === i : undefined} onClick={() => setOpen(open === i ? null : i)} className={`grid min-h-11 w-full grid-cols-[1rem_minmax(4.6rem,max-content)_minmax(0,1fr)_auto] items-baseline gap-x-2.5 border-b border-border/60 px-1 py-2 text-left ${canOpen ? 'hover:bg-muted/60' : 'cursor-default'}`} data-testid={`row-dasa-${depth}-${p.lord}`}>
        <ChevronRight size={13} className={`self-center text-muted-foreground transition-transform ${open === i ? 'rotate-90' : ''} ${canOpen ? '' : 'opacity-0'}`}/>
        <span className={`display flex items-center gap-1.5 ${depth ? 'text-base' : 'text-lg'} ${run ? 'font-bold text-accent' : past ? 'text-muted-foreground' : ''}`}>{run && <span className="size-2 rounded-full bg-accent"/>}{p.lord}</span>
        <span className={`mono truncate text-[11px] ${run ? '' : 'text-muted-foreground'}`}>{fmtDate(start, tz)} → {fmtDate(p.fullEnd, tz)}{p.fullStart < d.birthMs && <span className="ml-2 text-[9px] uppercase tracking-wider">balance at birth</span>}</span>
        <span className="mono text-[11px] text-muted-foreground">{spanLabel(p.fullEnd - start)}</span>
      </button>
      {open === i && <DasaRows list={subPeriods(p, d.birthMs)} d={d} depth={depth + 1} now={now} tz={tz}/>}
    </li>; })}</ul>;
}

export function DasaPanel({ d, tz }: { d: Dasa; tz?: string }) {
  const now = useMemo(() => Date.now(), []);
  const chain = runningChain(d, now);
  return <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
    <Section eyebrow="Vimshottari / five levels" title="Period sequence" note={`Moon in ${d.nak.name} pada ${d.nak.pada}; ${d.lord} balance at birth ${fx(d.balanceYears, 3)} years. Year length ${fx(d.yearMs / 86400000, 4)} days.`}>
      <DasaRows list={d.periods} d={d} depth={0} now={now} tz={tz}/>
    </Section>
    <Section eyebrow="Running now" title="Current chain">
      {chain.length ? <div className="grid gap-2">{chain.map((p, i) => { const pct = Math.min(100, Math.max(0, (now - p.fullStart) / (p.fullEnd - p.fullStart) * 100)); return <div key={i} className="grid grid-cols-[5.6rem_4.6rem_minmax(0,1fr)] items-center gap-x-2.5"><span className="mono text-[9px] uppercase tracking-wider text-muted-foreground">{LEVELS[i]}</span><span className="display text-base">{p.lord}</span><span className="relative h-1.5 overflow-hidden rounded bg-[hsl(var(--track))]"><span className="absolute inset-y-0 left-0 rounded bg-accent" style={{ width: `${pct}%` }}/></span><span className="mono col-start-3 text-[10px] text-muted-foreground">ends {fmtDate(p.fullEnd, tz)}</span></div>; })}</div> : <p className="text-sm text-muted-foreground">The present moment is outside the 120-year cycle.</p>}
    </Section>
  </div>;
}

const EV_LABEL = (e: TEvent) => {
  if (e.kind === 'ingress') return <><b>{e.body}</b> enters {SIGNS[e.sign ?? 0]}{e.retro ? ' (retrograde)' : ''}</>;
  if (e.kind === 'station') return <><b>{e.body}</b> stations {e.retro ? 'retrograde' : 'direct'}</>;
  if (e.kind === 'nakshatra') return <><b>{e.body}</b> enters {e.name}</>;
  if (e.kind === 'contact') return <><b>{e.body}</b> {e.name} natal {e.to}{e.retro ? ' (R)' : ''}</>;
  if (e.kind === 'dasa') return <><b className="text-primary">{LEVELS[e.level ?? 0]}</b> begins: {(e.lords || []).join(' / ')}</>;
  return <>{e.kind}</>;
};

const toLocalInput = (ms: number) => { const d = new Date(ms - new Date(ms).getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16); };

export function TransitPanel({ input, defaultPlace, tz }: { input: ChartInput; defaultPlace?: { label: string; lat: number; lon: number } | null; tz?: string }) {
  const [when, setWhen] = useState(() => toLocalInput(Date.now()));
  const [loc, setLoc] = useState<{ label: string; lat: number; lon: number }>(defaultPlace || { label: input.placeLabel, lat: input.lat, lon: input.lon });
  const [q, setQ] = useState(''); const [picked, setPicked] = useState<Place | null>(null);
  const [gps, setGps] = useState(''); const [kind, setKind] = useState('all');
  const ms = new Date(when).getTime();
  const args = Number.isFinite(ms) ? { transitMs: ms, transitLat: Number(loc.lat.toFixed(4)), transitLon: Number(loc.lon.toFixed(4)) } : undefined;
  const calc = useChartCalc(args ? input : null, args);
  const useGps = () => {
    if (!navigator.geolocation) { setGps('Location is not available in this browser.'); return; }
    setGps('Requesting location…');
    navigator.geolocation.getCurrentPosition(p => { setLoc({ label: 'Current location', lat: p.coords.latitude, lon: p.coords.longitude }); setGps(''); },
      err => setGps(err.code === err.PERMISSION_DENIED ? 'Location permission denied. Search for a place instead.' : 'Location could not be determined. Search for a place instead.'), { timeout: 12000, maximumAge: 300000 });
  };
  const t = calc.data?.transit; const events = calc.data?.events;
  const natalLagna = calc.data?.chart.asc.sign ?? 0; const natalMoonSign = calc.data?.chart.bodies.find(b => b.id === 'Moon')?.sign ?? 0;
  const items: Record<number, GridItem[]> = {};
  if (t) { (items[t.rising.sign] ||= []).push({ key: 'As', text: 'As', tone: 'asc' }); t.bodies.forEach(b => (items[b.sign] ||= []).push({ key: b.id, text: `${b.abbr} ${Math.floor(b.deg)}°`, tone: 'tr', sup: b.retro ? 'R' : undefined })); calc.data!.chart.bodies.forEach(b => (items[b.sign] ||= []).push({ key: `n${b.id}`, text: b.abbr, tone: 'muted' })); }
  const filtered = (events || []).filter(e => kind === 'all' || e.kind === kind);
  const byMonth = filtered.reduce<Record<string, TEvent[]>>((acc, e) => { const k = new Date(e.ms).toLocaleDateString(undefined, { month: 'long', year: 'numeric', timeZone: tz }); (acc[k] ||= []).push(e); return acc; }, {});
  return <div className="grid gap-5">
    <Section eyebrow="Transit / recompute" title="Sky at a moment" note="Planet positions are geocentric; the place sets the rising sign and the transit Shadbala.">
      <div className="grid gap-4 md:grid-cols-[220px_minmax(0,1fr)_auto] md:items-end">
        <label className="grid gap-1.5"><span className="mono text-[9px] uppercase tracking-widest text-muted-foreground">Date & time (your clock)</span><input type="datetime-local" value={when} onChange={e => setWhen(e.target.value)} className="field-input" data-testid="input-transit-when"/></label>
        <PlacePicker label="Observe from" query={q} setQuery={setQ} selected={picked} setSelected={p => { setPicked(p); if (p) setLoc({ label: p.label, lat: p.lat, lon: p.lon }); }}/>
        <div className="flex flex-wrap gap-2"><button onClick={useGps} className="flex min-h-10 items-center gap-2 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-transit-gps"><Crosshair size={14}/> Use my location</button><button onClick={() => setWhen(toLocalInput(Date.now()))} className="min-h-10 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-transit-now">Now</button></div>
      </div>
      <div className="mono mt-3 flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground"><MapPin size={12}/>{loc.label} · {loc.lat.toFixed(4)}, {loc.lon.toFixed(4)}{gps && <span className="text-primary" role="status">{gps}</span>}</div>
    </Section>
    {calc.pending && !calc.data ? <CalcSkeleton/> : calc.error ? <CalcError message={calc.error} onRetry={calc.retry}/> : !t ? <div className="surface rounded-md p-5 text-sm text-muted-foreground" data-testid="status-transit-missing">The calculation service returned natal results but no transit snapshot for this request. No transit values are shown.</div> : <>
      <div className={`grid gap-5 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)] ${calc.pending ? 'opacity-60' : ''}`}>
        <RashiGrid items={items} lagna={natalLagna} title="Transits over natal" sub={fmtDateTime(t.ms, tz)}/>
        <div className="surface min-w-0 rounded-md p-4"><div className="mono text-[9px] uppercase tracking-widest text-muted-foreground">Rising at observer</div><div className="display text-2xl">{SIGNS[t.rising.sign]} {dms(t.rising.deg)}</div><div className="text-xs text-muted-foreground">{t.rising.nak.name} · natal house {t.rising.house}</div>
          {t.influences && <div className="mt-4 grid gap-1.5"><div className="mono text-[9px] uppercase tracking-widest text-muted-foreground">Net influence on natal grahas (virupas)</div>{(() => { const m = Math.max(1, ...t.influences.map(i => Math.abs(i.net))); return t.influences.map(i => <div key={i.id} className="grid grid-cols-[4.6rem_minmax(0,1fr)_3.6rem] items-center gap-2"><span className="display">{i.id}</span><span className="relative h-2.5 rounded bg-[hsl(var(--track))]"><span className="absolute inset-y-[-3px] left-1/2 w-px bg-muted-foreground"/><span className={`absolute inset-y-0 rounded ${i.net >= 0 ? 'left-1/2 bg-emerald-700/80' : 'right-1/2 bg-primary'}`} style={{ width: `${Math.abs(i.net) / m * 50}%` }}/></span><span className="mono text-right text-xs">{fx(i.net, 0)}</span></div>); })()}</div>}
        </div>
      </div>
      <Section title="Transit positions" note={`Houses from natal lagna (${SIGN_SHORT[natalLagna]}) and Moon (${SIGN_SHORT[natalMoonSign]}). Kakshya is the 3°45′ sub-division lord.`}>
        <div className="table-wrap"><table className="data-table min-w-[960px]" data-testid="table-transits"><thead><tr><th>Graha</th><th>Sign</th><th>Longitude</th><th>Nakshatra</th><th>House</th><th>From Moon</th><th>Bindus / SAV</th><th>Kakshya</th><th>Contacts</th></tr></thead><tbody>
          {t.bodies.map(b => <tr key={b.id}><td className="font-semibold">{b.id}{b.retro && <span className="tag-retro">R</span>}</td><td>{SIGNS[b.sign]}</td><td className="num">{dms(b.deg)}</td><td>{b.nak.name} {b.nak.pada}</td><td className="num">{b.house}</td><td className="num">{b.fromMoon}</td><td className="num">{b.av.bindus ?? '—'} / {b.av.sav}</td><td className={b.av.kakshyaGood ? 'text-emerald-700 dark:text-emerald-400' : ''}>{b.av.kakshya ?? '—'}</td><td className="text-xs">{b.contacts.slice(0, 3).map(c => `${c.name} ${c.to} (${fx(c.orb, 1)}°)`).join('; ') || '—'}</td></tr>)}
        </tbody></table></div>
      </Section>
    </>}
    {events && <Section eyebrow="Timeline / next twelve months" title="Coming transit events" aside={<div className="flex flex-wrap gap-1.5">{['all', 'ingress', 'station', 'nakshatra', 'contact', 'dasa'].map(k => <button key={k} aria-pressed={kind === k} onClick={() => setKind(k)} className={`min-h-9 rounded-full border px-3 text-xs capitalize ${kind === k ? 'border-foreground bg-foreground text-background' : 'border-border text-muted-foreground'}`}>{k}</button>)}</div>}>
      {!filtered.length ? <p className="text-sm text-muted-foreground">No events of this kind in the window.</p> : Object.entries(byMonth).map(([m, list]) => <div key={m}><h4 className="mono mb-1 mt-4 text-[10px] font-normal uppercase tracking-widest text-muted-foreground">{m}</h4><ul className="grid">{list.map((e, i) => <li key={i} className="grid grid-cols-[4.2rem_minmax(0,1fr)] gap-2.5 border-b border-border/60 py-1.5 text-sm"><span className="mono pt-0.5 text-[11px] text-muted-foreground">{fmtDate(e.ms, tz).replace(/,?\s*\d{4}$/, '')}</span><span className="min-w-0 break-words">{EV_LABEL(e)}</span></li>)}</ul></div>)}
    </Section>}
  </div>;
}
