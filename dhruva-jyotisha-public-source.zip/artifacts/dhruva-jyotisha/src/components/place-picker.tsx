import { Check } from 'lucide-react';
import { getSearchPlacesQueryKey, useSearchPlaces } from '@workspace/api-client-react';
import type { Place } from '@workspace/api-client-react';

export function TextField({ label, value, onChange, type = 'text', placeholder, required = false, testId }: { label: string; value: string; onChange: (value: string) => void; type?: string; placeholder?: string; required?: boolean; testId?: string }) {
  return <label className="grid min-w-0 gap-1.5"><span className="mono text-[9px] uppercase tracking-[.15em] text-muted-foreground">{label}</span><input required={required} type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} className="field-input" data-testid={testId}/></label>;
}

export function SelectField({ label, value, onChange, options, testId }: { label: string; value: string; onChange: (v: string) => void; options: [string, string][]; testId?: string }) {
  return <label className="grid min-w-0 gap-1.5"><span className="mono text-[9px] uppercase tracking-widest text-muted-foreground">{label}</span><select value={value} onChange={e => onChange(e.target.value)} className="field-input" data-testid={testId}>{options.map(([v, l]) => <option value={v} key={v}>{l}</option>)}</select></label>;
}

export function PlacePicker({ query, setQuery, selected, setSelected, label = 'Birthplace' }: { query: string; setQuery: (s: string) => void; selected: Place | null; setSelected: (p: Place | null) => void; label?: string }) {
  const q = query.trim();
  const params = { q: q.length >= 2 ? q : '  ', limit: 6 };
  const result = useSearchPlaces(params, { query: { enabled: q.length >= 2 && !selected, queryKey: getSearchPlacesQueryKey(params) } });
  const list = result.data?.results || [];
  return <div className="relative min-w-0">
    <TextField label={label} value={selected?.label || query} onChange={v => { setQuery(v); setSelected(null); }} placeholder="Search city or place" required testId="input-place"/>
    {!selected && q.length >= 2 && <div className="absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-md border border-border bg-card p-1 shadow-xl">
      {result.isLoading ? <div className="p-3 text-xs text-muted-foreground">Looking up places…</div> : result.isError ? <div className="p-3 text-xs text-destructive">Place search unavailable. Retry in a moment.</div> : list.length ? list.map((place, i) => <button key={`${place.cc}-${place.lat}-${i}`} type="button" onClick={() => { setSelected(place); setQuery(place.label); }} className="grid min-h-11 w-full gap-0.5 rounded px-3 py-2 text-left hover:bg-primary/10" data-testid={`option-place-${i}`}><span className="text-sm font-semibold">{place.name}<span className="ml-2 text-xs font-normal text-muted-foreground">{[place.region, place.country].filter(Boolean).join(', ')}</span></span><span className="mono text-[10px] text-muted-foreground">{place.lat.toFixed(4)} · {place.lon.toFixed(4)} · {place.tz}</span></button>) : <div className="p-3 text-xs text-muted-foreground">No matching place found.</div>}
    </div>}
    {selected && <div className="mono mt-1 flex items-center gap-2 text-[10px] text-muted-foreground"><Check size={12} className="text-emerald-700"/> {selected.lat.toFixed(4)}, {selected.lon.toFixed(4)} · {selected.tz}</div>}
  </div>;
}
