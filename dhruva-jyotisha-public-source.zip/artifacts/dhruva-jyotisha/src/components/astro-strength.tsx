import { useState } from 'react';
import { SIGNS, SIGN_SHORT, fmtTime, fx, type Ashtakavarga, type Avasthas, type Strength } from '@/lib/astro';
import { RashiGrid, Section } from './astro-ui';

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function ShadbalaPanel({ s, tz }: { s: Strength; tz?: string }) {
  const max = Math.max(...s.planets.map(p => Math.max(p.total, p.required))) * 1.08;
  const t = s.time;
  return <Section eyebrow={`Shadbala / ${s.frame} frame`} title="Six-fold strength" note="Totals in virupas (60 = one rupa). The dark tick marks the classical minimum each graha requires.">
    <dl className="mb-5 flex flex-wrap gap-x-6 gap-y-2 border-y border-border py-3">
      {[['Sunrise', fmtTime(t.sunrise, tz)], ['Sunset', fmtTime(t.sunset, tz)], ['Weekday', `${WEEKDAYS[t.weekday]} · ${t.varaLord}`], ['Hora', `${t.horaNumber} · ${t.horaLord}`], ['Tribhaga', `${t.tribhagaPart} · ${t.tribhagaLord}`], ['Year lord', t.yearLord || '—'], ['Month lord', t.monthLord || '—'], ['Moon', `${s.waxing ? 'Waxing' : 'Waning'} · ${fx(s.elongation, 1)}°`]].map(([a, b]) => <div key={a}><dt className="mono text-[9px] uppercase tracking-widest text-muted-foreground">{a}</dt><dd className="mono m-0 text-xs">{b}</dd></div>)}
    </dl>
    {t.polar && <p className="mb-3 text-xs text-primary">Polar day or night at this latitude: day/night factors use the engine's fallback rule.</p>}
    <div className="grid gap-2.5" data-testid="chart-shadbala">{s.planets.map(p => <div key={p.id} className="grid grid-cols-[4.6rem_minmax(0,1fr)_5.6rem] items-center gap-2.5 sm:grid-cols-[5.6rem_minmax(0,1fr)_6.4rem]">
      <span className="display text-base">{p.id}</span>
      <div className="relative h-3.5 rounded-sm bg-[hsl(var(--track))]"><div className={`absolute inset-y-0 left-0 origin-left rounded-sm ${p.meets ? 'bg-emerald-700/80 dark:bg-emerald-400/70' : 'bg-muted-foreground/45'}`} style={{ width: `${(p.total / max) * 100}%` }}/><div className="absolute -inset-y-1 w-0.5 bg-foreground" style={{ left: `${(p.required / max) * 100}%` }}/></div>
      <span className="mono text-right text-xs">{fx(p.rupas, 2)} r<small className="block text-[10px] text-muted-foreground">{fx(p.ratio * 100, 0)}% · #{p.rank}</small></span>
    </div>)}</div>
    {s.war.length > 0 && <p className="mt-4 text-sm"><b>Graha yuddha:</b> {s.war.map(w => `${w.a}–${w.b} (${fx(w.separation, 2)}°)`).join('; ')}</p>}
    <details className="mt-5" open><summary className="cursor-pointer py-2 text-sm">Component breakdown</summary>
      <div className="table-wrap mt-2"><table className="data-table min-w-[860px] text-right"><thead><tr><th className="text-left">Graha</th><th>Uccha</th><th>Saptavarga</th><th>Ojha</th><th>Kendra</th><th>Drek.</th><th>Sthana</th><th>Dig</th><th>Kala</th><th>Cheshta</th><th>Naisarg.</th><th>Drik</th><th>Total</th><th>Req.</th><th>Ishta</th><th>Kashta</th></tr></thead><tbody>
        {s.planets.map(p => <tr key={p.id}><td className="text-left font-semibold">{p.id}</td>{[p.sthana.uccha, p.sthana.sapta, p.sthana.ojha, p.sthana.kendra, p.sthana.drekkana, p.sthana.total, p.dig, p.kala.total, p.cheshta, p.naisargika, p.drik].map((v, i) => <td key={i} className="num">{fx(v, 2)}</td>)}<td className="num font-semibold">{fx(p.total, 2)}</td><td className="num">{p.required}</td><td className="num">{fx(p.ishta, 2)}</td><td className="num">{fx(p.kashta, 2)}</td></tr>)}
      </tbody></table></div>
      <div className="table-wrap mt-3"><table className="data-table min-w-[700px] text-right"><thead><tr><th className="text-left">Kala bala</th><th>Nata</th><th>Paksha</th><th>Tribhaga</th><th>Abda</th><th>Masa</th><th>Vara</th><th>Hora</th><th>Ayana</th></tr></thead><tbody>
        {s.planets.map(p => <tr key={p.id}><td className="text-left font-semibold">{p.id}</td>{[p.kala.nata, p.kala.paksha, p.kala.tribhaga, p.kala.abda, p.kala.masa, p.kala.vara, p.kala.hora, p.kala.ayana].map((v, i) => <td key={i} className="num">{fx(v, 2)}</td>)}</tr>)}
      </tbody></table></div>
    </details>
  </Section>;
}

const STATES = ['lajjita', 'garvita', 'kshudhita', 'trishita', 'mudita', 'kshobhita'];
const gradeCls: Record<string, string> = { devastating: 'text-primary font-semibold', felt: 'text-primary', mild: 'text-muted-foreground' };
export function AvasthaPanel({ a }: { a: Avasthas }) {
  const [open, setOpen] = useState<string | null>(null);
  return <Section eyebrow={`Lajjitaadi avasthas / ${a.frame}`} title="States of the grahas" note="Each figure is the graha's own Shadbala less (Mudita: plus) the weighted influences, in virupas. Grade compares against its requirement.">
    <div className="table-wrap"><table className="data-table min-w-[820px]" data-testid="table-avasthas"><thead><tr><th>Graha</th><th>House</th><th>Shadbala</th>{STATES.map(s => <th key={s} className="capitalize">{s}</th>)}<th/></tr></thead><tbody>
      {a.planets.map(p => <tr key={p.id}><td className="font-semibold">{p.id}</td><td className="num">{p.house} · {SIGN_SHORT[p.sign]}</td><td className="num">{fx(p.shadbala, 1)}</td>
        {STATES.map(s => { const v = p.states[s]; if (!v) return <td key={s} className="num text-border">·</td>;
          const cls = s === 'mudita' ? 'text-emerald-700 dark:text-emerald-400' : s === 'garvita' ? 'text-accent' : gradeCls[v.grade || ''] || '';
          return <td key={s} className={`num ${cls}`}>{fx(v.value, 1)}<small className="block text-[9px] uppercase tracking-wider">{v.grade || v.reason || (v.gain != null ? `+${fx(v.gain, 1)}` : '')}</small></td>; })}
        <td><button onClick={() => setOpen(open === p.id ? null : p.id)} className="min-h-9 rounded border border-border px-2 text-xs hover:bg-muted" data-testid={`button-av-why-${p.id}`}>{open === p.id ? 'Hide' : 'Why'}</button></td></tr>)}
    </tbody></table></div>
    {open && (() => { const p = a.planets.find(x => x.id === open)!; return <div className="mt-4 border-l-2 border-primary pl-4"><div className="display text-lg">{p.id}: influences</div>{p.influences.length ? <ul className="mt-2 grid gap-1.5 text-sm">{p.influences.map((i, k) => <li key={k}><b className="capitalize">{i.state}</b> from {i.from} by {i.how} <span className="mono text-xs text-muted-foreground">{fx(i.value, 1)}/60 → {fx(i.amount, 2)} v</span></li>)}</ul> : <p className="text-sm text-muted-foreground">No influences recorded.</p>}{p.garvita && <p className="mt-2 text-xs text-muted-foreground">Garvita cushion of {fx(p.cushion, 1)} virupas applies to grading.</p>}</div>; })()}
    <details className="mt-5"><summary className="cursor-pointer py-2 text-sm">Drishti / yuti matrix (from row to column)</summary><div className="table-wrap mt-2"><table className="data-table min-w-[560px] text-center"><thead><tr><th/>{Object.keys(a.matrix).map(t => <th key={t}>{t.slice(0, 2)}</th>)}</tr></thead><tbody>
      {Object.keys(a.matrix).map(f => <tr key={f}><td className="text-left font-semibold">{f}</td>{Object.keys(a.matrix).map(t => { const e = a.matrix[f][t]; return <td key={t} className={`num ${!e ? 'text-border' : e.kind !== 'aspect' ? 'text-accent' : e.value ? '' : 'text-border'}`}>{!e ? '—' : e.kind === 'conj' ? 'cj' : e.kind === 'lord' ? 'lj' : fx(e.value, 1)}</td>; })}</tr>)}
    </tbody></table></div></details>
  </Section>;
}

const AV_ROWS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
export function AshtakavargaPanel({ av, lagna }: { av: Ashtakavarga; lagna: number }) {
  const [sel, setSel] = useState<number | null>(null);
  const heat: Record<number, React.ReactNode> = {};
  av.sav.forEach((v, s) => { heat[s] = v; });
  return <Section eyebrow={`Ashtakavarga / ${av.frame}`} title="Bindus by sign" note="Sarvashtakavarga totals in the chart; 28 is the average. Select a sign column to see which references contributed.">
    <div className="grid gap-6 lg:grid-cols-[minmax(0,400px)_minmax(0,1fr)]">
      <RashiGrid items={{}} lagna={lagna} title={`SAV ${av.sav.reduce((a, b) => a + b, 0)}`} sub="Sarvashtakavarga" heat={heat}/>
      <div className="min-w-0"><div className="table-wrap"><table className="data-table min-w-[640px] text-center" data-testid="table-ashtakavarga"><thead><tr><th className="text-left">BAV</th>{SIGN_SHORT.map((s, i) => <th key={s} className={sel === i ? 'bg-primary/10' : ''}><button className="min-h-8 px-1" onClick={() => setSel(sel === i ? null : i)}>{s}</button></th>)}<th>Σ</th></tr></thead><tbody>
        {AV_ROWS.map(p => <tr key={p}><td className="text-left font-semibold">{p}</td>{av.bav[p].map((v, i) => <td key={i} className={`num ${sel === i ? 'bg-primary/10' : ''} ${v >= 5 ? 'font-semibold text-emerald-700 dark:text-emerald-400' : v <= 2 ? 'text-primary' : ''}`}>{v}</td>)}<td className="num">{av.bav[p].reduce((a, b) => a + b, 0)}</td></tr>)}
        <tr className="border-t border-foreground/30"><td className="text-left font-semibold">SAV</td>{av.sav.map((v, i) => <td key={i} className={`num font-semibold ${sel === i ? 'bg-primary/10' : ''}`}>{v}</td>)}<td className="num">{av.sav.reduce((a, b) => a + b, 0)}</td></tr>
      </tbody></table></div>
      {sel != null && <div className="mt-4 text-sm"><div className="display text-lg">{SIGNS[sel]} — contributors</div><ul className="mt-2 grid gap-1">{AV_ROWS.map(p => <li key={p}><b>{p}:</b> <span className="text-muted-foreground">{av.contrib[p][sel].join(', ') || 'none'}</span></li>)}</ul></div>}
      </div>
    </div>
  </Section>;
}
