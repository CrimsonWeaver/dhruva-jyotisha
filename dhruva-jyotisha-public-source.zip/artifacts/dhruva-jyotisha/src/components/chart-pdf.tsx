import { renderToStaticMarkup } from 'react-dom/server';
import type { ChartInput } from '@workspace/api-client-react';
import type { Content, TDocumentDefinitions } from 'pdfmake/interfaces';
import { SIGNS, SKT, dms, fx, type Calc } from '@/lib/astro';
import { SOUTH_POS, type ChartStyle } from '@/lib/chart-layout';
import { NorthChartSvg } from './north-chart';
import { natalItems } from './astro-ui';
import devanagariUrl from '@/assets/fonts/NotoSansDevanagari-Regular.ttf?url';
import { canExportChart, chartPdfFilename } from '@/lib/chart-export-data';

function SouthChartSvg({ c }: { c: Calc }) {
  const items = natalItems(c);
  return <svg xmlns="http://www.w3.org/2000/svg" width="480" height="480" viewBox="0 0 480 480">
    <rect width="480" height="480" fill="#ffffff"/>
    {Object.entries(SOUTH_POS).map(([key, [col, row]]) => {
      const sign = Number(key), entries = items[sign] || [];
      const size = entries.length > 5 ? 9 : 12;
      return <g key={sign}>
        <rect x={col * 120} y={row * 120} width="120" height="120" fill={sign === c.chart.asc.sign ? '#f7eef1' : '#ffffff'} stroke="#8c8795"/>
        <text x={col * 120 + 6} y={row * 120 + 15} fontSize="10" fill="#762b46">{SIGNS[sign]}{sign === c.chart.asc.sign ? ' · Asc' : ''}</text>
        {entries.map((it, i) => <text key={it.key} x={col * 120 + 6} y={row * 120 + 29 + i * (size + 1)} fontSize={size} fill="#262233">{it.text}{it.sup || ''}</text>)}
      </g>;
    })}
    <text x="240" y="225" textAnchor="middle" fontSize="20" fill="#262233">Natal · D1</text>
    <text x="240" y="249" textAnchor="middle" fontSize="12" fill="#615b6b">{c.chart.zodiac} zodiac</text>
    <text x="240" y="271" textAnchor="middle" fontSize="10" fill="#615b6b">South Indian · fixed signs</text>
  </svg>;
}

// Split mixed-script labels into font runs: both fonts are embedded in the PDF.
function unicode(value: string): Content {
  return { text: value.split(/([\u0900-\u097f\uA8E0-\uA8FF]+)/u).filter(Boolean).map(text => ({ text, font: /[\u0900-\u097f\uA8E0-\uA8FF]/u.test(text) ? 'Devanagari' : 'Roboto' })) };
}
const heading = (text: string, pageBreak?: 'before'): Content => ({ text, headlineLevel: 1, pageBreak, fontSize: 16, bold: true, color: '#762b46', margin: [0, 12, 0, 10] });

export function chartReport(input: ChartInput, c: Calc, style: ChartStyle, meta?: { utcMs?: number; savedEngine?: string }): TDocumentDefinitions {
  if (!canExportChart(c)) throw new Error('A complete calculation is required before exporting.');
  const svg = renderToStaticMarkup(style === 'north' ? <NorthChartSvg items={natalItems(c)} lagna={c.chart.asc.sign} print/> : <SouthChartSvg c={c}/>);
  const rows = [{ id: 'Lagna', sign: c.chart.asc.sign, degInSign: c.chart.asc.degInSign, nak: c.chart.asc.nak, house: 1, retro: false, trop: c.chart.asc.trop }, ...c.chart.bodies];
  const settings = [
    ['Ephemeris engine', c.engineVersion], ['Positions supplied by', 'Swiss Ephemeris'],
    ['Zodiac / Shadbala frame', `${c.chart.zodiac} / ${input.sbFrame ?? c.chart.zodiac}`],
    ['Ayanamsa mode', `${c.chart.ayMode}${c.chart.ayStandard ? ' (standard Swiss definition)' : ''}`],
    ['Ayanamsa value', `${dms(c.chart.ayanamsa)} (${fx(c.chart.ayanamsa, 6)}°)`],
    ['Mean ayanamsa', c.chart.ayanamsaMean != null ? dms(c.chart.ayanamsaMean) : 'Not returned'],
    ['Lunar node', c.chart.nodeType], ['Dasa year length', `${input.dasaYear ?? 365.25} days`],
    ['House conventions', 'Campanus bhava cusps; whole-sign rasi houses. Diagram houses do not replace computed cusps.'],
    ['Universal time', new Date(meta?.utcMs ?? c.chart.ms).toISOString()],
    ['Chart layout', style === 'north' ? 'North Indian (fixed houses)' : 'South Indian (fixed signs)'],
    ...(meta?.savedEngine ? [['Saved chart engine', meta.savedEngine]] : []),
  ];
  return {
    pageSize: 'A4', pageMargins: [40, 42, 40, 45],
    info: { title: `${input.name} · Natal chart`, author: 'Dhruva Jyotisha', subject: 'Birth details, natal positions and calculation settings' },
    defaultStyle: { font: 'Roboto', fontSize: 10, color: '#262233', lineHeight: 1.2 },
    pageBreakBefore: (node, queries) => node.headlineLevel === 1 && queries.getFollowingNodesOnPage().length === 0,
    footer: (page, total) => ({ text: `Dhruva Jyotisha · Swiss Ephemeris   |   ${page} / ${total}`, alignment: 'center', fontSize: 8, color: '#615b6b', margin: [40, 12, 40, 0] }),
    content: [
      { text: 'DHRUVA JYOTISHA', fontSize: 10, color: '#762b46', characterSpacing: 2 },
      { ...unicode(input.name) as object, fontSize: 24, margin: [0, 10, 0, 12] } as Content,
      heading('Birth record'),
      { table: { widths: [115, '*'], body: [
        ['Local birth date / time', unicode(`${input.localDate} at ${input.localTime}`)],
        ['Birthplace', unicode(input.placeLabel)], ['Time zone (IANA)', unicode(input.tz)],
        ['Coordinates', `${input.lat.toFixed(5)}, ${input.lon.toFixed(5)}`],
        ['Universal time', new Date(c.chart.ms).toISOString()],
      ] }, layout: 'lightHorizontalLines', margin: [0, 0, 0, 12] },
      heading(`Natal chart · ${style === 'north' ? 'North Indian' : 'South Indian'}`),
      { svg, width: 365, alignment: 'center' },
      { text: style === 'north' ? 'Fixed houses, counterclockwise from Asc. Sign numbers: 1 Aries to 12 Pisces. Crowded signs are listed in full below.' : 'Fixed signs, Pisces at top left. Asc marks the ascendant sign.', fontSize: 9, margin: [0, 10, 0, 0] },
      heading('Planetary positions', 'before'),
      { text: `Longitudes in the ${c.chart.zodiac} zodiac; nakshatras always sidereal. R = retrograde.`, margin: [0, 0, 0, 8], fontSize: 9 },
      { table: { headerRows: 1, keepWithHeaderRows: 1, dontBreakRows: true, widths: [68, 58, 63, '*', 32, 35], body: [
        ['Graha', 'Sign', 'Longitude', 'Nakshatra / lord', 'Pada', 'House'].map(text => ({ text, bold: true, fillColor: '#f3f0f5', fontSize: 9 })),
        ...rows.map(b => [
          unicode(`${b.id}${b.retro ? ' R' : ''}${SKT[b.id] ? `\n${SKT[b.id]}` : ''}`), SIGNS[b.sign], dms(b.degInSign),
          unicode(`${b.nak.name}\n${b.nak.lord}`), String(b.nak.pada), String(b.house),
        ]),
      ] }, layout: 'lightHorizontalLines', fontSize: 9 },
      heading('Natal chart key · all annotations'),
      { text: SIGNS.map((sign, s) => `${s + 1} ${sign}: ${(natalItems(c)[s] || []).map(it => `${it.text}${it.sup || ''}`).join(', ') || '—'}`).join('\n'), fontSize: 9 },
      heading('Calculation settings & attribution', 'before'),
      { table: { widths: [130, '*'], headerRows: 1, keepWithHeaderRows: 1, dontBreakRows: true, body: [
        [{ text: 'Setting', bold: true }, { text: 'Value', bold: true }],
        ...settings.map(([label, value]) => [{ text: label, color: '#615b6b' }, unicode(value)]),
      ] }, layout: 'lightHorizontalLines' },
      { text: 'Generated locally in this browser from the returned calculation. No chart or PDF is saved to the server by downloading. Layout changes affect presentation only.', margin: [0, 16, 0, 0], fontSize: 9, color: '#615b6b' },
    ],
  };
}

type PdfBrowser = {
  addVirtualFileSystem: (vfs: Record<string, string>) => void;
  addFonts: (fonts: Record<string, Record<string, string>>) => void;
  createPdf: (definition: TDocumentDefinitions) => { getBlob: () => Promise<Blob> };
};
let ready: Promise<PdfBrowser> | undefined;
function pdfEngine() {
  if (!ready) ready = (async () => {
    const [engine, fonts, response] = await Promise.all([import('pdfmake/build/pdfmake'), import('pdfmake/build/vfs_fonts'), fetch(devanagariUrl)]);
    if (!response.ok) throw new Error('The PDF font could not be loaded. Please retry.');
    const bytes = new Uint8Array(await response.arrayBuffer());
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    const pdf = engine.default as unknown as PdfBrowser;
    pdf.addVirtualFileSystem({ ...fonts.default, 'NotoSansDevanagari-Regular.ttf': btoa(binary) });
    pdf.addFonts({ Devanagari: { normal: 'NotoSansDevanagari-Regular.ttf', bold: 'NotoSansDevanagari-Regular.ttf', italics: 'NotoSansDevanagari-Regular.ttf', bolditalics: 'NotoSansDevanagari-Regular.ttf' } });
    return pdf;
  })().catch(error => { ready = undefined; throw error; });
  return ready;
}

export async function createChartPdf(input: ChartInput, c: Calc, style: ChartStyle, meta?: { utcMs?: number; savedEngine?: string }) {
  const pdf = await pdfEngine();
  return pdf.createPdf(chartReport(input, c, style, meta)).getBlob();
}

export async function downloadChartPdf(input: ChartInput, c: Calc, style: ChartStyle, meta?: { utcMs?: number; savedEngine?: string }) {
  const blob = await createChartPdf(input, c, style, meta);
  if (!blob.size || blob.type !== 'application/pdf') throw new Error('The PDF could not be generated. Please retry.');
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = chartPdfFilename(input.name, style);
  document.body.append(anchor);
  try { anchor.click(); } finally { anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 60_000); }
}
