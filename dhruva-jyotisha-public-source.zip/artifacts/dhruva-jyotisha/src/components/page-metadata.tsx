import { useEffect } from 'react';
import { useLocation } from 'wouter';

export function PageMetadata() {
  const [location] = useLocation();
  useEffect(() => {
    const section = location.startsWith('/settings') ? 'Preferences'
      : location === '/charts' ? 'Saved charts'
      : location.startsWith('/shared/') ? 'Shared chart'
      : location.startsWith('/preview') ? 'Unsaved chart preview'
      : location.startsWith('/chart/') ? ({
        chart: 'Grahas, houses and vargas', strength: 'Strength and avasthas',
        dasa: 'Vimshottari periods', transits: 'Transit comparison',
        method: 'Calculation method',
      }[location.split('/')[3] ?? ''] ?? 'Chart overview')
      : 'Create a chart';
    // Page titles never expose chart names or birth details.
    document.title = `${section} — Dhruva Jyotisha`;
    document.querySelector('meta[name="description"]')?.setAttribute('content', `${section}. Inspectable Jyotisha calculations powered by Swiss Ephemeris.`);
    document.querySelector('meta[property="og:title"]')?.setAttribute('content', document.title);
    let robots = document.querySelector<HTMLMetaElement>('meta[name="robots"]');
    if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.appendChild(robots); }
    robots.content = location === '/' ? 'index, follow' : 'noindex, nofollow';
  }, [location]);
  return null;
}
