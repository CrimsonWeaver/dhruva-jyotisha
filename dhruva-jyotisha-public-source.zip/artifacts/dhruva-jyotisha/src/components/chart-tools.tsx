import { useState } from 'react';
import { FileDown } from 'lucide-react';
import type { ChartInput } from '@workspace/api-client-react';
import type { Calc } from '@/lib/astro';
import { ChartStyleToggle, useChartStyle } from '@/lib/chart-style';
import { canExportChart } from '@/lib/chart-export-data';

export function ChartTools({ input, c, disabled, meta }: { input: ChartInput; c: Calc | null; disabled: boolean; meta?: { utcMs?: number; savedEngine?: string } }) {
  const { style } = useChartStyle();
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ style: typeof style; message: string; failed: boolean } | null>(null);
  const unavailable = disabled || !canExportChart(c);
  const download = async () => {
    if (!c || unavailable || busy) return;
    setBusy(true); setFeedback({ style, failed: false, message: 'Preparing PDF in this browser…' });
    try {
      const { downloadChartPdf } = await import('./chart-pdf');
      await downloadChartPdf(input, c, style, meta);
      setFeedback({ style, failed: false, message: 'PDF ready. Your browser will download the file.' });
    } catch (error) {
      setFeedback({ style, failed: true, message: error instanceof Error ? `PDF export failed: ${error.message}` : 'PDF export failed. Please try again.' });
    } finally { setBusy(false); }
  };
  return <div className="surface mb-5 rounded-md p-3 sm:p-4">
    <div className="flex flex-wrap items-end justify-between gap-3"><ChartStyleToggle/>
      <div className="min-w-0"><button onClick={download} disabled={unavailable || busy} aria-busy={busy} aria-describedby="pdf-export-help" className="flex min-h-11 items-center gap-2 rounded border border-border px-3 text-xs hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-download-pdf"><FileDown size={15}/>{busy ? 'Preparing PDF…' : 'Download PDF'}</button>
        <p id="pdf-export-help" className="mt-1.5 max-w-xs text-[11px] text-muted-foreground">{unavailable ? 'Available after a successful calculation.' : 'Natal chart · selected layout · no sign-in needed'}</p>
      </div>
    </div>
    {feedback?.style === style && <p className={`mt-3 break-words text-xs ${feedback.failed ? 'text-destructive' : 'text-muted-foreground'}`} role={feedback.failed ? 'alert' : 'status'}>{feedback.message}</p>}
  </div>;
}
