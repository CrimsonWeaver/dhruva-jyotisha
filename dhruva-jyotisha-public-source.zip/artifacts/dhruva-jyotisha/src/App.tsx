import { useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import { useAuth } from '@workspace/replit-auth-web';
import { PageMetadata } from './components/page-metadata';
import { ArrowLeft, ArrowRight, CalendarDays, Compass, Copy, Eye, FileDown, Layers3, LogOut, Menu, Moon, Pencil, Plus, Search, Settings2, Share2, ShieldCheck, Sun, Trash2, X } from 'lucide-react';
import {
  getExportUserDataQueryKey, getGetChartQueryKey, getGetChartsSummaryQueryKey, getGetSettingsQueryKey, getGetSharedChartQueryKey, getListChartsQueryKey,
  useCreateChart, useCreateChartShareLink, useDeleteChart, useExportUserData, useGetChart, useGetChartsSummary, useGetSettings, useGetSharedChart,
  useListCharts, useRevokeChartShareLink, useUpdateChart, useUpdateSettings,
} from '@workspace/api-client-react';
import type { Chart, ChartInput, Place, UserSettings, UserSettingsInput } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import { PlacePicker, SelectField, TextField } from '@/components/place-picker';
import { ChartWorkspace, TabBar, resolveChartTab } from '@/components/chart-workspace';
import { birthInput, errorText } from '@/lib/use-calc';
import { ChartStyleProvider } from '@/lib/chart-style';

const client = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 20_000 } } });
type Settings = Pick<ChartInput, 'nodeType' | 'dasaYear' | 'ayanamsaMode' | 'sbFrame'>;
const setupDefaults: Required<Settings> = { nodeType: 'mean', dasaYear: 365.25, ayanamsaMode: 'equatorial', sbFrame: 'tropical' };
const PREVIEW_KEY = 'dhruva-preview-input';
const dateToday = () => new Date().toISOString().slice(0, 10);
const niceDate = (value: string) => new Date(value).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const AYANAMSAS: [string, string][] = [['lahiri', 'Lahiri'], ['dhruva', 'Dhruva (Galactic Center mid-Mula)'], ['equatorial', 'Dhruva equatorial (Kala)'], ['wilhelm', 'Wilhelm'], ['raman', 'Raman'], ['krishnamurti', 'Krishnamurti'], ['fagan', 'Fagan Bradley'], ['yukteshwar', 'Sri Yukteshwar'], ['ushashashi', 'Ushashashi']];
const NODES: [string, string][] = [['mean', 'Mean node'], ['true', 'True node'], ['interpolated', 'Interpolated node']];
const YEARS: [string, string][] = [['365.2425', '365.2425 days'], ['365.25', '365.25 days'], ['360', '360 days (savana)']];
const FRAMES: [string, string][] = [['sidereal', 'Sidereal'], ['tropical', 'Tropical']];

function readPreview(): ChartInput | null { try { const v = sessionStorage.getItem(PREVIEW_KEY); return v ? JSON.parse(v) as ChartInput : null; } catch { return null; } }

function Brand({ compact = false }: { compact?: boolean }) {
  return <Link href="/" className="flex items-center gap-3 text-foreground no-underline" data-testid="link-home">
    <div className="grid size-9 place-items-center rounded-full border border-primary/35 bg-primary/10 text-primary"><span className="deva text-xl leading-none">ध</span></div>
    {!compact && <div className="leading-tight"><div className="display text-[19px] font-semibold tracking-tight">Dhruva</div><div className="mono text-[9px] uppercase tracking-[.18em] text-muted-foreground">Jyotisha workbench</div></div>}
  </Link>;
}

function ThemeToggle() {
  const [dark, setDark] = useState(() => localStorage.getItem('dhruva-theme') === 'dark');
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('dhruva-theme', dark ? 'dark' : 'light'); }, [dark]);
  return <button className="grid size-9 place-items-center rounded-full border border-border text-muted-foreground hover:bg-muted" onClick={() => setDark(!dark)} aria-label="Toggle color theme" data-testid="button-theme">{dark ? <Sun size={16}/> : <Moon size={16}/>}</button>;
}

/* Clears every cached user query when the signed-in identity changes. */
function AuthCacheGuard() {
  const { user, isLoading } = useAuth(); const qc = useQueryClient(); const prev = useRef<string | null | undefined>(undefined);
  useEffect(() => { if (isLoading) return; const id = user?.id ?? null; if (prev.current !== undefined && prev.current !== id) qc.clear(); prev.current = id; }, [user?.id, isLoading, qc]);
  return null;
}

function Footer() {
  return <footer className="mt-14 flex flex-wrap gap-x-5 gap-y-2 border-t border-border pt-5 text-[11px] leading-5 text-muted-foreground" data-testid="footer">
    <span>Dhruva Jyotisha is free software under the <a className="text-foreground underline underline-offset-2" href="https://www.gnu.org/licenses/agpl-3.0.html" target="_blank" rel="noreferrer">GNU AGPL-3.0-or-later</a>. <a className="text-foreground underline underline-offset-2" href="/api/source" data-testid="link-source">Source code</a>.</span>
    <span>Place data from <a className="text-foreground underline underline-offset-2" href="https://www.geonames.org/" target="_blank" rel="noreferrer">GeoNames</a>, licensed <a className="text-foreground underline underline-offset-2" href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0</a>.</span>
    <span>Positions from the Swiss Ephemeris.</span>
  </footer>;
}

function Frame({ children, shared = false }: { children: React.ReactNode; shared?: boolean }) {
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();
  const [menu, setMenu] = useState(false);
  const [location] = useLocation();
  useEffect(() => setMenu(false), [location]);
  const active = location.startsWith('/charts') || location.startsWith('/chart/') ? 'charts' : location.startsWith('/settings') ? 'settings' : location.startsWith('/preview') ? 'preview' : 'new';
  if (isLoading) return <div className="grid min-h-[100dvh] place-items-center"><div className="w-[min(420px,88vw)] space-y-3"><div className="h-7 w-44 animate-pulse rounded bg-muted"/><div className="h-3 w-full animate-pulse rounded bg-muted"/><div className="h-3 w-2/3 animate-pulse rounded bg-muted"/></div></div>;
  const nav = <><NavItem href="/" active={active === 'new'} icon={<Plus size={16}/>} label="Create a chart"/><NavItem href="/preview" active={active === 'preview'} icon={<Eye size={16}/>} label="Unsaved preview"/><NavItem href="/charts" active={active === 'charts'} icon={<Layers3 size={16}/>} label="Saved charts"/></>;
  return <div className="app-shell flex bg-background"><PageMetadata/>
    <aside className="desktop-sidebar side-nav sticky top-0 hidden h-[100dvh] flex-col border-r border-border bg-card/70 px-4 py-5 md:flex">
      <Brand/>
      <div className="mono mb-3 mt-10 px-3 text-[9px] uppercase tracking-[.18em] text-muted-foreground">Workbench</div>
      <nav className="grid gap-1">{nav}</nav>
      <div className="mono mb-3 mt-9 px-3 text-[9px] uppercase tracking-[.18em] text-muted-foreground">Account</div>
      <NavItem href="/settings" active={active === 'settings'} icon={<Settings2 size={16}/>} label="Preferences"/>
      <div className="mt-auto border-t border-border pt-4">
        <div className="mb-4 flex items-center gap-3 px-2"><div className="mono grid size-8 place-items-center rounded-full bg-secondary text-xs text-primary">{(user?.firstName || user?.email || 'G').slice(0, 1).toUpperCase()}</div><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold" data-testid="text-user">{isAuthenticated ? user?.firstName || user?.email || 'Practitioner' : 'Guest session'}</div><div className="mono text-[9px] uppercase tracking-wider text-muted-foreground">{isAuthenticated ? 'Private workspace' : 'Calculate freely · log in to save'}</div></div></div>
        {isAuthenticated ? <button className="flex min-h-9 w-full items-center gap-2 rounded-md px-3 text-left text-xs text-muted-foreground hover:bg-muted" onClick={logout} data-testid="button-logout"><LogOut size={14}/> Log out</button> : <button className="min-h-9 w-full rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground hover:opacity-90" onClick={login} data-testid="button-login-side">Log in to workspace</button>}
      </div>
    </aside>
    <div className="main-pane">
      <header className="sticky top-0 z-30 flex h-[62px] items-center justify-between border-b border-border bg-background/90 px-4 backdrop-blur-md sm:px-7">
        <div className="flex items-center gap-3 md:hidden"><button onClick={() => setMenu(!menu)} aria-label="Open navigation" aria-expanded={menu} className="grid size-9 place-items-center rounded-full border border-border" data-testid="button-menu">{menu ? <X size={17}/> : <Menu size={17}/>}</button><Brand compact/><span className="display text-lg max-[360px]:hidden">Dhruva</span></div>
        <div className="hidden items-center gap-2 text-xs text-muted-foreground md:flex"><span className="size-1.5 rounded-full bg-emerald-600"/>{shared ? 'Shared chart · read only' : 'Swiss Ephemeris · calculation integrity mode'}</div>
        <div className="ml-auto flex items-center gap-2"><ThemeToggle/>{!isAuthenticated && !shared && <button className="min-h-9 rounded-full px-3 text-xs font-semibold text-primary hover:bg-primary/10 md:hidden" onClick={login}>Log in</button>}{isAuthenticated && <button className="grid size-9 place-items-center rounded-full border border-border text-muted-foreground md:hidden" onClick={logout} aria-label="Log out"><LogOut size={15}/></button>}</div>
      </header>
      {menu && <div className="fixed inset-x-0 top-[62px] z-40 grid gap-1 border-b border-border bg-card p-3 shadow-lg md:hidden">{nav}<NavItem href="/settings" active={active === 'settings'} icon={<Settings2 size={16}/>} label="Preferences"/></div>}
      <main className="mx-auto max-w-[1440px] px-4 pb-10 pt-7 sm:px-7 lg:px-10">{children}<Footer/></main>
    </div>
  </div>;
}

function NavItem({ href, active, icon, label }: { href: string; active: boolean; icon: React.ReactNode; label: string }) {
  return <Link href={href} className={`flex min-h-10 items-center gap-3 rounded-md px-3 text-sm no-underline transition-colors ${active ? 'bg-primary/10 font-semibold text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} data-testid={`nav-${label.toLowerCase().replaceAll(' ', '-')}`}>{icon}{label}</Link>;
}

function SignedOut({ login, context = 'save and revisit your chart work' }: { login: () => void; context?: string }) {
  return <div className="surface mx-auto my-6 max-w-xl overflow-hidden rounded-lg">
    <div className="subtle-grid border-b border-border p-8 sm:p-10"><div className="mono text-[10px] uppercase tracking-[.2em] text-primary">Private workspace</div><h2 className="display mt-3 text-3xl">Keep your work<br/>close at hand.</h2><p className="mt-3 max-w-md text-sm leading-6 text-muted-foreground">Log in to {context}. Your birth data remains in your private chart library.</p></div>
    <div className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-2 text-xs text-muted-foreground"><ShieldCheck size={16} className="text-primary"/> Secure sign-in only.</div><button onClick={login} className="min-h-10 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground hover:opacity-90" data-testid="button-login">Log in</button></div>
  </div>;
}

function PageHeading({ eyebrow, title, detail, actions }: { eyebrow: string; title: string; detail?: string; actions?: React.ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div className="min-w-0"><div className="mono mb-2 text-[10px] uppercase tracking-[.2em] text-primary">{eyebrow}</div><h1 className="display text-4xl font-medium tracking-tight sm:text-[46px]">{title}</h1>{detail && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{detail}</p>}</div>{actions}</div>;
}

function useDefaults(): { defaults: Required<Settings>; prefs?: UserSettings } {
  const { isAuthenticated } = useAuth();
  const s = useGetSettings({ query: { enabled: isAuthenticated, queryKey: getGetSettingsQueryKey() } });
  const p = isAuthenticated ? s.data : undefined;
  return { defaults: p ? { nodeType: p.nodeType, dasaYear: p.dasaYear, ayanamsaMode: p.ayanamsaMode, sbFrame: p.sbFrame } : setupDefaults, prefs: p };
}

/* Birth record form used for create, preview, edit and duplicate. */
function BirthForm({ initial, defaults, submitLabel, busy, onSubmit, secondary, error }: { initial?: ChartInput; defaults: Required<Settings>; submitLabel: string; busy?: boolean; onSubmit: (input: ChartInput) => void; secondary?: { label: string; onClick: (input: ChartInput) => void }; error?: string }) {
  const [name, setName] = useState(initial?.name || '');
  const [date, setDate] = useState(initial?.localDate || dateToday());
  const [time, setTime] = useState(initial?.localTime || '12:00');
  const initialPlace: Place | null = initial ? { name: initial.placeLabel, region: '', country: '', cc: '', lat: initial.lat, lon: initial.lon, tz: initial.tz, population: 0, label: initial.placeLabel } : null;
  const [placeQuery, setPlaceQuery] = useState(initial?.placeLabel || '');
  const [place, setPlace] = useState<Place | null>(initialPlace);
  const [locationOverride, setLocationOverride] = useState<{ lat: string; lon: string; tz: string } | null>(null);
  const locationFields = locationOverride ?? { lat: place ? String(place.lat) : '', lon: place ? String(place.lon) : '', tz: place?.tz ?? '' };
  const [st, setSt] = useState<Required<Settings>>({ nodeType: initial?.nodeType ?? defaults.nodeType, dasaYear: initial?.dasaYear ?? defaults.dasaYear, ayanamsaMode: initial?.ayanamsaMode ?? defaults.ayanamsaMode, sbFrame: initial?.sbFrame ?? defaults.sbFrame });
  const touched = useRef(!!initial);
  useEffect(() => { if (!touched.current) setSt(defaults); }, [defaults.nodeType, defaults.dasaYear, defaults.ayanamsaMode, defaults.sbFrame]); // eslint-disable-line react-hooks/exhaustive-deps
  const setS = (patch: Partial<Settings>) => { touched.current = true; setSt(p => ({ ...p, ...patch })); };
  const [local, setLocal] = useState('');
  const build = (): ChartInput | null => {
    setLocal('');
    if (!name.trim()) { setLocal('Give the chart a name or reference.'); return null; }
    if (!place) { setLocal('Choose a birthplace from the location results before continuing.'); return null; }
    const lat = Number(locationFields.lat), lon = Number(locationFields.lon);
    if (!locationFields.lat.trim() || !locationFields.lon.trim() || !Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 89 || Math.abs(lon) > 180) { setLocal('Enter a latitude between −89 and 89 and longitude between −180 and 180.'); return null; }
    try { new Intl.DateTimeFormat(undefined, { timeZone: locationFields.tz }); } catch { setLocal('Enter a valid IANA time zone, such as Europe/London.'); return null; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) { setLocal('Enter a complete date and time.'); return null; }
    return { name: name.trim(), placeLabel: place.label, lat, lon, tz: locationFields.tz, localDate: date, localTime: time.slice(0, 5), ...st, zodiac: st.sbFrame };
  };
  return <form onSubmit={e => { e.preventDefault(); const i = build(); if (i) onSubmit(i); }} className="grid gap-6">
    <TextField label="Chart name" value={name} onChange={setName} placeholder="Name or reference" required testId="input-chart-name"/>
    <PlacePicker query={placeQuery} setQuery={setPlaceQuery} selected={place} setSelected={p => { setPlace(p); setLocationOverride(null); }}/>
    {place && <details className="rounded border border-border px-3 py-2 text-sm">
      <summary className="min-h-9 cursor-pointer pt-2 text-muted-foreground">Inspect or correct coordinates and time zone</summary>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <TextField label="Latitude" value={locationFields.lat} onChange={v => setLocationOverride({ ...locationFields, lat: v })} testId="input-birth-lat"/>
        <TextField label="Longitude" value={locationFields.lon} onChange={v => setLocationOverride({ ...locationFields, lon: v })} testId="input-birth-lon"/>
        <div className="sm:col-span-2"><TextField label="IANA time zone" value={locationFields.tz} onChange={v => setLocationOverride({ ...locationFields, tz: v })} testId="input-birth-tz"/></div>
      </div>
    </details>}
    <div className="grid gap-4 sm:grid-cols-2"><TextField label="Local birth date" type="date" value={date} onChange={setDate} required testId="input-birth-date"/><TextField label="Local birth time" type="time" value={time} onChange={setTime} required testId="input-birth-time"/></div>
    <details open className="border-t border-border pt-3"><summary className="mono min-h-9 cursor-pointer pt-2 text-[9px] uppercase tracking-[.16em] text-muted-foreground">Calculation settings</summary><fieldset className="grid gap-4 pt-4 sm:grid-cols-2">
      <SelectField label="Ayanamsa" value={st.ayanamsaMode} onChange={v => setS({ ayanamsaMode: v as Settings['ayanamsaMode'] })} options={AYANAMSAS} testId="select-ayanamsa"/>
      <SelectField label="Zodiac / Shadbala frame" value={st.sbFrame} onChange={v => setS({ sbFrame: v as Settings['sbFrame'] })} options={FRAMES} testId="select-sbframe"/>
      <SelectField label="Lunar node" value={st.nodeType} onChange={v => setS({ nodeType: v as Settings['nodeType'] })} options={NODES} testId="select-node"/>
      <SelectField label="Dasa year" value={String(st.dasaYear)} onChange={v => setS({ dasaYear: Number(v) as Settings['dasaYear'] })} options={YEARS} testId="select-dasa-year"/>
    </fieldset></details>
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5"><div className="max-w-xs text-xs text-muted-foreground">Date and time are read in the birthplace's time zone.</div>
      <div className="flex flex-wrap gap-2">{secondary && <button type="button" onClick={() => { const i = build(); if (i) secondary.onClick(i); }} className="flex min-h-10 items-center gap-2 rounded border border-border px-4 text-sm hover:bg-muted" data-testid="button-preview-chart"><Eye size={15}/>{secondary.label}</button>}
        <button disabled={busy} className="flex min-h-10 items-center gap-2 rounded bg-primary px-5 text-sm font-semibold text-primary-foreground disabled:opacity-50" data-testid="button-submit-birth">{busy ? 'Working…' : submitLabel}<ArrowRight size={15}/></button></div></div>
    {(local || error) && <p className="m-0 text-sm text-destructive" role="alert">{local || error}</p>}
  </form>;
}

function CreatePage() {
  const { isAuthenticated, login } = useAuth();
  const { defaults } = useDefaults();
  const [, navigate] = useLocation();
  const [error, setError] = useState('');
  const create = useCreateChart(); const qc = useQueryClient();
  const preview = (input: ChartInput) => { sessionStorage.setItem(PREVIEW_KEY, JSON.stringify(input)); navigate('/preview'); };
  const save = (input: ChartInput) => {
    if (!isAuthenticated) { preview(input); return; }
    setError('');
    create.mutate({ data: input }, { onSuccess: chart => { qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); qc.invalidateQueries({ queryKey: getGetChartsSummaryQueryKey() }); navigate(`/chart/${chart.id}`); }, onError: e => setError(errorText(e, 'The chart could not be saved. Check the details and try again.')) });
  };
  return <><PageHeading eyebrow="Chart intake / 01" title="Create a chart" detail="Record the birth data precisely. Anyone can calculate and download a PDF; logging in lets you save and share charts."/>
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(280px,.8fr)]">
      <section className="surface rounded-md p-5 sm:p-7"><div className="mb-6 flex items-start justify-between border-b border-border pb-4"><div><div className="mono text-[9px] uppercase tracking-[.16em] text-muted-foreground">01 — Identity</div><h2 className="display mt-1 text-2xl">Birth record</h2></div><CalendarDays size={18} className="text-primary"/></div>
        <BirthForm defaults={defaults} submitLabel={isAuthenticated ? 'Save & calculate' : 'Calculate'} busy={create.isPending} onSubmit={save} secondary={isAuthenticated ? { label: 'Preview only', onClick: preview } : undefined} error={error}/></section>
      <div className="grid content-start gap-5">
        <section className="surface rounded-md p-5"><div className="flex items-center gap-2 text-primary"><Compass size={16}/><span className="mono text-[10px] uppercase tracking-[.16em]">Calculation protocol</span></div><h2 className="display mt-3 text-2xl">Swiss Ephemeris, stated plainly.</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">The ayanamsa, frame, node model and year length you choose are sent with every calculation and shown on the Method panel. The Shadbala frame also decides the zodiac signs are read in.</p></section>
        {!isAuthenticated && <section className="surface subtle-grid rounded-md p-5"><div className="mono text-[10px] uppercase tracking-[.16em] text-primary">Guest mode</div><p className="mt-2 text-sm leading-6 text-muted-foreground">Guest calculations stay in this browser tab only. Download your chart as a PDF without an account, or log in to keep a library and share read-only links.</p><button onClick={login} className="mt-3 min-h-9 rounded border border-border px-3 text-xs hover:bg-muted">Log in</button></section>}
      </div>
    </div></>;
}

function ChartHeader({ eyebrow, input, back, actions }: { eyebrow: string; input: ChartInput; back: { href: string; label: string }; actions?: React.ReactNode }) {
  return <div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div className="min-w-0 max-w-full"><Link href={back.href} className="mb-3 inline-flex min-h-9 items-center gap-1 text-xs text-muted-foreground no-underline hover:text-primary"><ArrowLeft size={13}/>{back.label}</Link><div className="mono text-[9px] uppercase tracking-[.18em] text-primary">{eyebrow}</div><h1 className="display mt-1 truncate text-4xl sm:text-[44px]" data-testid="text-chart-name">{input.name}</h1><p className="mt-1 text-sm text-muted-foreground">{input.placeLabel} <span className="mx-1 text-border">/</span> {input.localDate} at {input.localTime} <span className="mono ml-1 text-[10px]">· {input.ayanamsaMode} · {input.sbFrame}</span></p></div>{actions}</div>;
}

function PreviewPage() {
  const { isAuthenticated, login } = useAuth();
  const { defaults, prefs } = useDefaults();
  const [input, setInput] = useState<ChartInput | null>(readPreview);
  const [tab, setTab] = useState('overview'); const [editing, setEditing] = useState(false);
  const create = useCreateChart(); const qc = useQueryClient(); const [, navigate] = useLocation(); const [err, setErr] = useState('');
  if (!input) return <><PageHeading eyebrow="Preview" title="Nothing to preview"/><div className="surface subtle-grid rounded-md p-8 sm:p-12"><h2 className="display text-3xl">Enter a birth record first.</h2><p className="mt-2 max-w-lg text-sm text-muted-foreground">Previews live only in this browser tab and are never stored on the server.</p><Link href="/" className="mt-6 inline-flex min-h-10 items-center gap-2 rounded bg-primary px-4 text-sm font-semibold text-primary-foreground no-underline"><Plus size={15}/> Create chart</Link></div></>;
  const update = (i: ChartInput) => { sessionStorage.setItem(PREVIEW_KEY, JSON.stringify(i)); setInput(i); setEditing(false); };
  const save = () => create.mutate({ data: input }, { onSuccess: c => { sessionStorage.removeItem(PREVIEW_KEY); qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); navigate(`/chart/${c.id}`); }, onError: e => setErr(errorText(e, 'Could not save this chart.')) });
  return <div className="animate-in">
    <ChartHeader eyebrow="Unsaved preview · this tab only" input={input} back={{ href: '/', label: 'New chart' }} actions={<div className="flex flex-wrap gap-2">
      <button onClick={() => setEditing(true)} className="flex min-h-9 items-center gap-2 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-edit-preview"><Pencil size={14}/> Edit inputs</button>
      {isAuthenticated ? <button onClick={save} disabled={create.isPending} className="flex min-h-9 items-center gap-2 rounded bg-primary px-3 text-xs font-semibold text-primary-foreground" data-testid="button-save-preview">{create.isPending ? 'Saving…' : 'Save to library'}</button> : <button onClick={login} className="min-h-9 rounded bg-primary px-3 text-xs font-semibold text-primary-foreground">Log in to save</button>}
      <button onClick={() => { sessionStorage.removeItem(PREVIEW_KEY); setInput(null); }} className="min-h-9 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-clear-preview">Discard</button></div>}/>
    {err && <p className="mb-3 text-sm text-destructive" role="alert">{err}</p>}
    <TabBar tab={tab} onTab={setTab}/>
    <ChartWorkspace input={input} tab={tab} transitPlace={hereOf(prefs)}/>
    {editing && <Modal title="Edit birth inputs" onClose={() => setEditing(false)}><BirthForm initial={input} defaults={defaults} submitLabel="Recalculate" onSubmit={update}/></Modal>}
  </div>;
}

const hereOf = (p?: UserSettings) => p && p.hereLat != null && p.hereLon != null ? { label: p.hereLabel || 'Saved location', lat: p.hereLat, lon: p.hereLon } : null;

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  return <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-foreground/30 p-3 sm:p-6" role="dialog" aria-modal="true" aria-label={title} onClick={e => e.target === e.currentTarget && onClose()}>
    <div className="surface animate-in my-auto w-full max-w-2xl rounded-md p-5 sm:p-7"><div className="mb-5 flex items-center justify-between gap-3"><h2 className="display text-2xl">{title}</h2><button onClick={onClose} aria-label="Close" className="grid size-9 place-items-center rounded-full hover:bg-muted"><X size={17}/></button></div>{children}</div>
  </div>;
}

function SkeletonList() { return <div className="surface space-y-3 rounded-md p-5">{[1, 2, 3, 4].map(n => <div key={n} className="h-12 animate-pulse rounded bg-muted"/>)}</div>; }
function ErrorPanel({ title, onRetry, detail }: { title: string; onRetry: () => void; detail?: string }) { return <div className="surface rounded-md p-7" role="alert"><div className="text-sm font-semibold">{title}</div><p className="text-sm text-muted-foreground">{detail || 'The request did not complete. Your work has not been changed.'}</p><button onClick={onRetry} className="mt-2 min-h-9 rounded border border-border px-3 text-xs hover:bg-muted">Try again</button></div>; }

function ChartsPage() {
  const { isAuthenticated, login } = useAuth();
  const [search, setSearch] = useState('');
  const params = { q: search.trim() || undefined };
  const charts = useListCharts(params, { query: { enabled: isAuthenticated, queryKey: getListChartsQueryKey(params) } });
  const summary = useGetChartsSummary({ query: { enabled: isAuthenticated, queryKey: getGetChartsSummaryQueryKey() } });
  const del = useDeleteChart(); const qc = useQueryClient();
  if (!isAuthenticated) return <><PageHeading eyebrow="Library / 02" title="Saved charts" detail="A private index of birth records and their calculation methods."/><SignedOut login={login} context="search, manage, and revisit saved charts"/></>;
  const rows = charts.data || [];
  return <><PageHeading eyebrow="Library / 02" title="Saved charts" detail="A private index of birth records and their calculation methods." actions={<Link href="/" className="flex min-h-10 items-center gap-2 rounded bg-primary px-4 text-sm font-semibold text-primary-foreground no-underline"><Plus size={15}/> New chart</Link>}/>
    <div className="mb-5 flex flex-wrap items-center gap-3"><div className="relative min-w-0 flex-1 sm:max-w-md"><Search size={15} className="absolute left-3 top-3 text-muted-foreground"/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name or birthplace" className="field-input w-full pl-9" data-testid="input-chart-search"/></div><div className="mono text-[10px] uppercase tracking-widest text-muted-foreground">{summary.data?.chartCount ?? '—'} records</div></div>
    {charts.isLoading ? <SkeletonList/> : charts.isError ? <ErrorPanel title="Chart library unavailable" onRetry={() => charts.refetch()}/> : rows.length === 0 ? <EmptyLibrary query={search}/> : <div className="surface overflow-hidden rounded-md">
      <div className="mono grid grid-cols-[minmax(0,1fr)_minmax(120px,.6fr)_130px_40px] gap-3 border-b border-border bg-muted/50 px-4 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground max-sm:grid-cols-[minmax(0,1fr)_40px]"><span>Chart / place</span><span className="max-sm:hidden">Birth date</span><span className="max-sm:hidden">Updated</span><span/></div>
      {rows.map(chart => <div key={chart.id} className="grid grid-cols-[minmax(0,1fr)_minmax(120px,.6fr)_130px_40px] items-center gap-3 border-b border-border/70 px-4 py-2 last:border-0 max-sm:grid-cols-[minmax(0,1fr)_40px]" data-testid={`row-chart-${chart.id}`}>
        <Link href={`/chart/${chart.id}`} className="min-w-0 py-1 no-underline hover:text-primary"><span className="block truncate text-sm font-semibold">{chart.name}</span><span className="mt-0.5 block truncate text-xs text-muted-foreground">{chart.placeLabel}<span className="sm:hidden"> · {chart.localDate}</span></span></Link>
        <span className="mono text-xs max-sm:hidden">{chart.localDate} · {chart.localTime}</span><span className="mono text-[10px] text-muted-foreground max-sm:hidden">{niceDate(chart.updatedAt)}</span>
        <button title="Delete chart" aria-label={`Delete ${chart.name}`} className="grid size-10 place-items-center rounded text-muted-foreground hover:bg-destructive/10 hover:text-destructive" disabled={del.isPending} onClick={() => { if (confirm(`Delete "${chart.name}" and all its associated records?`)) del.mutate({ id: chart.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); qc.invalidateQueries({ queryKey: getGetChartsSummaryQueryKey() }); } }); }} data-testid={`button-delete-${chart.id}`}><Trash2 size={15}/></button>
      </div>)}
    </div>}
  </>;
}
function EmptyLibrary({ query }: { query: string }) { return <div className="surface subtle-grid rounded-md p-8 sm:p-12"><div className="mono text-[10px] uppercase tracking-[.18em] text-primary">{query ? 'No matches' : 'First record'}</div><h2 className="display mt-2 text-3xl">{query ? 'No chart found.' : 'A careful record starts here.'}</h2><p className="mt-2 max-w-lg text-sm text-muted-foreground">{query ? 'Try another name or birthplace.' : 'Create a birth record to begin a private, inspectable chart archive.'}</p>{!query && <Link href="/" className="mt-6 inline-flex min-h-10 items-center gap-2 rounded bg-primary px-4 text-sm font-semibold text-primary-foreground no-underline"><Plus size={15}/> Create chart</Link>}</div>; }

const toInput = (c: Chart): ChartInput => birthInput(c);

function OwnedChartRoute() {
  const params = useParams<{ id: string; tab?: string }>();
  const { isAuthenticated, login } = useAuth();
  const { prefs } = useDefaults();
  const id = params.id; const tab = resolveChartTab(params.tab);
  const owned = useGetChart(id, { query: { enabled: isAuthenticated && !!id, queryKey: getGetChartQueryKey(id) } });
  if (!isAuthenticated) return <SignedOut login={login} context="open this saved chart"/>;
  if (owned.isLoading) return <SkeletonList/>;
  if (owned.isError || !owned.data) return <ErrorPanel title="Chart could not be opened" detail="It may have been deleted, or belongs to another account." onRetry={() => owned.refetch()}/>;
  const chart = owned.data; const input = toInput(chart);
  return <div className="animate-in">
    <ChartHeader eyebrow={`Birth record · ${chart.engineVersion}`} input={input} back={{ href: '/charts', label: 'Chart library' }} actions={<ChartActions chart={chart}/>}/>
    <TabBar tab={tab} hrefFor={k => k === 'overview' ? `/chart/${id}` : `/chart/${id}/${k}`}/>
    <ChartWorkspace key={chart.updatedAt} input={input} tab={tab} transitPlace={hereOf(prefs)} meta={{ utcMs: chart.utcMs, savedEngine: chart.engineVersion }}/>
  </div>;
}

function SharedChartRoute() {
  const { token } = useParams<{ token: string }>();
  const [tab, setTab] = useState('overview');
  const share = useGetSharedChart(token, { query: { enabled: !!token, queryKey: getGetSharedChartQueryKey(token), retry: false } });
  if (share.isLoading) return <SkeletonList/>;
  if (share.isError || !share.data) return <ErrorPanel title="This share link is unavailable" detail="The link may have been revoked by its owner." onRetry={() => share.refetch()}/>;
  const chart = share.data.chart; const input = toInput(chart);
  return <div className="animate-in">
    <ChartHeader eyebrow="Read-only share" input={input} back={{ href: '/', label: 'Dhruva workbench' }}/>
    <TabBar tab={tab} onTab={setTab}/>
    <ChartWorkspace input={input} tab={tab} meta={{ utcMs: chart.utcMs, savedEngine: chart.engineVersion }}/>
  </div>;
}

function ChartActions({ chart }: { chart: Chart }) {
  const [shareLink, setShareLink] = useState(''); const [copied, setCopied] = useState(false);
  const [mode, setMode] = useState<'edit' | 'duplicate' | null>(null); const [err, setErr] = useState('');
  const create = useCreateChartShareLink(); const revoke = useRevokeChartShareLink(); const update = useUpdateChart(); const dup = useCreateChart(); const del = useDeleteChart();
  const qc = useQueryClient(); const [, navigate] = useLocation();
  const { defaults } = useDefaults();
  const copy = (url: string) => navigator.clipboard?.writeText(url).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800); }).catch(() => setCopied(false));
  const btn = 'flex min-h-9 items-center gap-2 rounded border border-border px-3 text-xs hover:bg-muted';
  return <div className="flex flex-wrap items-center gap-2">
    <button onClick={() => { setErr(''); setMode('edit'); }} className={btn} data-testid="button-edit-chart"><Pencil size={14}/> Edit birth</button>
    <button onClick={() => { setErr(''); setMode('duplicate'); }} className={btn} data-testid="button-duplicate-chart"><Copy size={14}/> Duplicate</button>
    <button onClick={() => create.mutate({ id: chart.id }, { onSuccess: res => { const abs = new URL(res.url, window.location.origin).toString(); setShareLink(abs); copy(abs); }, onError: e => setErr(errorText(e, 'Share link could not be created.')) })} disabled={create.isPending} className={btn} data-testid="button-share"><Share2 size={14}/>{create.isPending ? 'Creating…' : 'Share'}</button>
    <button onClick={() => { if (confirm(`Delete "${chart.name}" and all its associated records?`)) del.mutate({ id: chart.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); qc.invalidateQueries({ queryKey: getGetChartsSummaryQueryKey() }); navigate('/charts'); } }); }} className={`${btn} hover:text-destructive`} aria-label="Delete chart" data-testid="button-delete-chart"><Trash2 size={14}/></button>
    {err && !mode && <span className="w-full text-xs text-destructive" role="alert">{err}</span>}
    {mode && <Modal title={mode === 'edit' ? 'Edit birth inputs' : 'Duplicate as a new chart'} onClose={() => setMode(null)}>
      <BirthForm initial={{ ...toInput(chart), name: mode === 'duplicate' ? `${chart.name} (copy)` : chart.name }} defaults={defaults} submitLabel={mode === 'edit' ? 'Save & recalculate' : 'Create copy'} busy={update.isPending || dup.isPending} error={err}
        onSubmit={input => mode === 'edit'
          ? update.mutate({ id: chart.id, data: input }, { onSuccess: c => { qc.setQueryData(getGetChartQueryKey(chart.id), c); qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); setMode(null); }, onError: e => setErr(errorText(e, 'Changes could not be saved.')) })
          : dup.mutate({ data: input }, { onSuccess: c => { qc.invalidateQueries({ queryKey: getListChartsQueryKey() }); qc.invalidateQueries({ queryKey: getGetChartsSummaryQueryKey() }); setMode(null); navigate(`/chart/${c.id}`); }, onError: e => setErr(errorText(e, 'Copy could not be created.')) })}/>
    </Modal>}
    {shareLink && <Modal title="Read-only link" onClose={() => setShareLink('')}><p className="text-sm text-muted-foreground">Anyone with this link can inspect the chart's calculations and download its PDF. Editing and private account data are not available.</p><div className="mono my-4 break-all rounded bg-muted p-3 text-xs" data-testid="text-share-url">{shareLink}</div><div className="flex flex-wrap gap-2"><button onClick={() => copy(shareLink)} className="min-h-10 rounded bg-primary px-4 text-xs font-semibold text-primary-foreground" data-testid="button-copy-share">{copied ? 'Copied' : 'Copy link'}</button><button onClick={() => { if (confirm('Revoke this share link? It stops working immediately.')) revoke.mutate({ id: chart.id }, { onSuccess: () => setShareLink('') }); }} disabled={revoke.isPending} className="min-h-10 rounded border border-border px-4 text-xs" data-testid="button-revoke-share">{revoke.isPending ? 'Revoking…' : 'Revoke'}</button></div></Modal>}
  </div>;
}

function SettingsPage() {
  const { isAuthenticated, login } = useAuth();
  const settings = useGetSettings({ query: { enabled: isAuthenticated, queryKey: getGetSettingsQueryKey() } });
  const update = useUpdateSettings(); const qc = useQueryClient();
  const exportData = useExportUserData({ query: { enabled: false, queryKey: getExportUserDataQueryKey() } });
  const [form, setForm] = useState<UserSettingsInput>({});
  const [q, setQ] = useState(''); const [picked, setPicked] = useState<Place | null>(null);
  const [initialized, setInitialized] = useState(false); const [msg, setMsg] = useState(''); const [gps, setGps] = useState('');
  useEffect(() => { if (settings.data && !initialized) { setForm({ ...settings.data }); setInitialized(true); } }, [settings.data, initialized]);
  const set = (patch: UserSettingsInput) => { setMsg(''); setForm(prev => ({ ...prev, ...patch })); };
  const save = () => update.mutate({ data: form }, { onSuccess: d => { qc.setQueryData(getGetSettingsQueryKey(), d); setMsg('Preferences saved.'); }, onError: e => setMsg(errorText(e, 'Preferences could not be saved.')) });
  const locate = () => { if (!navigator.geolocation) { setGps('Location is not available in this browser.'); return; } setGps('Requesting location…'); navigator.geolocation.getCurrentPosition(p => { set({ hereLabel: 'Current location', hereLat: Number(p.coords.latitude.toFixed(4)), hereLon: Number(p.coords.longitude.toFixed(4)), hereTz: Intl.DateTimeFormat().resolvedOptions().timeZone }); setGps(''); }, e => setGps(e.code === e.PERMISSION_DENIED ? 'Permission denied. Search for a place instead.' : 'Location unavailable. Search for a place instead.'), { timeout: 12000 }); };
  if (!isAuthenticated) return <><PageHeading eyebrow="Account / preferences" title="Defaults" detail="Your preferred calculation conventions and transit location."/><SignedOut login={login} context="configure personal calculation defaults and a transit location"/></>;
  if (settings.isLoading) return <SkeletonList/>;
  if (settings.isError) return <ErrorPanel title="Preferences unavailable" onRetry={() => settings.refetch()}/>;
  return <><PageHeading eyebrow="Account / preferences" title="Defaults" detail="Conventions prefilled for new charts, plus the location used for transit comparisons."/>
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]"><section className="surface rounded-md p-5 sm:p-7"><div className="mono text-[9px] uppercase tracking-[.16em] text-primary">01 / Calculation defaults</div><div className="mt-5 grid gap-4 sm:grid-cols-2">
      <SelectField label="Ayanamsa" value={String(form.ayanamsaMode ?? 'lahiri')} onChange={v => set({ ayanamsaMode: v as UserSettingsInput['ayanamsaMode'] })} options={AYANAMSAS} testId="select-pref-ayanamsa"/>
      <SelectField label="Zodiac / Shadbala frame" value={String(form.sbFrame ?? 'sidereal')} onChange={v => set({ sbFrame: v as UserSettingsInput['sbFrame'], zodiac: v as UserSettingsInput['zodiac'] })} options={FRAMES} testId="select-pref-frame"/>
      <SelectField label="Lunar node" value={String(form.nodeType ?? 'mean')} onChange={v => set({ nodeType: v as UserSettingsInput['nodeType'] })} options={NODES} testId="select-pref-node"/>
      <SelectField label="Dasa year" value={String(form.dasaYear ?? 365.2425)} onChange={v => set({ dasaYear: Number(v) as UserSettingsInput['dasaYear'] })} options={YEARS} testId="select-pref-year"/>
    </div><div className="mt-6 flex flex-wrap justify-between gap-3 border-t border-border pt-5"><span className="self-center text-xs text-muted-foreground" role="status">{msg || 'Used when creating new charts and previews.'}</span><button onClick={save} disabled={update.isPending} className="min-h-10 rounded bg-primary px-4 text-sm font-semibold text-primary-foreground" data-testid="button-save-settings">{update.isPending ? 'Saving…' : 'Save preferences'}</button></div></section>
    <div className="grid content-start gap-5"><section className="surface rounded-md p-5"><div className="mono text-[9px] uppercase tracking-[.16em] text-muted-foreground">02 / Transit location</div><h2 className="display mt-2 text-xl">Here & now</h2><p className="mt-2 text-xs leading-5 text-muted-foreground">Default place for transit comparisons. Saved with the preferences above.</p>
      <div className="mt-4 grid gap-3"><PlacePicker label="Search a place" query={q} setQuery={setQ} selected={picked} setSelected={p => { setPicked(p); if (p) set({ hereLabel: p.label, hereLat: p.lat, hereLon: p.lon, hereTz: p.tz }); }}/>
        <button onClick={locate} className="min-h-9 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-pref-gps">Use my current location</button>{gps && <p className="text-xs text-primary" role="status">{gps}</p>}
        <div className="mono rounded bg-muted/60 p-3 text-[11px]">{form.hereLat != null && form.hereLon != null ? <>{form.hereLabel || 'Unnamed'}<br/>{form.hereLat.toFixed(4)}, {form.hereLon.toFixed(4)} · {form.hereTz || '—'}</> : 'None set: transits use the birthplace.'}</div>
        {form.hereLat != null && <button onClick={() => set({ hereLabel: null, hereLat: null, hereLon: null, hereTz: null })} className="text-left text-xs text-muted-foreground underline">Clear location</button>}</div></section>
    <section className="surface rounded-md p-5"><div className="mono text-[9px] uppercase tracking-[.16em] text-muted-foreground">Data portability</div><p className="mt-2 text-sm text-muted-foreground">Export your charts, preferences, and any historical records as JSON.</p><button onClick={() => { exportData.refetch().then(({ data }) => { if (!data) return; const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'dhruva-jyotisha-export.json'; a.click(); URL.revokeObjectURL(url); }); }} disabled={exportData.isFetching} className="mt-3 flex min-h-9 items-center gap-2 rounded border border-border px-3 text-xs hover:bg-muted" data-testid="button-export"><FileDown size={14}/>{exportData.isFetching ? 'Preparing…' : 'Export my data'}</button>{exportData.isError && <p className="mt-2 text-xs text-destructive">Export failed. Try again.</p>}</section></div></div>
  </>;
}

function AppRoutes() {
  return <Switch>
    <Route path="/"><Frame><CreatePage/></Frame></Route>
    <Route path="/preview"><Frame><PreviewPage/></Frame></Route>
    <Route path="/charts"><Frame><ChartsPage/></Frame></Route>
    <Route path="/settings"><Frame><SettingsPage/></Frame></Route>
    <Route path="/chart/:id"><Frame><OwnedChartRoute/></Frame></Route>
    <Route path="/chart/:id/:tab"><Frame><OwnedChartRoute/></Frame></Route>
    <Route path="/shared/:token"><Frame shared><SharedChartRoute/></Frame></Route>
    <Route component={NotFound}/>
  </Switch>;
}

function App() {
  return <QueryClientProvider client={client}><ChartStyleProvider><AuthCacheGuard/><AppRoutes/></ChartStyleProvider></QueryClientProvider>;
}

export default App;
