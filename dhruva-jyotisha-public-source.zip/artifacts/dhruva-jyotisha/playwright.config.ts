import { defineConfig, devices } from '@playwright/test';
import { fileURLToPath } from 'node:url';

const output = fileURLToPath(new URL('../../generated-artifacts/chart-browser-tests/', import.meta.url));
const baseURL = process.env.CHART_TEST_BASE_URL
  ?? (process.env.CI ? 'http://127.0.0.1:3000' : 'http://localhost:80');

export default defineConfig({
  testDir: './tests/browser',
  outputDir: `${output}/results`,
  reporter: [
    ['list'],
    ['html', { outputFolder: `${output}/report`, open: 'never' }],
    ['json', { outputFile: `${output}/results.json` }],
  ],
  // PDF generation is CPU-heavy. Keep the matrix deterministic on small runners.
  workers: 1,
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: 0,
  timeout: 90_000,
  expect: { timeout: 15_000 },
  use: {
    baseURL,
    acceptDownloads: true,
    serviceWorkers: 'block',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  ],
  // Locally use the existing managed workflow via the shared proxy. A fresh CI
  // runner has no Replit proxy/workflows, so it starts its own frontend only.
  webServer: process.env.CI && !process.env.CHART_TEST_BASE_URL ? {
    command: 'pnpm run dev',
    env: { PORT: '3000', BASE_PATH: '/', NODE_ENV: 'production' },
    url: baseURL,
    reuseExistingServer: false,
    timeout: 60_000,
  } : undefined,
});
