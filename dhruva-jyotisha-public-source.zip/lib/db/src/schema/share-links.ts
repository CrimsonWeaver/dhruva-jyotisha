import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, timestamp, uuid, varchar } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { chartsTable } from "./charts";

export const shareLinksTable = pgTable(
  "share_links",
  {
    token: varchar("token", { length: 64 }).primaryKey(),
    chartId: uuid("chart_id").notNull().references(() => chartsTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (table) => [index("share_links_chart_created_idx").on(table.chartId, table.createdAt)],
);

export const insertShareLinkSchema = createInsertSchema(shareLinksTable).omit({
  createdAt: true,
});
export type InsertShareLink = z.infer<typeof insertShareLinkSchema>;
export type ShareLink = typeof shareLinksTable.$inferSelect;
