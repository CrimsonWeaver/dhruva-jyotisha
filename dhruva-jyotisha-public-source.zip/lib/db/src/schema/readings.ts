import { createInsertSchema } from "drizzle-zod";
import { boolean, index, integer, pgTable, text, timestamp, uuid, varchar, bigint } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { chartsTable } from "./charts";

export const readingsTable = pgTable(
  "readings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    chartId: uuid("chart_id").notNull().references(() => chartsTable.id, { onDelete: "cascade" }),
    transitMs: bigint("transit_ms", { mode: "number" }).notNull(),
    months: integer("months").notNull(),
    focus: varchar("focus", { length: 300 }).notNull().default(""),
    model: varchar("model", { length: 100 }).notNull(),
    text: text("text").notNull(),
    truncated: boolean("truncated").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("readings_chart_created_idx").on(table.chartId, table.createdAt)],
);

export const insertReadingSchema = createInsertSchema(readingsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertReading = z.infer<typeof insertReadingSchema>;
export type Reading = typeof readingsTable.$inferSelect;
