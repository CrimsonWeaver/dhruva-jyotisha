import { pgTable, varchar, integer, date, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./auth";

export const readingUsageTable = pgTable("reading_usage", {
  userId: varchar("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  day: date("day", { mode: "string" }).notNull(),
  requests: integer("requests").notNull().default(0),
}, table => [primaryKey({ columns: [table.userId, table.day] })]);
export const insertReadingUsageSchema = createInsertSchema(readingUsageTable);
export type InsertReadingUsage = z.infer<typeof insertReadingUsageSchema>;
export type ReadingUsage = typeof readingUsageTable.$inferSelect;
