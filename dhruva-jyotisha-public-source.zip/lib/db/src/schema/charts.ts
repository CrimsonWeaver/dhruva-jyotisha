import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, uuid, varchar, doublePrecision, date, time, bigint, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./auth";

export const chartsTable = pgTable(
  "charts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: varchar("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 120 }).notNull(),
    placeLabel: varchar("place_label", { length: 240 }).notNull(),
    lat: doublePrecision("lat").notNull(),
    lon: doublePrecision("lon").notNull(),
    tz: varchar("tz", { length: 100 }).notNull(),
    localDate: date("local_date", { mode: "string" }).notNull(),
    localTime: time("local_time").notNull(),
    utcMs: bigint("utc_ms", { mode: "number" }).notNull(),
    nodeType: varchar("node_type", { length: 20 }).notNull().default("mean"),
    dasaYear: doublePrecision("dasa_year").notNull().default(365.25),
    zodiac: varchar("zodiac", { length: 20 }).notNull().default("tropical"),
    ayanamsaMode: varchar("ayanamsa_mode", { length: 24 }).notNull().default("equatorial"),
    sbFrame: varchar("sb_frame", { length: 20 }).notNull().default("tropical"),
    engineVersion: varchar("engine_version", { length: 80 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [index("charts_user_updated_idx").on(table.userId, table.updatedAt)],
);

export const insertChartSchema = createInsertSchema(chartsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertChart = z.infer<typeof insertChartSchema>;
export type Chart = typeof chartsTable.$inferSelect;
