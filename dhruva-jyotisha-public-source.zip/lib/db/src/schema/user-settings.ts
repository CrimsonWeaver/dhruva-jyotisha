import { createInsertSchema } from "drizzle-zod";
import { doublePrecision, pgTable, timestamp, varchar } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./auth";

export const userSettingsTable = pgTable("user_settings", {
  userId: varchar("user_id").primaryKey().references(() => usersTable.id, { onDelete: "cascade" }),
  nodeType: varchar("node_type", { length: 20 }).notNull().default("mean"),
  dasaYear: doublePrecision("dasa_year").notNull().default(365.25),
  zodiac: varchar("zodiac", { length: 20 }).notNull().default("tropical"),
  ayanamsaMode: varchar("ayanamsa_mode", { length: 24 }).notNull().default("equatorial"),
  sbFrame: varchar("sb_frame", { length: 20 }).notNull().default("tropical"),
  hereLabel: varchar("here_label", { length: 240 }),
  hereLat: doublePrecision("here_lat"),
  hereLon: doublePrecision("here_lon"),
  hereTz: varchar("here_tz", { length: 100 }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSettingsSchema = createInsertSchema(userSettingsTable).omit({
  updatedAt: true,
});
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettingsTable.$inferSelect;
