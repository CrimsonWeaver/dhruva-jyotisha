# Dhruva Jyotisha

Vedic chart workbench using tropical signs (or a selected sidereal framework),
sidereal nakshatras, Dhruva and standard ayanamshas, and the supplied Kala-style
calculation core. The original `core.js`, `placesearch.js`, and Swiss vector
adapter are preserved unchanged.

## Development

Use Node.js 24 and pnpm 10.26.1. The locked native dependencies target
Linux x86-64. From a clean checkout, install and build both services with:

```sh
pnpm install --frozen-lockfile
PORT=3000 BASE_PATH=/ pnpm run build
```

Builds and component tests do not require a database or account credentials.
Running the full app requires a Replit workspace configured to serve the web app
at `/` and the API server at `/api` on the same origin. The managed workflows in
the original workspace supply the ports and routing. Workspace-specific
registrations and credentials are not part of the source archive.

Required configuration:

- Replit PostgreSQL (`DATABASE_URL`) and Replit Auth.
- Replit App Storage, provisioned through the workspace. Public, non-personal
  datasets live under `dhruva-datasets/` in the configured default bucket.

The place dataset is the supplied GeoNames cities1000 derivative (CC BY 4.0).
The Swiss Ephemeris files `sepl_18.se1` and `semo_18.se1` come from
https://github.com/aloistr/swisseph/tree/master/ephe and cover 1800–2399.
They and the 8.4 MB place list are kept in App Storage, not Git. The server
downloads missing local caches automatically. To populate a new configured
bucket, run `node artifacts/api-server/scripts/prepare-test-data.mjs` from
the repository root (requires Python 3 and network access). Then, from
`artifacts/api-server`, run
`DATASET_SOURCE_DIR=../../generated-artifacts node scripts/seed-datasets.mjs`
using the workspace's App Storage authorization.

```sh
pnpm --filter @workspace/db run push              # development database only
pnpm --filter @workspace/api-spec run codegen
pnpm run typecheck
node artifacts/api-server/scripts/prepare-test-data.mjs # for a fresh checkout / CI
pnpm --filter @workspace/api-server run test:engine
node artifacts/api-server/scripts/test-api.mjs
```

The API integration check creates temporary isolated test accounts and synthetic
historical records, then deletes them in `finally`. It confirms retired AI
endpoints cannot generate readings and that historical records remain confined
to their owner's private export. It makes no AI requests. Never use real birth
records as test fixtures.

### Chart PDF regression checks

```sh
pnpm --filter @workspace/dhruva-jyotisha run test:charts
pnpm --filter @workspace/dhruva-jyotisha exec playwright install chromium firefox webkit
pnpm --filter @workspace/dhruva-jyotisha run test:charts:browser
```

Both suites require Poppler's `pdftotext` and `pdffonts`. On a fresh supported
Linux runner use `playwright install --with-deps chromium firefox webkit` to
install the browsers' system dependencies too. The browser suite uses the existing
web workflow at `http://localhost:80` in Replit; start that managed workflow first.
To target another frontend origin, set `CHART_TEST_BASE_URL` (include a trailing
slash for any base path). No API server, database, authentication credentials or
astronomical datasets are needed. CI starts an isolated frontend automatically.

The 18 browser checks (six per Chromium, Firefox and WebKit) exercise the real
guest, owned, and shared chart previews and export components with synthetic
API responses. They require actual download events,
validate saved PDF bytes, embedded fonts and layout-specific text, check layout
persistence, inject a failed font response and retry without a reload, and hold a
font request to switch layouts during generation in both directions. All other
API requests and outgoing writes are blocked and fail the privacy assertions.
Session/local storage, cookies and IndexedDB are checked for unintended changes;
only the chart-layout preference may change during export.

Reports, PDFs, screenshots and traces go under the ignored
`generated-artifacts/chart-browser-tests/` directory, never into application
storage. Open the report with
`pnpm --filter @workspace/dhruva-jyotisha exec playwright show-report ../../generated-artifacts/chart-browser-tests/report`.
Use `--project=firefox` (or `chromium` / `webkit`) after `test:charts:browser` to
isolate an engine. The dedicated **Chart PDF downloads** CI check runs the full
matrix on pushes and pull requests and retains reports for seven days. It fails
if a browser is missing; browsers are never silently skipped.

Replit's Nix workspace may need native-library setup beyond downloading upstream
Playwright browsers. Use the supported Ubuntu CI job for the full release check
rather than skipping an engine. Keep machine-specific browser binaries and setup
under `generated-artifacts/`, separate from the portable test configuration.

## Calculation integrity

All positions come from Swiss Ephemeris through the supplied vector adapter.
Missing data produces an explicit error; Moshier fallback is not permitted.
Calculations and twelve-month transit scans run on the server. Transit scans use
bounded child processes because Swiss Ephemeris native settings are process-wide,
including across Node worker threads. The PWA shell does not imply offline
astronomical computation.

The adapter comparison test retains its 60-arcsecond threshold. Its original
Moon discrepancy near 2100 was due to different future delta-T estimates, not
different coordinate frames: the comparison now shares Swiss's delta-T with
Astronomy Engine while keeping the two independent planetary models. Production
continues to use Swiss's own UT-to-TT conversion. Two fixture errors were also
corrected: planet identity is `id`, not `name`, and vector lengths must use only
`x/y/z`, not Astronomy Engine's extra time metadata. The core regression suites
remain unchanged.

## Privacy and data portability

Only explicit saves persist birth inputs. Saved charts, settings and exports
require an authenticated owner. Shared charts are read-only and never
include reading history or ownership details. Revocation invalidates the shared
URL. Responses containing birth data are not cached by the API.

AI readings have been removed. The app has no AI SDK, generation handler, or
model/API-key requirement. Legacy reading URLs show the chart overview, while
the retired singular and plural API endpoints return HTTP 410 after the normal
authentication and ownership checks. Previously saved readings are not deleted:
they remain available only through the owner's private JSON export. The legacy
database tables remain intact; this removal requires no database migration.
The original reference template is retained as source provenance and is not
served as an app feature. API keys and request bodies are not logged.

## License and source

AGPL-3.0-or-later; see `LICENSE` and `LICENSE-NOTICE.md`. The Source code footer
downloads an archive of the complete application source through `/api/source`.
The archive uses an explicit allowlist and excludes secrets, uploads, user data,
conversations, dependencies and Git history.

To reproduce the source archive from a checkout, run
`node artifacts/api-server/scripts/package-source.mjs generated-artifacts/dhruva-source.tar.gz`.
It includes both services, their regression tests and CI configuration, and
does not depend on the workspace's Git history.
