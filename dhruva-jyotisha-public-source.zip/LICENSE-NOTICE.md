# Licence notice

Dhruva Jyotisha is free software: you can redistribute it and/or modify it under the terms of the GNU Affero
General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your
option) any later version. It is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public
License for more details: https://www.gnu.org/licenses/agpl-3.0.html

Because the app is offered over a network, every user must be able to get the complete corresponding source code.
The running app therefore links to its public source repository.

## Third-party components
- Swiss Ephemeris, (c) Astrodienst AG, used under the AGPL. https://www.astro.com/swisseph/
- Astronomy Engine, by Don Cross, MIT licence (used for cross-checks and by the single-file reference build).
- Place data from GeoNames, CC BY 4.0. https://www.geonames.org/
